// background.js - Service Worker for Knowunity Assistant & SaveFrom Customizer v5.2
// Features: Resilient Cookie Clearing + Network-Level Ad-Blocker (declarativeNetRequest) for savefrom.net

const SAVEFROM_AD_DOMAINS = [
  'doubleclick.net',
  'googlesyndication.com',
  'googleadservices.com',
  'adservice.google.com',
  'popads.net',
  'popcash.net',
  'propellerads.com',
  'exoclick.com',
  'adsterra.com',
  'clickadu.com',
  'hilltopads.net',
  'mgid.com',
  'taboola.com',
  'outbrain.com',
  'yandex.ru/ads',
  'an.yandex.ru',
  'mc.yandex.ru',
  'bet365.com',
  '1xbet.com'
];

async function updateSaveFromAdBlockRules(enabled = true) {
  if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) return;

  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existing.map(r => r.id);

    if (!enabled) {
      if (removeRuleIds.length > 0) {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] });
      }
      return;
    }

    const addRules = SAVEFROM_AD_DOMAINS.map((domain, idx) => ({
      id: 5000 + idx,
      priority: 1,
      action: { type: 'block' },
      condition: {
        urlFilter: `||${domain}`,
        initiatorDomains: ['savefrom.net', 'en1.savefrom.net', 'en.savefrom.net'],
        resourceTypes: ['script', 'sub_frame', 'xmlhttprequest', 'image', 'media', 'ping', 'other']
      }
    }));

    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds,
      addRules
    });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get({ sfAdBlockEnabled: true }, (data) => {
    updateSaveFromAdBlockRules(Boolean(data.sfAdBlockEnabled));
  });
});

if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sfAdBlockEnabled !== undefined) {
      updateSaveFromAdBlockRules(Boolean(changes.sfAdBlockEnabled.newValue));
    }
  });
}

function removeCookieResilient(cookie) {
  return new Promise((resolve) => {
    try {
      const rawDomain = (cookie.domain || '').replace(/^\./, '');
      const path = (cookie.path && cookie.path.startsWith('/')) ? cookie.path : ('/' + (cookie.path || ''));
      const primaryProtocol = cookie.secure ? 'https:' : 'http:';
      const fallbackProtocol = cookie.secure ? 'http:' : 'https:';
      const primaryUrl = `${primaryProtocol}//${rawDomain}${path}`;
      const fallbackUrl = `${fallbackProtocol}//${rawDomain}${path}`;

      const detailsWithPartition = {
        url: primaryUrl,
        name: cookie.name,
        storeId: cookie.storeId
      };
      if (cookie.partitionKey && typeof cookie.partitionKey === 'object') {
        detailsWithPartition.partitionKey = cookie.partitionKey;
      }

      chrome.cookies.remove(detailsWithPartition, (res1) => {
        if (!chrome.runtime.lastError && res1) {
          return resolve(true);
        }
        // Fallback 1: without partitionKey
        const detailsNoPartition = {
          url: primaryUrl,
          name: cookie.name,
          storeId: cookie.storeId
        };
        chrome.cookies.remove(detailsNoPartition, (res2) => {
          if (!chrome.runtime.lastError && res2) {
            return resolve(true);
          }
          // Fallback 2: alternate protocol
          const detailsAlt = {
            url: fallbackUrl,
            name: cookie.name,
            storeId: cookie.storeId
          };
          chrome.cookies.remove(detailsAlt, (res3) => {
            resolve(Boolean(!chrome.runtime.lastError && res3));
          });
        });
      });
    } catch (e) {
      resolve(false);
    }
  });
}

async function clearAllTargetSiteCookies(senderUrl = '') {
  const isSaveFrom = senderUrl.toLowerCase().includes('savefrom.net') || senderUrl.toLowerCase().includes('sfrom.net');
  const domains = isSaveFrom
    ? ['savefrom.net', '.savefrom.net', 'en1.savefrom.net', '.en1.savefrom.net', 'sfrom.net', '.sfrom.net']
    : ['knowunity.ph', '.knowunity.ph', 'knowunity.com', '.knowunity.com', 'knowunity.de', '.knowunity.de'];
  const keyword = isSaveFrom ? 'savefrom' : 'knowunity';
  const cookieMap = new Map();

  const addCookies = (list) => {
    if (!Array.isArray(list)) return;
    for (const c of list) {
      if (!c || !c.name) continue;
      const key = `${c.name}|${c.domain}|${c.path}|${c.storeId || ''}`;
      cookieMap.set(key, c);
    }
  };

  // 1. Query by known domains
  for (const domain of domains) {
    await new Promise((resolve) => {
      try {
        chrome.cookies.getAll({ domain }, (cookies) => {
          if (!chrome.runtime.lastError) addCookies(cookies);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  // 2. Query by sender tab URL if valid
  if (senderUrl && (senderUrl.startsWith('http://') || senderUrl.startsWith('https://'))) {
    await new Promise((resolve) => {
      try {
        chrome.cookies.getAll({ url: senderUrl }, (cookies) => {
          if (!chrome.runtime.lastError) addCookies(cookies);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  // 3. Broad scan for any cookie containing keyword in its domain
  await new Promise((resolve) => {
    try {
      chrome.cookies.getAll({}, (cookies) => {
        if (!chrome.runtime.lastError && Array.isArray(cookies)) {
          const matched = cookies.filter(c => c && c.domain && c.domain.toLowerCase().includes(keyword));
          addCookies(matched);
        }
        resolve();
      });
    } catch (e) {
      resolve();
    }
  });

  const allCookies = Array.from(cookieMap.values());
  let removedCount = 0;

  for (const cookie of allCookies) {
    const ok = await removeCookieResilient(cookie);
    if (ok) removedCount++;
  }

  return { success: true, removedCount, totalFound: allCookies.length };
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (!req || !req.action) return false;

  if (req.action === 'clear_website_cookies_from_page') {
    const tabUrl = (req.url) || (sender && sender.tab && sender.tab.url) || '';
    clearAllTargetSiteCookies(tabUrl)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, removedCount: 0, error: err ? err.message : 'Unknown error' }));
    return true;
  }

  return false;
});
