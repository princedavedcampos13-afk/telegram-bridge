// email_generator.js - Cryptographic Unique Test Email Generator with Unlimited Generation & Domain Validation

const EmailGenerator = (() => {
  const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const generatedHistory = new Set();
  let monotonicCounter = 0;

  const KNOWN_DOMAINS = {
    'tempforward.com': {
      supported: false,
      reason: "Domain 'tempforward.com' is not verified or supported by an active inbound email provider. Verification messages cannot be received."
    },
    'gmail.com': {
      supported: true,
      description: "Standard web email domain."
    },
    'outlook.com': {
      supported: true,
      description: "Standard web email domain."
    },
    'testmail.dev': {
      supported: true,
      description: "Standard testing domain with inbound API support."
    },
    'mailtrap.io': {
      supported: true,
      description: "Developer testing inbox service."
    },
    'example.com': {
      supported: true,
      description: "RFC 2606 reserved documentation & unit test domain."
    }
  };

  function normalizeEmail(email) {
    if (!email || typeof email !== 'string') return '';
    const trimmed = email.trim();
    const atIndex = trimmed.lastIndexOf('@');
    if (atIndex === -1) return trimmed.toLowerCase();
    const user = trimmed.slice(0, atIndex);
    const domain = trimmed.slice(atIndex + 1).toLowerCase();
    return `${user}@${domain}`;
  }

  function validateDomain(domain) {
    if (!domain || typeof domain !== 'string') {
      return { valid: false, error: 'Domain must be a non-empty string.' };
    }
    const cleanDomain = domain.trim().toLowerCase().replace(/^@/, '');
    if (!cleanDomain.includes('.') || cleanDomain.endsWith('.')) {
      return { valid: false, error: `Invalid domain format: "${cleanDomain}"` };
    }

    if (KNOWN_DOMAINS[cleanDomain]) {
      const info = KNOWN_DOMAINS[cleanDomain];
      if (!info.supported) {
        return { valid: false, error: info.reason, domain: cleanDomain };
      }
      return { valid: true, domain: cleanDomain, description: info.description };
    }

    return {
      valid: true,
      domain: cleanDomain,
      description: 'Custom domain (ensure your provider is configured to receive verification messages).'
    };
  }

  function generateRandomUsername(length = 6) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const webCrypto = (typeof crypto !== 'undefined') ? crypto : ((typeof window !== 'undefined') ? window.crypto : null);

    // High-entropy unique username: student + base36 timestamp + monotonic counter + random chars
    monotonicCounter = (monotonicCounter + 1) % 1000000;
    const timeStr = Date.now().toString(36);
    const countStr = monotonicCounter.toString(36);
    let randomLetters = '';

    if (webCrypto && typeof webCrypto.getRandomValues === 'function') {
      const values = new Uint8Array(length);
      webCrypto.getRandomValues(values);
      for (let i = 0; i < length; i++) {
        randomLetters += chars[values[i] % chars.length];
      }
    } else {
      for (let i = 0; i < length; i++) {
        randomLetters += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }

    return `student${timeStr}${countStr}${randomLetters}`;
  }

  function generateEmail(domain = 'gmail.com', customUsername = null) {
    const domainCheck = validateDomain(domain);
    if (!domainCheck.valid) {
      return {
        success: false,
        email: null,
        error: domainCheck.error
      };
    }

    let attempts = 0;
    while (true) {
      attempts++;
      const user = customUsername ? customUsername.trim().toLowerCase() : generateRandomUsername(6);
      const rawEmail = `${user}@${domainCheck.domain}`;
      const normalized = normalizeEmail(rawEmail);

      if (!EMAIL_REGEX.test(normalized)) {
        if (attempts > 5) {
          const safeUser = `student${Date.now().toString(36)}${Math.random().toString(36).substring(2, 6)}`;
          const safeEmail = `${safeUser}@${domainCheck.domain}`;
          generatedHistory.add(safeEmail);
          return {
            success: true,
            email: safeEmail,
            username: safeUser,
            domain: domainCheck.domain,
            description: domainCheck.description,
            attemptsRequired: attempts,
            historyCount: generatedHistory.size
          };
        }
        continue;
      }

      if (!generatedHistory.has(normalized)) {
        generatedHistory.add(normalized);
        if (generatedHistory.size > 5000) {
          const first = generatedHistory.values().next().value;
          generatedHistory.delete(first);
        }
        return {
          success: true,
          email: normalized,
          username: user,
          domain: domainCheck.domain,
          description: domainCheck.description,
          attemptsRequired: attempts,
          historyCount: generatedHistory.size
        };
      }

      if (customUsername) {
        return {
          success: false,
          email: null,
          error: `Requested custom address "${normalized}" has already been generated in this session.`
        };
      }

      if (attempts > 20) {
        const forcedUser = `student${Date.now().toString(36)}${Math.random().toString(36).substring(2, 8)}`;
        const forcedEmail = `${forcedUser}@${domainCheck.domain}`;
        generatedHistory.add(forcedEmail);
        return {
          success: true,
          email: forcedEmail,
          username: forcedUser,
          domain: domainCheck.domain,
          description: domainCheck.description,
          attemptsRequired: attempts,
          historyCount: generatedHistory.size
        };
      }
    }
  }

  function loadHistory(historyList) {
    if (Array.isArray(historyList)) {
      historyList.forEach(e => {
        const norm = normalizeEmail(e);
        if (norm) generatedHistory.add(norm);
      });
    }
  }

  function getHistory() {
    return Array.from(generatedHistory);
  }

  function clearHistory() {
    generatedHistory.clear();
  }

  function hasEmail(email) {
    return generatedHistory.has(normalizeEmail(email));
  }

  return {
    validateDomain,
    generateEmail,
    generateRandomUsername,
    normalizeEmail,
    loadHistory,
    getHistory,
    clearHistory,
    hasEmail,
    EMAIL_REGEX
  };
})();

if (typeof window !== 'undefined') {
  window.EmailGenerator = EmailGenerator;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EmailGenerator;
}
