// content.js - Knowunity Assistant v5.1 Content Script
// Features: Continuous Infinite Rotation Loop (Sign Up -> Magpatuloy -> 6-Box Referral -> I-apply -> Tapos Na -> Auto-Clear Cookies -> Back to Sign Up Landing Page -> Repeat Until Stopped),
// Multi-Code Referral Rotation Pool, Instant Stop Control, Repositionable Floating Glass Dock & Menu Drawer, and 100% Vector UI.

(() => {
  if (window.__knowunityHelperLoaded) return;
  window.__knowunityHelperLoaded = true;

  let isWorkflowRunning = false;
  let isStoppedByUser = false;
  let activeRunToken = 0;
  let loopTimerId = null;
  let workflowStartTimeMs = 0;

  // --- Helper: Identify Extension Own DOM Elements ---
  function isExtensionEl(el) {
    if (!el || typeof el.closest !== 'function') return false;
    return !!el.closest(
      "#knowunity-site-toolbar, #knowunity-site-menu-panel, #knowunity-helper-toast, [id^='knowunity-'], .kn-ext-element"
    );
  }

  // --- Helper: Get Visible Page Text Excluding Extension UI ---
  function getSiteBodyText() {
    if (!document.body) return '';
    try {
      const toolbar = document.getElementById('knowunity-site-toolbar');
      const toast = document.getElementById('knowunity-helper-toast');
      const rawText = document.body.innerText || document.body.textContent || '';
      if (!toolbar && !toast) return rawText.toLowerCase();

      let clean = rawText;
      if (toolbar) {
        const tbText = toolbar.innerText || toolbar.textContent || '';
        if (tbText) clean = clean.replace(tbText, '');
      }
      if (toast) {
        const tsText = toast.innerText || toast.textContent || '';
        if (tsText) clean = clean.replace(tsText, '');
      }
      return clean.toLowerCase();
    } catch (e) {
      return ((document.body && document.body.innerText) || '').toLowerCase();
    }
  }

  // --- Helper: Robust Element Visibility ---
  function isElementVisible(el, allowOpacityZero = false) {
    if (!el) return false;
    if (el.nodeType !== Node.ELEMENT_NODE) return true;
    if (el.hidden || el.getAttribute('aria-hidden') === 'true') return false;

    try {
      const style = window.getComputedStyle ? window.getComputedStyle(el) : el.style;
      if (style) {
        if (style.display === 'none' || style.visibility === 'hidden') {
          return false;
        }
        if (!allowOpacityZero && style.opacity === '0') {
          return false;
        }
      }
      if (typeof el.getClientRects === 'function') {
        const rects = el.getClientRects();
        if (rects.length > 0) return true;
      }
    } catch (e) {}

    return el.offsetParent !== null;
  }

  // --- 1. Robust Page Mode Detection: LOGIN vs SIGN_UP vs UNKNOWN ---
  function detectPageMode() {
    const url = window.location.href.toLowerCase();

    if (url.includes('/login') || url.includes('mode=login') || url.includes('auth=login') || url.includes('signin')) {
      return 'LOGIN';
    }
    if (url.includes('/signup') || url.includes('/register') || url.includes('mode=register') || url.includes('mode=signup')) {
      return 'SIGN_UP';
    }

    const headings = Array.from(
      document.querySelectorAll('h1, h2, h3, h4, h5, [role="heading"], [class*="title" i], [class*="header" i], header')
    );
    let headingText = '';
    for (const h of headings) {
      if (!isExtensionEl(h) && isElementVisible(h)) {
        headingText += ' ' + (h.innerText || h.textContent || '').trim().toLowerCase();
      }
    }

    const candidates = Array.from(document.querySelectorAll('a, button, [role="button"], input[type="submit"], p, span'));
    const linkTexts = [];
    const buttonTexts = [];
    for (const el of candidates) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (txt && txt.length < 80) {
        if (el.tagName === 'BUTTON' || el.getAttribute('role') === 'button' || el.type === 'submit') {
          buttonTexts.push(txt);
        } else if (el.tagName === 'A' || el.closest('a')) {
          linkTexts.push(txt);
        }
      }
    }

    const fullBody = getSiteBodyText();

    const siteInputs = Array.from(document.querySelectorAll('input')).filter(el => !isExtensionEl(el) && isElementVisible(el));
    const hasEmail = siteInputs.some(el => {
      const t = (el.type || '').toLowerCase();
      const n = (el.name || '').toLowerCase();
      const id = (el.id || '').toLowerCase();
      const ph = (el.placeholder || '').toLowerCase();
      return t === 'email' || n.includes('email') || id.includes('email') || ph.includes('email');
    });
    const hasPassword = siteInputs.some(el => (el.type || '').toLowerCase() === 'password');
    const hasTermsCheckbox = siteInputs.some(el => (el.type || '').toLowerCase() === 'checkbox');
    const hasForgotPassword =
      linkTexts.some(t => t.includes('nakalimutan') || t.includes('forgot')) ||
      fullBody.includes('nakalimutan ang password') ||
      fullBody.includes('forgot password');

    if (hasForgotPassword && hasEmail) {
      return 'LOGIN';
    }

    const hasSwitchToSignUpLink = linkTexts.some(
      t =>
        t.includes('wala ka pang account') ||
        t.includes("don't have an account") ||
        t.includes('mag-register') ||
        t.includes('mag-sign up') ||
        t === 'sign up' ||
        t === 'register'
    );
    if (hasSwitchToSignUpLink && (hasPassword || hasEmail) && !hasTermsCheckbox) {
      return 'LOGIN';
    }

    const hasLoginButton = buttonTexts.some(
      t =>
        t.includes('mag-log in') ||
        t.includes('mag-login') ||
        t.includes('log in') ||
        t.includes('sign in') ||
        t.includes('mag-sign in')
    );
    if (hasLoginButton && !hasTermsCheckbox) {
      return 'LOGIN';
    }

    if (
      headingText.includes('mag-log in') ||
      headingText.includes('log in') ||
      headingText.includes('sign in') ||
      headingText.includes('mag-sign in') ||
      headingText.includes('mag log in')
    ) {
      if (!headingText.includes('register') && !headingText.includes('sign up')) {
        return 'LOGIN';
      }
    }

    if (
      headingText.includes('mag-register') ||
      headingText.includes('sign up') ||
      headingText.includes('create account') ||
      headingText.includes('lumikha ng account')
    ) {
      return 'SIGN_UP';
    }

    if (hasTermsCheckbox || fullBody.includes('sa pamamagitan ng pagrehistro') || fullBody.includes('by signing up')) {
      return 'SIGN_UP';
    }

    const hasSwitchToLoginLink = linkTexts.some(
      t => t.includes('mayroon na akong account') || t.includes('already have an account')
    );
    if (hasSwitchToLoginLink) {
      return 'SIGN_UP';
    }

    if (hasEmail) {
      if (hasLoginButton && !hasTermsCheckbox) return 'LOGIN';
      return 'SIGN_UP';
    }

    return 'UNKNOWN';
  }

  // --- 2. Switch from Login to Sign Up Mode ---
  async function switchToSignUp(timeoutMs = 4000) {
    const current = detectPageMode();
    if (current === 'SIGN_UP') {
      return { success: true, message: 'Already in Sign-Up mode.' };
    }

    const switchTerms = [
      'wala ka pang account',
      'mag-register',
      'mag-sign up',
      'lumikha ng account',
      'create an account',
      'create account',
      'sign up',
      'register',
      "don't have an account"
    ];

    const clickableElements = Array.from(document.querySelectorAll('a, button, [role="button"], span, p'));
    let targetElement = null;

    for (const el of clickableElements) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (!text) continue;

      for (const term of switchTerms) {
        if (text === term || text.includes(term)) {
          const candidate = el.closest('a, button, [role="button"]') || el;
          if (!isExtensionEl(candidate)) {
            targetElement = candidate;
            break;
          }
        }
      }
      if (targetElement) break;
    }

    if (!targetElement) {
      return {
        success: false,
        message: 'Could not find a switch-to-signup link on the page.'
      };
    }

    simulateUserClick(targetElement);

    const start = Date.now();
    return new Promise((resolve) => {
      const interval = setInterval(() => {
        const mode = detectPageMode();
        if (mode === 'SIGN_UP' || Date.now() - start > timeoutMs) {
          clearInterval(interval);
          resolve({
            success: mode === 'SIGN_UP',
            message: mode === 'SIGN_UP' ? 'Successfully switched to Sign-Up mode.' : 'Timed out waiting for Sign-Up mode.'
          });
        }
      }, 100);
    });
  }

  // --- Helper: Find "Continue with Email" Button ---
  function findContinueWithEmailButton() {
    const candidates = Array.from(document.querySelectorAll("button, a, [role='button'], div[role='button']"));
    const terms = [
      'magpatuloy gamit ang email',
      'gamitin ang email',
      'continue with email',
      'sign up with email',
      'mag-sign up gamit ang email',
      'use email',
      'email address'
    ];
    for (const el of candidates) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      for (const t of terms) {
        if (text.includes(t)) {
          return el;
        }
      }
    }
    return null;
  }

  // --- 3. React & Framework-Compatible Input Setter ---
  function setFrameworkInputValue(element, value) {
    if (!element) return false;

    try {
      element.focus();
    } catch (e) {}

    const prototype = Object.getPrototypeOf(element);
    const nativeSetter =
      Object.getOwnPropertyDescriptor(prototype, 'value')?.set ||
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;

    if (nativeSetter) {
      nativeSetter.call(element, value);
    } else {
      element.value = value;
    }

    if (element._valueTracker) {
      try {
        element._valueTracker.setValue('');
      } catch (e) {}
    }

    const eventOptions = { bubbles: true, cancelable: true, composed: true };

    try {
      element.dispatchEvent(new InputEvent('beforeinput', { data: value, ...eventOptions }));
    } catch (e) {}

    element.dispatchEvent(new Event('input', eventOptions));
    element.dispatchEvent(new Event('change', eventOptions));

    try {
      element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }));
      element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));
    } catch (e) {}

    element.dispatchEvent(new Event('blur', { bubbles: true, composed: true }));

    return element.value === value;
  }

  // --- 4. Locators & Asynchronous Polling ---
  function findInputsImmediate() {
    const emailSelectors = [
      'input[type="email"]',
      'input[name*="email" i]',
      'input[id*="email" i]',
      'input[autocomplete="email"]',
      'input[autocomplete="username"]',
      'input[placeholder*="email" i]',
      'input[aria-label*="email" i]',
      'input[data-testid*="email" i]'
    ];

    const passwordSelectors = [
      'input[type="password"]',
      'input[name*="password" i]',
      'input[id*="password" i]',
      'input[autocomplete*="password" i]',
      'input[placeholder*="password" i]',
      'input[data-testid*="password" i]'
    ];

    let emailInput = null;
    for (const sel of emailSelectors) {
      const matches = Array.from(document.querySelectorAll(sel));
      for (const el of matches) {
        if (!isExtensionEl(el) && isElementVisible(el)) {
          emailInput = el;
          break;
        }
      }
      if (emailInput) break;
    }

    if (!emailInput) {
      const allTextInputs = Array.from(
        document.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="password"])')
      );
      for (const el of allTextInputs) {
        if (isExtensionEl(el) || !isElementVisible(el)) continue;
        const ml = el.getAttribute('maxlength') || el.maxLength;
        if (ml === 1 || ml === '1' || ml === 6 || ml === '6') continue;
        const type = (el.type || 'text').toLowerCase();
        if (type === 'text' || type === 'email') {
          emailInput = el;
          break;
        }
      }
    }

    let passwordInput = null;
    for (const sel of passwordSelectors) {
      const matches = Array.from(document.querySelectorAll(sel));
      for (const el of matches) {
        if (!isExtensionEl(el) && isElementVisible(el)) {
          passwordInput = el;
          break;
        }
      }
      if (passwordInput) break;
    }

    return { emailInput, passwordInput };
  }

  async function waitForInputs(timeoutMs = 6000) {
    const start = Date.now();
    let fields = findInputsImmediate();
    if (fields.emailInput) return fields;

    const emailOpt = findContinueWithEmailButton();
    if (emailOpt && isElementVisible(emailOpt)) {
      simulateUserClick(emailOpt);
    }

    return new Promise((resolve) => {
      let done = false;
      const observer = new MutationObserver(() => {
        if (done) return;
        fields = findInputsImmediate();
        if (fields.emailInput) {
          done = true;
          observer.disconnect();
          clearInterval(interval);
          resolve(fields);
        }
      });

      try {
        observer.observe(document.documentElement || document.body, { childList: true, subtree: true });
      } catch (e) {}

      const interval = setInterval(() => {
        if (done) return;
        if (isStoppedByUser) {
          done = true;
          observer.disconnect();
          clearInterval(interval);
          return resolve({ emailInput: null, passwordInput: null });
        }
        fields = findInputsImmediate();
        if (fields.emailInput) {
          done = true;
          observer.disconnect();
          clearInterval(interval);
          return resolve(fields);
        }

        const btn = findContinueWithEmailButton();
        if (btn && isElementVisible(btn)) {
          simulateUserClick(btn);
        }

        if (Date.now() - start > timeoutMs) {
          done = true;
          observer.disconnect();
          clearInterval(interval);
          resolve(fields);
        }
      }, 120);
    });
  }

  // Wait for React hydration on landing/sign-up page after reload
  async function waitForLandingOrSignupReady(timeoutMs = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (isStoppedByUser) return false;
      const inputs = findInputsImmediate();
      if (inputs.emailInput) return true;
      if (findMagsimulaButton()) return true;
      if (findContinueWithEmailButton()) return true;
      const mode = detectPageMode();
      if (mode === 'LOGIN' || mode === 'SIGN_UP') return true;
      await new Promise(r => setTimeout(r, 180));
    }
    return false;
  }

  // --- 5. Locate Magpatuloy / Magsimula Submit Button ---
  function findMagpatuloyButton(contextInput) {
    const terms = ['magpatuloy', 'magsimula', 'continue', 'sign up', 'register', 'lumikha', 'submit', 'mag-register'];

    if (contextInput) {
      const container =
        contextInput.closest('form, [role="dialog"], [class*="modal" i], [class*="container" i], [class*="card" i]') ||
        document.body;
      const allButtonsInContainer = Array.from(
        container.querySelectorAll('button, a, [role="button"], input[type="submit"]')
      );

      let followingButtons = allButtonsInContainer;
      if (typeof contextInput.compareDocumentPosition === 'function') {
        try {
          followingButtons = allButtonsInContainer.filter(btn => {
            const pos = contextInput.compareDocumentPosition(btn);
            return (pos & ((typeof Node !== 'undefined' && Node.DOCUMENT_POSITION_FOLLOWING) || 4)) !== 0;
          });
        } catch (e) {
          followingButtons = allButtonsInContainer;
        }
      }

      for (const btn of followingButtons) {
        if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
        const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
        for (const t of terms) {
          if (text === t || text.startsWith(t)) {
            return { element: btn, method: 'following_button_text', term: t };
          }
        }
      }

      for (const btn of allButtonsInContainer) {
        if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
        const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
        for (const t of terms) {
          if (text === t || text.startsWith(t)) {
            return { element: btn, method: 'container_button_text', term: t };
          }
        }
      }
    }

    const allButtons = Array.from(document.querySelectorAll('button, a, [role="button"], input[type="submit"]'));
    for (const el of allButtons) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      for (const t of terms) {
        if (text === t || text.startsWith(t)) {
          return { element: el, method: 'global_button_text', term: t };
        }
      }
    }

    return null;
  }

  // --- 6. Inspect Magpatuloy Validation State ---
  function inspectValidationState(buttonElement) {
    if (!buttonElement) {
      return { found: false, enabled: false, reason: "Could not locate 'Magpatuloy' button on page." };
    }

    const isExplicitlyDisabled = buttonElement.disabled === true;
    const isAriaDisabled = buttonElement.getAttribute('aria-disabled') === 'true';
    const hasClassList = buttonElement.classList && typeof buttonElement.classList.contains === 'function';
    const hasDisabledClass =
      (hasClassList && (buttonElement.classList.contains('disabled') || buttonElement.classList.contains('opacity-50'))) ||
      buttonElement.getAttribute('aria-hidden') === 'true';

    const isDisabled = isExplicitlyDisabled || isAriaDisabled || hasDisabledClass;

    if (isDisabled) {
      const errorElements = Array.from(
        document.querySelectorAll(
          '[role="alert"], [aria-invalid="true"], .error-message, .invalid-feedback, p[class*="error" i], span[class*="error" i]'
        )
      );
      const activeErrors = errorElements
        .filter(el => !isExtensionEl(el) && el.offsetParent !== null)
        .map(el => (el.innerText || el.textContent || '').trim())
        .filter(t => t.length > 0 && t.length < 80);

      const reason =
        activeErrors.length > 0 ? activeErrors.join(' | ') : 'Form inputs have not passed validation checks yet.';

      return {
        found: true,
        enabled: false,
        element: buttonElement,
        reason
      };
    }

    return {
      found: true,
      enabled: true,
      element: buttonElement,
      reason: null
    };
  }

  function highlightField(el) {
    if (!el || !el.style) return;
    const orig = el.style.outline;
    el.style.outline = '2px solid #10b981';
    try {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (e) {}
    setTimeout(() => {
      try {
        el.style.outline = orig;
      } catch (e) {}
    }, 1800);
  }

  function simulateUserClick(element) {
    if (!element) return false;
    try {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (e) {}

    if (element.style) {
      const prevOutline = element.style.outline;
      element.style.outline = '3px solid #10b981';
      setTimeout(() => {
        try {
          element.style.outline = prevOutline;
        } catch (e) {}
      }, 1400);
    }

    let clientX = 0;
    let clientY = 0;
    try {
      const rect = element.getBoundingClientRect();
      clientX = rect.left + rect.width / 2;
      clientY = rect.top + rect.height / 2;
    } catch (e) {}

    try {
      if (typeof Touch !== 'undefined' && typeof TouchEvent !== 'undefined') {
        const touch = new Touch({
          identifier: Date.now(),
          target: element,
          clientX,
          clientY,
          screenX: clientX,
          screenY: clientY,
          pageX: clientX,
          pageY: clientY
        });
        element.dispatchEvent(
          new TouchEvent('touchstart', {
            bubbles: true,
            cancelable: true,
            touches: [touch],
            targetTouches: [touch],
            changedTouches: [touch]
          })
        );
        element.dispatchEvent(
          new TouchEvent('touchend', {
            bubbles: true,
            cancelable: true,
            touches: [],
            targetTouches: [],
            changedTouches: [touch]
          })
        );
      }
    } catch (e) {}

    const pointerEvents = [
      new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX, clientY, pointerType: 'touch' }),
      new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX, clientY }),
      new PointerEvent('pointerup', { bubbles: true, cancelable: true, clientX, clientY, pointerType: 'touch' }),
      new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX, clientY }),
      new MouseEvent('click', { bubbles: true, cancelable: true, clientX, clientY })
    ];

    for (const evt of pointerEvents) {
      try {
        element.dispatchEvent(evt);
      } catch (e) {}
    }

    if (typeof element.click === 'function') {
      try {
        element.click();
      } catch (e) {}
    }

    if (
      element.tagName === 'A' &&
      element.href &&
      element.href !== '#' &&
      !element.href.startsWith('javascript:')
    ) {
      setTimeout(() => {
        if (window.location.href !== element.href) {
          window.location.href = element.href;
        }
      }, 300);
    }
    return true;
  }

  function findMagsimulaButton() {
    // Direct hero link / utm_content check
    const heroLink = document.querySelector('a[href*="utm_content=homepage_hero"], a[href*="/auth?mode=signup"]');
    if (heroLink && !isExtensionEl(heroLink) && isElementVisible(heroLink)) {
      return { element: heroLink, text: (heroLink.innerText || heroLink.textContent || 'Magsimulang matuto').trim() };
    }

    const terms = [
      'magsimulang matuto',
      'magsimula',
      'magsimula na',
      'magsimula nang libre',
      'mag-register',
      'mag-sign up',
      'sign up',
      'simulan',
      'simulan ngayon',
      'get started',
      'start',
      'create account',
      'lumikha ng account',
      'register'
    ];
    const candidates = Array.from(document.querySelectorAll("button, a, [role='button'], div, span"));

    for (const el of candidates) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (
        text === 'magsimula' ||
        text === 'magsimula na' ||
        text === 'simulan' ||
        text === 'magsimula nang libre' ||
        text.includes('magsimulang matuto') ||
        text.includes('magsimula')
      ) {
        const clickable = el.closest("button, a, [role='button']") || el;
        if (!isExtensionEl(clickable)) {
          return { element: clickable, text };
        }
      }
    }

    if (typeof NodeFilter !== 'undefined' && document.createTreeWalker && document.body) {
      try {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        let node;
        while ((node = walker.nextNode())) {
          const val = (node.nodeValue || '').trim().toLowerCase();
          if (val === 'magsimula' || val === 'magsimula na' || val === 'magsimula nang libre') {
            const parent = node.parentElement;
            if (parent && isElementVisible(parent) && !isExtensionEl(parent)) {
              const clickable = parent.closest("button, a, [role='button']") || parent;
              if (!isExtensionEl(clickable)) {
                return { element: clickable, text: val };
              }
            }
          }
        }
      } catch (e) {}
    }

    for (const el of candidates) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (
        text.includes('all-in-one') ||
        text.includes('clear cookies') ||
        text.includes('menu') ||
        text.includes('set default') ||
        text.includes('assistant') ||
        text.includes('rotate') ||
        text.includes('stop')
      ) {
        continue;
      }

      if (text.includes('magsimula')) {
        const clickable = el.closest("button, a, [role='button']") || el;
        if (!isExtensionEl(clickable)) {
          return { element: clickable, text };
        }
      }

      for (const t of terms) {
        if (text === t || text.startsWith(t)) {
          const clickable = el.closest("button, a, [role='button']") || el;
          if (!isExtensionEl(clickable)) {
            return { element: clickable, text };
          }
        }
      }
    }

    const linkCandidates = Array.from(
      document.querySelectorAll(
        "a[href*='signup' i], a[href*='register' i], a[href*='auth' i], button[data-testid*='signup' i], button[data-testid*='register' i], [role='button'][data-testid*='signup' i]"
      )
    );
    for (const el of linkCandidates) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const clickable = el.closest("button, a, [role='button']") || el;
      if (!isExtensionEl(clickable)) {
        return { element: clickable, text: (el.innerText || 'Registration Link').trim() };
      }
    }

    return null;
  }

  function performMagsimulaAction() {
    const match = findMagsimulaButton();
    if (match) {
      simulateUserClick(match.element);
      showFloatingToast('Clicked: ' + match.text);
      return { found: true, text: match.text };
    }
    return { found: false, message: 'Magsimula button not found' };
  }

  function showFloatingToast(msg) {
    if (!document.body) return;
    let toast = document.getElementById('knowunity-helper-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'knowunity-helper-toast';
      toast.className = 'kn-ext-element';
      toast.style.cssText = [
        'position:fixed',
        'bottom:88px',
        'left:50%',
        'transform:translateX(-50%)',
        'background:rgba(15, 23, 42, 0.94)',
        'color:#f8fafc',
        'padding:10px 18px',
        'border-radius:99px',
        'border:1px solid rgba(148, 163, 184, 0.35)',
        'font-family:Inter,system-ui,-apple-system,sans-serif',
        'font-size:12px',
        'font-weight:700',
        'z-index:2147483647',
        'box-shadow:0 12px 28px rgba(15, 23, 42, 0.4)',
        'backdrop-filter:blur(12px)',
        '-webkit-backdrop-filter:blur(12px)',
        'transition:opacity 0.22s, transform 0.22s',
        'pointer-events:none',
        'max-width:90vw',
        'text-align:center'
      ].join(';');
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
    clearTimeout(toast.__timer);
    toast.__timer = setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(10px)';
    }, 3200);
  }

  // --- 7. Locate Top-Right Referral / Friends Button ---
  // DEEP FIX: Multi-strategy, URL-aware, with full console diagnostics
  function findTopRightReferralButton() {
    const path = window.location.pathname.toLowerCase();
    const fullBody = getSiteBodyText();

    // Strategy 1: Exact aria-label from Knowunity's compiled chunk
    // The button renders as: aria-label="Maglagay ng referral code" (Filipino) or "Enter a referral code" (English)
    const REFERRAL_ARIA_LABELS = [
      'maglagay ng referral code',
      'enter a referral code',
      'enter referral code',
      'add referral code',
      'referral code',
      'i-enter ang referral code',
      'referral',
      'kodigo ng referral'
    ];

    for (const label of REFERRAL_ARIA_LABELS) {
      const el = document.querySelector(`[aria-label*="${label}" i]`);
      if (el && !isExtensionEl(el)) {
        console.log('[KN-EXT] findTopRightReferralButton: Found by aria-label:', label, el);
        return el;
      }
    }

    // Strategy 2: data-testid or data-cy attributes referencing referral
    const testIdEl = document.querySelector(
      '[data-testid*="referral" i], [data-cy*="referral" i], [data-id*="referral" i], [id*="referral" i]'
    );
    if (testIdEl && !isExtensionEl(testIdEl)) {
      const btn = testIdEl.closest('button, a, [role="button"]') || testIdEl;
      if (!isExtensionEl(btn)) {
        console.log('[KN-EXT] findTopRightReferralButton: Found by data-testid/id:', btn);
        return btn;
      }
    }

    // Never fall back to generic top-right SVG heuristics on /auth, /login, or /signup pages
    const isAuthRoute =
      path.includes('/auth') || path.includes('/login') || path.includes('/signup') || path.includes('/register');

    const allButtons = Array.from(
      document.querySelectorAll(
        "header button, nav button, [class*='header' i] button, [class*='nav' i] button, [class*='toolbar' i] button, [class*='topbar' i] button, button, [role='button']"
      )
    );

    if (!isAuthRoute) {
      for (const el of allButtons) {
        if (isExtensionEl(el)) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) continue;

        const isInTopArea = rect.top < 160;
        const isInRightSide = rect.right > window.innerWidth * 0.4;
        const hasSvg = !!el.querySelector('svg');
        const aria = (el.getAttribute('aria-label') || '').toLowerCase();
        const title = (el.getAttribute('title') || '').toLowerCase();
        const cls = (el.className || '').toString().toLowerCase();

        // Skip obvious non-referral buttons
        if (
          aria.includes('menu') || aria.includes('close') || aria.includes('back') || aria.includes('notification') ||
          aria.includes('password') || aria.includes('show') || aria.includes('hide') ||
          title.includes('menu') || title.includes('close') || title.includes('back') ||
          cls.includes('hamburger') || cls.includes('close') || cls.includes('back')
        ) continue;

        const isReferralRelated =
          aria.includes('referral') || aria.includes('gift') || aria.includes('regalo') ||
          aria.includes('friend') || aria.includes('kaibigan') || aria.includes('invite') ||
          aria.includes('imbita') || aria.includes('ticket') || aria.includes('voucher') ||
          aria.includes('kodigo') || aria.includes('code') ||
          title.includes('referral') || title.includes('gift') || title.includes('code') ||
          cls.includes('referral') || cls.includes('gift') || cls.includes('ticket');

        if (isInTopArea && isInRightSide && isReferralRelated) {
          console.log('[KN-EXT] findTopRightReferralButton: Found referral-related top button:', el);
          return el;
        }

        // During onboarding: gift/ticket/person SVG icon buttons in top-bar that aren't back/close
        if (isInTopArea && isInRightSide && hasSvg && !cls.includes('nav') && !aria.includes('back') && !aria.includes('close')) {
          if (rect.width <= 68 && rect.height <= 68 && rect.width >= 16 && rect.height >= 16) {
            console.log('[KN-EXT] findTopRightReferralButton: Found SVG icon button in top-right area:', el);
            return el;
          }
        }
      }
    }

    // Strategy 4: Text-based lookup — any visible element saying "May referral code ka ba?" or similar CTA
    const textElements = Array.from(document.querySelectorAll("button, a, [role='button'], span, p, div"));
    for (const el of textElements) {
      if (isExtensionEl(el)) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (
        (txt.includes('may referral code') || txt.includes('enter referral') || txt.includes('referral code') ||
         txt.includes('may code') || txt.includes('maglagay ng referral') || txt.includes('ilagay ang referral')) &&
        !txt.includes('i-apply') && !txt.includes('i apply') && txt.length < 80
      ) {
        const candidate = el.closest("button, a, [role='button']") || el;
        if (!isExtensionEl(candidate)) {
          console.log('[KN-EXT] findTopRightReferralButton: Found by text content:', txt, candidate);
          return candidate;
        }
      }
    }

    return null;
  }

  // Helper to advance intermediate onboarding steps if the top-right referral button isn't on the first step
  function findOnboardingIntermediateStepButton() {
    const path = window.location.pathname.toLowerCase();
    if (!path.includes('/onboarding') && !path.includes('/app')) return null;

    // Do not click if referral modal is already open
    if (document.querySelector('[role="dialog"][aria-modal="true"], div[class*="cursor-text"] input')) return null;

    const stepTerms = [
      'tara na',
      "let's go",
      'lets go',
      'simulan na',
      'magpatuloy',
      'continue',
      'next',
      'susunod'
    ];

    const buttons = Array.from(document.querySelectorAll("button, [role='button'], a[role='button']"));
    for (const btn of buttons) {
      if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
      if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') continue;
      const txt = (btn.innerText || btn.textContent || '').trim().toLowerCase();
      for (const t of stepTerms) {
        if (txt === t || txt.startsWith(t)) {
          return btn;
        }
      }
    }
    return null;
  }

  // --- 8. Master 6-Box Referral Filler (Strictly excludes extension inputs) ---
  async function fillSixBoxReferralCode(cleanCode) {
    cleanCode = (cleanCode || 'NM3G4X').trim().toUpperCase();

    // Priority 1: Check for Knowunity's Referral Modal or 6-box cursor-text overlay input (opacity-0)
    const modal = document.querySelector('[role="dialog"][aria-modal="true"], div[class*="rounded-3xl"]');
    const container = modal || document;
    const modalInput = container.querySelector(
      'div[class*="cursor-text"] input, input[autoCapitalize="characters"], [role="dialog"] input[type="text"], [role="dialog"] input:not([type="hidden"])'
    );

    if (modalInput && !isExtensionEl(modalInput)) {
      const boxWrapper = modalInput.closest('div[class*="cursor-text"]');
      if (boxWrapper) {
        try { boxWrapper.click(); } catch (e) {}
      }
      modalInput.focus();
      setFrameworkInputValue(modalInput, cleanCode);
      highlightField(modalInput);

      for (let i = 0; i < cleanCode.length; i++) {
        const char = cleanCode[i];
        const keyCode = char.charCodeAt(0);
        modalInput.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: 'Key' + char, keyCode, bubbles: true }));
        modalInput.dispatchEvent(new KeyboardEvent('keypress', { key: char, code: 'Key' + char, keyCode, bubbles: true }));
        modalInput.dispatchEvent(new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true, composed: true }));
        modalInput.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: 'Key' + char, keyCode, bubbles: true }));
      }
      modalInput.dispatchEvent(new Event('input', { bubbles: true }));
      modalInput.dispatchEvent(new Event('change', { bubbles: true }));

      showFloatingToast(`Filled referral code "${cleanCode}"!`);
      return true;
    }

    const allInputs = Array.from(document.querySelectorAll("input:not([type='hidden'])")).filter(
      el => !isExtensionEl(el)
    );
    const singleCharInputs = allInputs.filter(el => {
      const ml = el.getAttribute('maxlength') || el.maxLength;
      return ml === 1 || ml === '1' || el.size === 1;
    });

    if (singleCharInputs.length >= 6) {
      for (let i = 0; i < 6; i++) {
        if (isStoppedByUser) return false;
        const box = singleCharInputs[i];
        const char = cleanCode[i] || '';
        box.focus();
        setFrameworkInputValue(box, char);
        highlightField(box);
        box.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: 'Key' + char, bubbles: true }));
        box.dispatchEvent(new KeyboardEvent('keypress', { key: char, code: 'Key' + char, bubbles: true }));
        box.dispatchEvent(
          new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true, composed: true })
        );
        box.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: 'Key' + char, bubbles: true }));
        box.dispatchEvent(new Event('change', { bubbles: true }));
        await new Promise(r => setTimeout(r, 55));
      }
      showFloatingToast(`Filled 6-box referral code "${cleanCode}"!`);
      return true;
    }

    const otpInputs = allInputs.filter(el => {
      const ml = el.getAttribute('maxlength') || el.maxLength;
      const name = (el.name || '').toLowerCase();
      const testid = (el.getAttribute('data-testid') || '').toLowerCase();
      const cls = (el.className || '').toLowerCase();
      return (
        ml === 6 ||
        ml === '6' ||
        el.getAttribute('autocomplete') === 'one-time-code' ||
        name.includes('code') ||
        name.includes('referral') ||
        name.includes('otp') ||
        testid.includes('code') ||
        testid.includes('otp') ||
        cls.includes('otp')
      );
    });

    const targetInput = otpInputs[0] || (allInputs.length === 1 ? allInputs[0] : null);

    if (targetInput) {
      targetInput.focus();
      setFrameworkInputValue(targetInput, cleanCode);
      highlightField(targetInput);

      for (const char of cleanCode) {
        targetInput.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: 'Key' + char, bubbles: true }));
        targetInput.dispatchEvent(
          new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true, composed: true })
        );
        targetInput.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: 'Key' + char, bubbles: true }));
      }
      targetInput.dispatchEvent(new Event('change', { bubbles: true }));

      try {
        const dt = new DataTransfer();
        dt.setData('text/plain', cleanCode);
        const pasteEvt = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: dt
        });
        targetInput.dispatchEvent(pasteEvt);
      } catch (e) {}

      showFloatingToast(`Filled referral code "${cleanCode}" into input!`);
      return true;
    }

    if (
      document.activeElement &&
      document.activeElement.tagName === 'INPUT' &&
      !isExtensionEl(document.activeElement)
    ) {
      const active = document.activeElement;
      setFrameworkInputValue(active, cleanCode);
      active.dispatchEvent(
        new InputEvent('input', { data: cleanCode, inputType: 'insertText', bubbles: true, composed: true })
      );
      active.dispatchEvent(new Event('change', { bubbles: true }));
      showFloatingToast(`Filled referral code "${cleanCode}" into active input!`);
      return true;
    }

    const visualBoxes = Array.from(
      document.querySelectorAll(
        "[class*='box' i], [class*='slot' i], [class*='digit' i], [class*='cell' i], [class*='char' i]"
      )
    ).filter(el => !isExtensionEl(el) && isElementVisible(el));
    if (visualBoxes.length >= 6) {
      simulateUserClick(visualBoxes[0]);
      await new Promise(r => setTimeout(r, 150));

      const activeAfterClick = document.activeElement;
      if (activeAfterClick && activeAfterClick.tagName === 'INPUT' && !isExtensionEl(activeAfterClick)) {
        setFrameworkInputValue(activeAfterClick, cleanCode);
        activeAfterClick.dispatchEvent(
          new InputEvent('input', { data: cleanCode, inputType: 'insertText', bubbles: true, composed: true })
        );
        activeAfterClick.dispatchEvent(new Event('change', { bubbles: true }));
        showFloatingToast(`Filled referral code "${cleanCode}"!`);
        return true;
      }
    }

    try {
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: new DataTransfer()
      });
      pasteEvent.clipboardData.setData('text/plain', cleanCode);
      const target =
        document.activeElement && !isExtensionEl(document.activeElement) ? document.activeElement : document.body;
      target.dispatchEvent(pasteEvent);
    } catch (e) {}

    showFloatingToast(`Filled 6-box referral code "${cleanCode}"!`);
    return true;
  }

  // --- 9. Persistent "I-apply ang code" Trigger Engine ---
  async function triggerApplyCodeButton(maxAttempts = 15) {
    const exactTerms = [
      'i-apply ang code',
      'i apply ang code',
      'i-apply',
      'i apply',
      'apply ang code',
      'apply code',
      'i-redeem',
      'redeem',
      'gamitin ang code',
      'gamitin'
    ];

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

      const buttonElements = Array.from(
        document.querySelectorAll("button, [role='button'], input[type='submit'], input[type='button'], a[role='button']")
      );
      let applyBtn = null;

      for (const btn of buttonElements) {
        if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
        const txt = (
          btn.innerText ||
          btn.textContent ||
          btn.value ||
          btn.getAttribute('aria-label') ||
          ''
        )
          .trim()
          .toLowerCase();
        for (const t of exactTerms) {
          if (txt === t || txt.startsWith(t)) {
            applyBtn = btn;
            break;
          }
        }
        if (applyBtn) break;
      }

      if (!applyBtn) {
        for (const btn of buttonElements) {
          if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
          const txt = (
            btn.innerText ||
            btn.textContent ||
            btn.value ||
            btn.getAttribute('aria-label') ||
            ''
          )
            .trim()
            .toLowerCase();
          if (
            txt.includes('i-apply') ||
            txt.includes('apply code') ||
            txt.includes('gamitin ang code') ||
            (txt.includes('apply') && !txt.includes('terms'))
          ) {
            applyBtn = btn;
            break;
          }
        }
      }

      if (!applyBtn) {
        const textElements = Array.from(document.querySelectorAll('span, p, b, strong, div')).filter(
          el => !isExtensionEl(el) && isElementVisible(el)
        );
        for (const el of textElements) {
          const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
          for (const t of exactTerms) {
            if (txt === t || txt.startsWith(t)) {
              const clickable = el.closest("button, [role='button'], a, [class*='btn' i], [class*='button' i]");
              if (clickable && !isExtensionEl(clickable)) {
                applyBtn = clickable;
                break;
              }
            }
          }
          if (applyBtn) break;
        }
      }

      if (applyBtn) {
        // Wait if async validation spinner is running and button is disabled (for first 8 attempts)
        const isDisabled = applyBtn.disabled || applyBtn.getAttribute('aria-disabled') === 'true' || applyBtn.classList.contains('opacity-50');
        if (isDisabled && attempt <= 8) {
          console.log('[KN-EXT] triggerApplyCodeButton: Apply button found but disabled (validating code...), waiting... attempt', attempt);
          await new Promise(r => setTimeout(r, 320));
          continue;
        }

        applyBtn.classList.remove('pointer-events-none', 'opacity-50', 'disabled');
        applyBtn.style.pointerEvents = 'auto';
        applyBtn.removeAttribute('disabled');
        applyBtn.removeAttribute('aria-disabled');
        applyBtn.disabled = false;

        highlightField(applyBtn);
        simulateUserClick(applyBtn);
        if (typeof applyBtn.click === 'function') {
          try {
            applyBtn.click();
          } catch (e) {}
        }

        if (applyBtn.form) {
          try {
            if (typeof applyBtn.form.requestSubmit === 'function') {
              applyBtn.form.requestSubmit();
            } else {
              applyBtn.form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
            }
          } catch (e) {}
        }

        await new Promise(r => setTimeout(r, 380));
        const bodyTxt = getSiteBodyText();
        const modalClosed =
          !bodyTxt.includes('may referral code ka ba') && !bodyTxt.includes('ilagay ang referral code');
        const taposAppeared =
          bodyTxt.includes('tapos na') || bodyTxt.includes('tagumpay') || !!findTaposNaButtonCandidate();

        if (modalClosed || taposAppeared) {
          showFloatingToast('"I-apply ang code" clicked and confirmed!');
          return { success: true, attempts: attempt, message: '"I-apply ang code" triggered successfully!' };
        }
      }

      await new Promise(r => setTimeout(r, 280));
    }

    return { success: true, message: 'Completed apply code trigger attempts.' };
  }

  // --- 9b. Dedicated "Tapos na" Confirmation Click Engine ---
  function findTaposNaButtonCandidate() {
    const terms = [
      'tapos na',
      'tapos',
      'tapusin',
      'done',
      'finish',
      'sige na',
      'sige',
      'ok',
      'okay',
      'tagumpay',
      'got it',
      'naintindihan'
    ];

    // Check directly inside referral modal
    const modal = document.querySelector('[role="dialog"][aria-modal="true"], div[class*="rounded-3xl"]');
    if (modal) {
      const modalBtns = Array.from(modal.querySelectorAll('button:not([aria-label*="close" i])')).filter(
        b => !isExtensionEl(b) && isElementVisible(b)
      );
      for (const btn of modalBtns) {
        const txt = (btn.innerText || btn.textContent || '').trim().toLowerCase();
        for (const t of terms) {
          if (txt === t || txt.startsWith(t)) return btn;
        }
      }
    }

    const buttonElements = Array.from(
      document.querySelectorAll(
        "button, a, [role='button'], input[type='button'], input[type='submit'], div[role='button']"
      )
    );
    for (const btn of buttonElements) {
      if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
      const txt = (
        btn.innerText ||
        btn.textContent ||
        btn.value ||
        btn.getAttribute('aria-label') ||
        ''
      )
        .trim()
        .toLowerCase();
      for (const t of terms) {
        if (txt === t || txt.startsWith(t)) {
          return btn;
        }
      }
    }

    for (const btn of buttonElements) {
      if (isExtensionEl(btn) || !isElementVisible(btn)) continue;
      const txt = (
        btn.innerText ||
        btn.textContent ||
        btn.value ||
        btn.getAttribute('aria-label') ||
        ''
      )
        .trim()
        .toLowerCase();
      if (txt.includes('tapos na') || txt.includes('tapos') || txt === 'done' || txt === 'ok') {
        return btn;
      }
    }

    const textElements = Array.from(document.querySelectorAll('span, p, div, b, strong, h3, h4'));
    for (const el of textElements) {
      if (isExtensionEl(el) || !isElementVisible(el)) continue;
      const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
      for (const t of terms) {
        if (txt === t || txt.startsWith(t)) {
          const clickable = el.closest(
            "button, a, [role='button'], [class*='btn' i], [class*='button' i], [class*='cursor-pointer' i]"
          );
          if (clickable && !isExtensionEl(clickable) && isElementVisible(clickable)) {
            return clickable;
          }
        }
      }
    }

    return null;
  }

  function clickTaposNaElement(taposBtn) {
    if (!taposBtn) return false;

    taposBtn.classList.remove('pointer-events-none', 'disabled', 'opacity-50');
    taposBtn.style.pointerEvents = 'auto';
    taposBtn.removeAttribute('disabled');
    taposBtn.removeAttribute('aria-disabled');
    taposBtn.disabled = false;

    highlightField(taposBtn);
    simulateUserClick(taposBtn);
    if (typeof taposBtn.click === 'function') {
      try {
        taposBtn.click();
      } catch (e) {}
    }

    showFloatingToast('"Tapos na" button clicked immediately!');
    return true;
  }

  async function triggerTaposNaButton(maxWaitMs = 8000) {
    if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

    const immediateBtn = findTaposNaButtonCandidate();
    if (immediateBtn) {
      clickTaposNaElement(immediateBtn);
      return { success: true, message: '"Tapos na" button clicked immediately!' };
    }

    return new Promise((resolve) => {
      let isDone = false;
      const startTime = Date.now();
      let observer = null;
      let intervalId = null;

      function finish(success, msg) {
        if (isDone) return;
        isDone = true;
        if (observer) {
          try {
            observer.disconnect();
          } catch (e) {}
        }
        if (intervalId) {
          clearInterval(intervalId);
        }
        resolve({ success, message: msg });
      }

      function checkNow() {
        if (isDone) return;
        if (isStoppedByUser) {
          finish(false, 'Stopped by user.');
          return;
        }
        const btn = findTaposNaButtonCandidate();
        if (btn) {
          clickTaposNaElement(btn);
          finish(true, '"Tapos na" button clicked immediately!');
          return;
        }
        if (Date.now() - startTime >= maxWaitMs) {
          finish(false, '"Tapos na" button not found within timeout.');
        }
      }

      try {
        observer = new MutationObserver(() => {
          checkNow();
        });
        observer.observe(document.body || document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['disabled', 'class', 'style']
        });
      } catch (e) {}

      intervalId = setInterval(checkNow, 40);

      setTimeout(() => {
        checkNow();
        if (!isDone) finish(false, '"Tapos na" button not found within timeout.');
      }, maxWaitMs);
    });
  }

  // --- 10. Complete Referral Automation: Open, Fill 6-Boxes, Click I-apply, Click Tapos Na ---
  async function applyReferralCodeOnPage(code = 'NM3G4X', autoOpen = true) {
    if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

    const cleanCode = (code || 'NM3G4X').trim().toUpperCase();
    showFloatingToast(`Locating referral section for "${cleanCode}"...`);

    // Pre-seed storage so if modal opens with initialCode, it's already populated
    try {
      window.sessionStorage.setItem('referral_prefill_code', cleanCode);
      window.localStorage.setItem('referral_prefill_code', cleanCode);
    } catch (e) {}

    const isModalOpen = () => {
      const fullText = getSiteBodyText();
      return (
        fullText.includes('may referral code ka ba') ||
        fullText.includes('ilagay ang referral code') ||
        fullText.includes('do you have a referral code') ||
        fullText.includes('enter a referral code to receive') ||
        !!document.querySelector('[role="dialog"][aria-modal="true"]') ||
        !!document.querySelector('div[class*="cursor-text"] input')
      );
    };

    // Wait up to 12 seconds for either the referral modal or the top-right referral button to appear
    const findStart = Date.now();
    let clickedStepOnce = false;
    while (!isModalOpen() && Date.now() - findStart < 12000) {
      if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

      const openTrigger = findTopRightReferralButton();
      if (openTrigger && autoOpen) {
        console.log('[KN-EXT] applyReferralCodeOnPage: Clicking top-right referral trigger:', openTrigger);
        try {
          openTrigger.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch (e) {}
        highlightField(openTrigger);
        simulateUserClick(openTrigger);
        if (typeof openTrigger.click === 'function') {
          try { openTrigger.click(); } catch (e) {}
        }
        showFloatingToast('Opening referral dialog...');
        await new Promise(r => setTimeout(r, 650));
        if (isModalOpen()) break;
      } else if (!clickedStepOnce && Date.now() - findStart > 2200) {
        // On some onboarding screens ("knowieWelcome"), the referral button is hidden until clicking "Tara na"
        const stepBtn = findOnboardingIntermediateStepButton();
        if (stepBtn) {
          console.log('[KN-EXT] applyReferralCodeOnPage: Clicking intermediate onboarding button to reveal referral top-bar:', stepBtn);
          clickedStepOnce = true;
          simulateUserClick(stepBtn);
          if (typeof stepBtn.click === 'function') {
            try { stepBtn.click(); } catch (e) {}
          }
          await new Promise(r => setTimeout(r, 700));
        }
      }
      await new Promise(r => setTimeout(r, 250));
    }

    if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

    // Wait briefly for the input inside the modal to mount
    for (let w = 0; w < 10; w++) {
      if (document.querySelector('div[class*="cursor-text"] input, [role="dialog"] input')) break;
      await new Promise(r => setTimeout(r, 150));
    }

    // Step C: Fill the 6 boxes
    await fillSixBoxReferralCode(cleanCode);

    // Wait 0.45s so Knowunity's async code validation API finishes and enables the Apply button
    showFloatingToast('Validating code before clicking apply...');
    await new Promise(r => setTimeout(r, 450));

    if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

    // Step D: Click "I-apply ang code" (20 attempts = up to ~6 seconds)
    const clickRes = await triggerApplyCodeButton(20);

    if (isStoppedByUser) return { success: false, message: 'Stopped by user.' };

    // Step E: Immediately click "Tapos na"
    const taposRes = await triggerTaposNaButton(8000);

    return {
      success: clickRes.success || taposRes.success,
      buttonClicked: clickRes.success,
      taposClicked: taposRes.success,
      referralCodeUsed: cleanCode,
      message: taposRes.success
        ? `Referral code "${cleanCode}" applied and "Tapos na" clicked!`
        : clickRes.success
        ? `Referral code "${cleanCode}" filled and "I-apply ang code" clicked!`
        : `Referral code "${cleanCode}" filled into 6-box section!`
    };
  }

  // --- 11. Full Autofill, Agreement Toggle, Button Click & Chained Referral + Continuous Loop ---
  async function autofillRegistrationForm(email, password, referralCode = 'NM3G4X', options = {}) {
    if (
      !window.location.hostname.includes('knowunity.ph') &&
      !window.location.hostname.includes('knowunity.com')
    ) {
      return {
        success: false,
        message: 'Autofill only allowed on supported Knowunity registration domains.'
      };
    }

    if (isStoppedByUser) {
      return { success: false, message: 'Workflow stopped by user.' };
    }

    let mode = detectPageMode();
    if (mode === 'LOGIN') {
      showFloatingToast('Login mode detected. Switching to Sign Up...');
      const switchRes = await switchToSignUp();
      if (!switchRes.success) {
        return { success: false, message: switchRes.message };
      }
      mode = detectPageMode();
    }

    const { emailInput, passwordInput } = await waitForInputs(6000);

    if (!emailInput) {
      return {
        success: false,
        message:
          'No visible registration fields found. Please ensure the registration/sign-up form is open on Knowunity.'
      };
    }

    let emailSet = false;
    let passwordSet = false;

    if (emailInput && email) {
      emailSet = setFrameworkInputValue(emailInput, email);
      highlightField(emailInput);
    }

    if (passwordInput && password) {
      passwordSet = setFrameworkInputValue(passwordInput, password);
      highlightField(passwordInput);
    }

    const form =
      (emailInput && emailInput.closest('form, [role="dialog"], [class*="modal" i]')) || document;
    const checkboxes = Array.from(form.querySelectorAll('input[type="checkbox"]')).filter(
      cb => !isExtensionEl(cb)
    );
    let checkboxToggled = false;
    for (const cb of checkboxes) {
      if (!cb.checked && isElementVisible(cb)) {
        cb.checked = true;
        cb.dispatchEvent(new Event('input', { bubbles: true }));
        cb.dispatchEvent(new Event('change', { bubbles: true }));
        simulateUserClick(cb);
        checkboxToggled = true;
      }
    }

    await new Promise(r => setTimeout(r, 200));

    const cleanReferralCode =
      referralCode && typeof referralCode === 'string' && referralCode.trim()
        ? referralCode.trim().toUpperCase()
        : 'NM3G4X';

    try {
      await chrome.storage.local.set({
        masterWorkflowActive: true,
        workflowStartTime: Date.now(),
        workflowStep: 'REFERRAL_STEP',
        activeEmail: email,
        activePassword: password,
        referralCode: cleanReferralCode
      });
    } catch (e) {}

    const magpatuloyMatch = findMagpatuloyButton(emailInput || passwordInput);
    const magpatuloyBtn = magpatuloyMatch ? magpatuloyMatch.element : null;
    inspectValidationState(magpatuloyBtn);

    let buttonClicked = false;
    if (magpatuloyBtn) {
      try {
        magpatuloyBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } catch (e) {}
      try {
        simulateUserClick(magpatuloyBtn);
        if (typeof magpatuloyBtn.click === 'function') {
          magpatuloyBtn.click();
        }
        buttonClicked = true;
        showFloatingToast('Form filled, agreement toggled, and button clicked!');
      } catch (err) {}
    }

    await new Promise(r => setTimeout(r, 600));
    if (isStoppedByUser) return { success: false, message: 'Workflow stopped by user.' };

    const postInputs = findInputsImmediate();
    if (postInputs.passwordInput && isElementVisible(postInputs.passwordInput)) {
      setFrameworkInputValue(postInputs.passwordInput, password);
      highlightField(postInputs.passwordInput);
      passwordSet = true;

      const nextBtn = findMagpatuloyButton(postInputs.passwordInput);
      if (nextBtn && nextBtn.element) {
        simulateUserClick(nextBtn.element);
      }
    }

    let referralResult = null;
    showFloatingToast('Advancing to referral screen for "' + cleanReferralCode + '"...');

    const pollStart = Date.now();
    let referralHandled = false;
    let intermediateClicked = false;

    while (Date.now() - pollStart < 18000) {
      if (isStoppedByUser) return { success: false, message: 'Workflow stopped by user.' };
      const fullTxt = getSiteBodyText();
      const hasModal =
        fullTxt.includes('may referral code ka ba') ||
        fullTxt.includes('ilagay ang referral code') ||
        fullTxt.includes('do you have a referral code') ||
        !!document.querySelector('[role="dialog"][aria-modal="true"]');
      const hasTopRightBtn = !!findTopRightReferralButton();

      if (hasModal || hasTopRightBtn) {
        await new Promise(r => setTimeout(r, 450));
        referralResult = await applyReferralCodeOnPage(cleanReferralCode, true);
        referralHandled = true;
        break;
      }

      // If we navigated to /app/onboarding and are on a welcome screen without the top-bar button yet, click "Tara na" / "Magpatuloy"
      const currentPath = window.location.pathname.toLowerCase();
      if (!intermediateClicked && (currentPath.includes('/onboarding') || currentPath.includes('/app')) && Date.now() - pollStart > 2500) {
        const stepBtn = findOnboardingIntermediateStepButton();
        if (stepBtn) {
          console.log('[KN-EXT] autofillRegistrationForm: Advancing onboarding step to reveal referral button:', stepBtn);
          intermediateClicked = true;
          simulateUserClick(stepBtn);
          if (typeof stepBtn.click === 'function') {
            try { stepBtn.click(); } catch (e) {}
          }
        }
      }

      await new Promise(r => setTimeout(r, 350));
    }

    if (!referralHandled && !isStoppedByUser) {
      referralResult = await applyReferralCodeOnPage(cleanReferralCode, true);
      referralHandled = true;
    }

    // If referral + Tapos Na finished and not called from inside executeOnPageWorkflow (e.g. called from Popup or auto-resume),
    // trigger the automatic Clear Cookie -> Back to Sign Up Landing Page -> Start Sign Up Again loop!
    if (referralHandled && !options.handledByCallerLoop && !isStoppedByUser) {
      await triggerNextRotationCycleIfActive();
    }

    return {
      success: true,
      pageMode: mode,
      emailSet,
      passwordSet,
      checkboxToggled,
      buttonClicked,
      referralCodeUsed: cleanReferralCode,
      referralResult,
      message:
        referralResult && referralResult.success
          ? `Magsimula complete! ${referralResult.message}`
          : 'Credentials populated, button clicked, and referral sequence finished!'
    };
  }

  // --- Helper Generators & Rotation Pool Logic ---
  function getFreshEmail(domain = 'gmail.com') {
    if (typeof EmailGenerator !== 'undefined' && EmailGenerator.generateEmail) {
      const res = EmailGenerator.generateEmail(domain || 'gmail.com');
      if (res && res.success && res.email) return res.email;
    }
    const rand = Math.random().toString(36).substring(2, 9);
    return `student_${rand}_${Date.now().toString().slice(-4)}@${domain || 'gmail.com'}`;
  }

  function getPersistentPassword(savedPassword) {
    if (savedPassword && typeof savedPassword === 'string' && savedPassword.length >= 8) {
      return savedPassword;
    }
    if (typeof PasswordGenerator !== 'undefined' && PasswordGenerator.generatePassword) {
      return PasswordGenerator.generatePassword(14);
    }
    return 'P@ssw0rd' + Math.floor(Math.random() * 9000 + 1000) + '!';
  }

  function parseReferralPool(rawPool, fallbackDefault = 'NM3G4X') {
    if (Array.isArray(rawPool)) {
      const cleaned = rawPool
        .map(c => String(c || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))
        .filter(c => c.length >= 4);
      return cleaned.length > 0 ? cleaned : [fallbackDefault];
    }
    if (typeof rawPool === 'string' && rawPool.trim()) {
      const cleaned = rawPool
        .split(/[\s,;]+/)
        .map(c => c.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))
        .filter(c => c.length >= 4);
      return cleaned.length > 0 ? cleaned : [fallbackDefault];
    }
    return [fallbackDefault];
  }

  async function resolveNextRotationState(explicitCode = null) {
    const data = await new Promise(r =>
      chrome.storage.local.get(
        [
          'defaultReferralCode',
          'lastReferralCode',
          'referralRotationPool',
          'rotationIndex',
          'rotationCycleCount',
          'autoClearOnStart',
          'autoRotateLoop',
          'rotationLoopActive',
          'lastGeneratedPassword',
          'selectedDomain'
        ],
        r
      )
    );

    const defaultCode = (data && data.defaultReferralCode) || 'NM3G4X';
    const pool = parseReferralPool(data && data.referralRotationPool, defaultCode);
    let idx = parseInt((data && data.rotationIndex) || 0, 10);
    if (isNaN(idx) || idx < 0) idx = 0;

    let selectedCode;
    let nextIdx = idx;

    if (explicitCode && typeof explicitCode === 'string' && explicitCode.trim()) {
      const cleanExplicit = explicitCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
      if (pool.length > 1 && cleanExplicit === defaultCode) {
        selectedCode = pool[idx % pool.length];
        nextIdx = (idx + 1) % pool.length;
      } else {
        selectedCode = cleanExplicit || defaultCode;
        nextIdx = (idx + 1) % pool.length;
      }
    } else {
      selectedCode = pool[idx % pool.length] || defaultCode;
      nextIdx = (idx + 1) % pool.length;
    }

    const cycleCount = (parseInt((data && data.rotationCycleCount) || 0, 10) || 0) + 1;
    const autoClearOnStart = data && typeof data.autoClearOnStart === 'boolean' ? data.autoClearOnStart : true;
    // Continuous rotation loop is ON by default unless explicitly disabled by user!
    const autoRotateLoop = data && typeof data.autoRotateLoop === 'boolean' ? data.autoRotateLoop : true;
    const domain = (data && data.selectedDomain) || 'gmail.com';
    const password = getPersistentPassword(data && data.lastGeneratedPassword);

    await chrome.storage.local.set({
      rotationIndex: nextIdx,
      rotationCycleCount: cycleCount,
      lastReferralCode: selectedCode,
      autoRotateLoop
    });

    updateOnPageRotationBadges(cycleCount, selectedCode, pool[nextIdx % pool.length]);

    return {
      selectedCode,
      nextCode: pool[nextIdx % pool.length] || selectedCode,
      pool,
      cycleCount,
      autoClearOnStart,
      autoRotateLoop,
      domain,
      password
    };
  }

  // --- 12. Silent & Full Cookie + Storage Wipe ---
  async function clearCookiesAndStorageSilent() {
    try {
      const rawCookies = (document.cookie || '').split(';');
      const host = (window.location && window.location.hostname) || 'knowunity.ph';
      const domains = [host, '.' + host, 'knowunity.ph', '.knowunity.ph', 'knowunity.com', '.knowunity.com'];
      const paths = ['/', window.location.pathname || '/'];

      for (const c of rawCookies) {
        const eqIdx = c.indexOf('=');
        const name = (eqIdx > -1 ? c.slice(0, eqIdx) : c).trim();
        if (!name) continue;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
        for (const d of domains) {
          for (const p of paths) {
            document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=${p};domain=${d}`;
          }
        }
      }

      try {
        window.localStorage.clear();
      } catch (e) {}
      try {
        window.sessionStorage.clear();
      } catch (e) {}

      await new Promise((resolve) => {
        let settled = false;
        const timer = setTimeout(() => {
          if (!settled) {
            settled = true;
            resolve();
          }
        }, 1200);

        try {
          chrome.runtime.sendMessage(
            { action: 'clear_website_cookies_from_page', url: window.location.href },
            () => {
              if (chrome.runtime.lastError) {}
              if (!settled) {
                settled = true;
                clearTimeout(timer);
                resolve();
              }
            }
          );
        } catch (e) {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            resolve();
          }
        }
      });

      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async function clearWebsiteCookiesAndStorage() {
    showFloatingToast('Clearing website cookies & storage...');
    await clearCookiesAndStorageSilent();
    showFloatingToast('Cookies and site storage cleared! Refreshing...');
    setTimeout(() => {
      try {
        window.location.reload();
      } catch (e) {}
    }, 450);
  }

  // --- High-DPI Vector SVG Icons (100% Zero Emojis) ---
  const KN_ICONS = {
    bolt: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
    stop: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>',
    broom: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/><path d="M3 21h18"/></svg>',
    rotate: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
    menu: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    globe: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    star: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    check: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    close: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    minimize: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>',
    copy: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    spinner: '<svg class="kn-icon kn-spin" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10" stroke-dasharray="32" stroke-dashoffset="12"/></svg>',
    alert: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    reset: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
    play: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
    sparkle: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M12 2l2.4 7.2L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.8z"/></svg>'
  };

  function detectBrowserInfo() {
    const ua = navigator.userAgent || '';
    let name = 'Chromium';
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);

    if (/Lemur/i.test(ua)) {
      name = 'Lemur Browser';
    } else if (/Kiwi/i.test(ua)) {
      name = 'Kiwi Browser';
    } else if (/Brave/i.test(ua) || (navigator.brave && typeof navigator.brave.isBrave === 'function')) {
      name = 'Brave Browser';
    } else if (/EdgA?|Edge/i.test(ua)) {
      name = 'Microsoft Edge';
    } else if (/OPR|Opera/i.test(ua)) {
      name = 'Opera';
    } else if (/Vivaldi/i.test(ua)) {
      name = 'Vivaldi';
    } else if (/SamsungBrowser/i.test(ua)) {
      name = 'Samsung Internet';
    } else if (/Firefox|FxiOS/i.test(ua)) {
      name = 'Firefox';
    } else if (/Chrome|CriOS/i.test(ua)) {
      name = 'Google Chrome';
    }

    const shortName = name.replace(' Browser', '');
    return {
      name,
      shortName,
      isMobile,
      platform: isMobile ? 'Mobile' : 'Desktop',
      summary: `${name} (${isMobile ? 'Mobile' : 'Desktop'})`,
      badge: `${shortName} / ${isMobile ? 'Mobile' : 'Desktop'}`
    };
  }

  function updateOnPageRotationBadges(cycleCount, activeCode, nextCode) {
    const dockCycleEl = document.getElementById('knowunity-dock-cycle-count');
    if (dockCycleEl && typeof cycleCount === 'number') {
      dockCycleEl.textContent = `#${cycleCount}`;
    }
    const menuCycleEl = document.getElementById('knowunityMenuCycleDisplay');
    if (menuCycleEl && typeof cycleCount === 'number') {
      menuCycleEl.textContent = `#${cycleCount}`;
    }
    const defDisp = document.getElementById('knowunityMenuDefaultDisplay');
    if (defDisp && activeCode) {
      defDisp.textContent = activeCode;
    }
    const nextDisp = document.getElementById('knowunityMenuNextCodeDisplay');
    if (nextDisp && nextCode) {
      nextDisp.textContent = nextCode;
    }
  }

  function setStopButtonVisibility(running) {
    const stopBtn = document.getElementById('knowunity-stop-rotation-btn');
    if (stopBtn) {
      stopBtn.style.display = running ? 'inline-flex' : 'none';
    }
  }

  // --- Authoritative User Stop Rotation Handler ---
  async function stopRotationWorkflow() {
    isStoppedByUser = true;
    isWorkflowRunning = false;
    activeRunToken++;
    if (loopTimerId) {
      clearTimeout(loopTimerId);
      loopTimerId = null;
    }

    try {
      await chrome.storage.local.remove(['masterWorkflowActive', 'workflowStep', 'workflowStartTime']);
      await chrome.storage.local.set({
        rotationLoopActive: false
      });
    } catch (e) {}

    setStopButtonVisibility(false);

    const btn = document.getElementById('knowunity-site-workflow-btn');
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.innerHTML = `${KN_ICONS.bolt} <span>Magsimula All-in-One</span>`;
      btn.style.background = 'linear-gradient(135deg, #3B82F6, #1D4ED8)';
    }

    showFloatingToast('Rotation workflow stopped by user.');
    return { success: true, stopped: true, message: 'Rotation workflow stopped.' };
  }

  // --- Continuous Loop Transition: After Tapos Na -> Clear Cookie -> Back to Sign Up Landing Page -> Start Sign Up Again ---
  async function triggerNextRotationCycleIfActive() {
    if (isStoppedByUser) return;

    const state = await new Promise(r =>
      chrome.storage.local.get(['rotationLoopActive', 'autoRotateLoop'], r)
    );
    const shouldLoop =
      state && typeof state.rotationLoopActive === 'boolean'
        ? state.rotationLoopActive
        : state && typeof state.autoRotateLoop === 'boolean'
        ? state.autoRotateLoop
        : true;

    if (!shouldLoop || isStoppedByUser) {
      setStopButtonVisibility(false);
      return;
    }

    setStopButtonVisibility(true);
    showFloatingToast('Tapos Na complete! Auto-clearing cookies & returning to Sign Up...');

    await new Promise((resolve) => {
      loopTimerId = setTimeout(resolve, 750);
    });

    if (isStoppedByUser) return;

    const recheck = await new Promise(r =>
      chrome.storage.local.get(['rotationLoopActive', 'autoRotateLoop'], r)
    );
    if (recheck && recheck.rotationLoopActive === false) {
      setStopButtonVisibility(false);
      return;
    }

    // 1. Automatically Clear Cookies & Site Storage
    showFloatingToast('Clearing cookies & session storage for next rotation cycle...');
    await clearCookiesAndStorageSilent();

    if (isStoppedByUser) return;

    // 2. Save persistent auto-loop state so page load immediately starts the next Sign Up cycle
    await chrome.storage.local.set({
      masterWorkflowActive: true,
      rotationLoopActive: true,
      workflowStartTime: Date.now(),
      workflowStep: 'AUTO_LOOP_NEXT'
    });

    showFloatingToast('Returning to Sign Up landing page for next rotation...');

    // 3. Navigate back to Sign Up / Landing Page
    const originUrl =
      window.location && window.location.origin && window.location.origin.startsWith('http')
        ? window.location.origin + '/'
        : 'https://knowunity.ph/';

    try {
      if (window.location.pathname !== '/' && window.location.href.startsWith('http')) {
        window.location.href = originUrl;
      } else {
        window.location.reload();
      }
    } catch (e) {}

    // Fallback in case reload is a no-op (e.g. SPA or test harness)
    loopTimerId = setTimeout(() => {
      if (!isStoppedByUser) {
        isWorkflowRunning = false;
        executeOnPageWorkflow(null, { skipCookieClear: true, isAutoLoopResume: true });
      }
    }, 1100);
  }

  // --- Authoritative On-Page Rotation + Clear Cookie Workflow Runner ---
  async function executeOnPageWorkflow(customReferralCode = null, options = {}) {
    if (isWorkflowRunning && Date.now() - workflowStartTimeMs > 25000) {
      isWorkflowRunning = false;
    }

    if (isWorkflowRunning) {
      showFloatingToast('Workflow is already running...');
      return { success: false, message: 'Workflow already running.' };
    }

    isStoppedByUser = false;
    isWorkflowRunning = true;
    workflowStartTimeMs = Date.now();
    const myRunToken = ++activeRunToken;

    // Activate continuous rotation loop until user explicitly clicks Stop
    await chrome.storage.local.set({
      rotationLoopActive: true
    });
    setStopButtonVisibility(true);

    const btn = document.getElementById('knowunity-site-workflow-btn');
    if (btn) {
      btn.disabled = true;
      btn.style.opacity = '0.9';
      btn.innerHTML = `${KN_ICONS.spinner} <span>Clearing & Rotating...</span>`;
    }

    try {
      const rotState = await resolveNextRotationState(customReferralCode);
      const referralCode = rotState.selectedCode;
      const shouldClearCookies =
        typeof options.clearCookies === 'boolean' ? options.clearCookies : rotState.autoClearOnStart;

      // 1. Integrated Clear Cookies & Storage in Magsimula All-in-One
      if (shouldClearCookies && !options.skipCookieClear) {
        showFloatingToast(`Cycle #${rotState.cycleCount}: Clearing cookies & session...`);
        await clearCookiesAndStorageSilent();
      }

      if (isStoppedByUser || myRunToken !== activeRunToken) {
        return { success: false, message: 'Stopped by user.' };
      }

      // 2. Always generate a brand NEW unique email address for this rotation cycle
      const email = getFreshEmail(rotState.domain);
      const password = rotState.password;

      // 3. Archive generated credentials + referral code + rotation cycle to persistent history
      try {
        const histData = await new Promise(r => chrome.storage.local.get(['credentialsHistory'], r));
        const currentHist = Array.isArray(histData && histData.credentialsHistory)
          ? histData.credentialsHistory
          : [];
        if (!currentHist.some(item => item.email && item.email.toLowerCase() === email.toLowerCase())) {
          const newHistoryItem = {
            id: 'cred_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
            email: email.trim(),
            password,
            referralCode,
            cycle: rotState.cycleCount,
            timestamp: Date.now(),
            createdAt: new Date().toISOString()
          };
          await chrome.storage.local.set({ credentialsHistory: [newHistoryItem, ...currentHist] });
        }
      } catch (e) {}

      await chrome.storage.local.set({
        lastGeneratedEmail: email,
        lastGeneratedPassword: password,
        lastReferralCode: referralCode
      });

      if (btn) {
        btn.innerHTML = `${KN_ICONS.spinner} <span>Cycle #${rotState.cycleCount} (${referralCode})...</span>`;
      }

      // Wait briefly if resuming after page reload so React hydration renders landing/signup buttons
      if (options.isAutoLoopResume) {
        await waitForLandingOrSignupReady(7000);
      }

      if (isStoppedByUser || myRunToken !== activeRunToken) {
        return { success: false, message: 'Stopped by user.' };
      }

      const bodyText = getSiteBodyText();
      const singleCharBoxes = Array.from(document.querySelectorAll('input[maxlength="1"]')).filter(
        el => !isExtensionEl(el) && isElementVisible(el)
      );
      const isReferralModalOpen =
        bodyText.includes('may referral code ka ba') ||
        bodyText.includes('ilagay ang referral code') ||
        singleCharBoxes.length >= 4;

      if (isReferralModalOpen && !shouldClearCookies) {
        showFloatingToast(`Referral screen detected. Applying "${referralCode}"...`);
        const refRes = await applyReferralCodeOnPage(referralCode, true);
        if (btn && !isStoppedByUser) {
          btn.innerHTML = `${KN_ICONS.check} <span>Cycle #${rotState.cycleCount} Complete!</span>`;
          btn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
        }
        await triggerNextRotationCycleIfActive();
        return refRes;
      }

      const mode = detectPageMode();
      const immediateInputs = findInputsImmediate();
      const hasMagsimula = !!findMagsimulaButton();
      const hasContinueEmail = !!findContinueWithEmailButton();

      // If cookies were cleared while on an authenticated dashboard/profile route where no signup/landing controls exist,
      // save state and redirect to root landing page to start the clean cycle
      if (
        shouldClearCookies &&
        !options.skipCookieClear &&
        mode === 'UNKNOWN' &&
        !immediateInputs.emailInput &&
        !hasMagsimula &&
        !hasContinueEmail &&
        !isReferralModalOpen
      ) {
        await chrome.storage.local.set({
          masterWorkflowActive: true,
          rotationLoopActive: true,
          workflowStartTime: Date.now(),
          workflowStep: 'POST_COOKIE_CLEAR',
          activeEmail: email,
          activePassword: password,
          referralCode
        });
        showFloatingToast(`Session wiped! Redirecting to start Cycle #${rotState.cycleCount}...`);
        setTimeout(() => {
          try {
            if (window.location.pathname !== '/' && window.location.href.startsWith('http')) {
              window.location.href = window.location.origin + '/';
            } else {
              window.location.reload();
            }
          } catch (e) {}
        }, 250);
        return {
          success: true,
          navigating: true,
          referralCodeUsed: referralCode,
          cycle: rotState.cycleCount,
          message: `Cookies cleared & rotating to Cycle #${rotState.cycleCount} (${referralCode}).`
        };
      }

      // Step A: If on landing page (mode is UNKNOWN), click Magsimula on homepage
      if (mode === 'UNKNOWN') {
        const heroRes = performMagsimulaAction();
        if (heroRes.found) {
          showFloatingToast(`Cycle #${rotState.cycleCount}: Opening registration form...`);

          await chrome.storage.local.set({
            masterWorkflowActive: true,
            rotationLoopActive: true,
            workflowStartTime: Date.now(),
            workflowStep: 'REGISTRATION_FORM',
            activeEmail: email,
            activePassword: password,
            referralCode
          });

          const formReady = await waitForInputs(8000);
          if (!formReady || !formReady.emailInput) {
            return {
              success: true,
              navigating: true,
              referralCodeUsed: referralCode,
              cycle: rotState.cycleCount,
              message: 'Navigating to registration screen...'
            };
          }
        } else {
          const emailOpt = findContinueWithEmailButton();
          if (emailOpt) {
            simulateUserClick(emailOpt);
            await waitForInputs(5000);
          } else if (isReferralModalOpen || !!findTopRightReferralButton()) {
            const refRes = await applyReferralCodeOnPage(referralCode, true);
            if (btn && !isStoppedByUser) {
              btn.innerHTML = `${KN_ICONS.check} <span>Cycle #${rotState.cycleCount} Complete!</span>`;
              btn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            }
            await triggerNextRotationCycleIfActive();
            return refRes;
          }
        }
      } else if (mode === 'LOGIN') {
        showFloatingToast('Login mode detected. Switching to Sign Up...');
        await switchToSignUp();
        await waitForInputs(5000);
      }

      const currentInputs = findInputsImmediate();
      if (!currentInputs.emailInput) {
        const emailOpt = findContinueWithEmailButton();
        if (emailOpt) {
          simulateUserClick(emailOpt);
          await waitForInputs(5000);
        }
      }

      if (isStoppedByUser || myRunToken !== activeRunToken) {
        return { success: false, message: 'Stopped by user.' };
      }

      // Step B & C: Run complete form fill, Magpatuloy click, 6-box referral code, I-apply, and Tapos Na
      const res = await autofillRegistrationForm(email, password, referralCode, {
        handledByCallerLoop: true
      });

      if (isStoppedByUser || myRunToken !== activeRunToken) {
        return { success: false, message: 'Stopped by user.' };
      }

      if (res && res.success) {
        if (btn) {
          btn.innerHTML = `${KN_ICONS.check} <span>Cycle #${rotState.cycleCount} Complete!</span>`;
          btn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
        }
        showFloatingToast(`Cycle #${rotState.cycleCount} Complete! Applied "${referralCode}"`);
        // Step D: Automatically Clear Cookie -> Back to Sign Up Landing Page -> Start Sign Up Again!
        await triggerNextRotationCycleIfActive();
      } else {
        if (btn) {
          btn.innerHTML = `${KN_ICONS.alert} <span>Retry Cycle</span>`;
          btn.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
        }
        showFloatingToast('Workflow notice: ' + ((res && res.message) || 'Incomplete'));
      }
      return res;
    } catch (err) {
      showFloatingToast('Error: ' + err.message);
      if (btn) {
        btn.innerHTML = `${KN_ICONS.alert} <span>Error</span>`;
        btn.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
      }
      return { success: false, message: err.message };
    } finally {
      setTimeout(() => {
        if (myRunToken === activeRunToken) {
          isWorkflowRunning = false;
          if (btn && !isStoppedByUser) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.innerHTML = `${KN_ICONS.bolt} <span>Magsimula All-in-One</span>`;
            btn.style.background = 'linear-gradient(135deg, #3B82F6, #1D4ED8)';
          }
        }
      }, 2200);
    }
  }

  // --- Redesigned & Repositionable Floating Glass Dock + Menu Drawer ---
  function applyDockPosition(container, pos = 'bottom-right') {
    if (!container) return;
    container.dataset.position = pos;
    container.style.top = 'auto';
    container.style.bottom = 'auto';
    container.style.left = 'auto';
    container.style.right = 'auto';
    container.style.transform = 'none';
    container.style.alignItems = 'flex-end';

    if (pos === 'bottom-center') {
      container.style.bottom = '20px';
      container.style.left = '50%';
      container.style.transform = 'translateX(-50%)';
      container.style.alignItems = 'center';
    } else if (pos === 'bottom-left') {
      container.style.bottom = '20px';
      container.style.left = '18px';
      container.style.alignItems = 'flex-start';
    } else if (pos === 'top-right') {
      container.style.top = '72px';
      container.style.right = '18px';
      container.style.alignItems = 'flex-end';
    } else {
      container.style.bottom = '20px';
      container.style.right = '18px';
      container.style.alignItems = 'flex-end';
    }

    document.querySelectorAll('.kn-pos-btn').forEach(b => {
      if (b.dataset.pos === pos) b.classList.add('active');
      else b.classList.remove('active');
    });
  }

  function createOnPageWorkflowWidget() {
    if (document.getElementById('knowunity-site-toolbar')) return;

    if (
      !window.location.hostname.includes('knowunity.ph') &&
      !window.location.hostname.includes('knowunity.com')
    ) {
      return;
    }

    const browserInfo = detectBrowserInfo();

    if (!document.getElementById('knowunity-site-styles')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'knowunity-site-styles';
      styleEl.textContent = `
        #knowunity-site-toolbar {
          position: fixed;
          bottom: 20px;
          right: 18px;
          z-index: 2147483646;
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 10px;
          font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          user-select: none;
          -webkit-user-select: none;
        }
        #knowunity-site-mini-btn {
          display: none;
          align-items: center;
          gap: 7px;
          padding: 9px 15px;
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.94), rgba(30, 58, 138, 0.94));
          color: #ffffff;
          border: 1px solid rgba(147, 197, 253, 0.45);
          border-radius: 99px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 10px 28px rgba(15, 23, 42, 0.38);
          backdrop-filter: blur(18px);
          -webkit-backdrop-filter: blur(18px);
          transition: transform 0.18s, box-shadow 0.18s;
        }
        #knowunity-site-mini-btn:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: 0 14px 32px rgba(15, 23, 42, 0.48);
        }
        #knowunity-site-dock {
          display: flex;
          align-items: center;
          gap: 6px;
          background: rgba(15, 23, 42, 0.9);
          backdrop-filter: blur(22px);
          -webkit-backdrop-filter: blur(22px);
          padding: 6px 8px;
          border-radius: 99px;
          border: 1px solid rgba(148, 163, 184, 0.32);
          box-shadow: 0 14px 36px rgba(15, 23, 42, 0.32), 0 3px 10px rgba(15, 23, 42, 0.18);
          transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .kn-browser-pill {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 6px 10px;
          background: rgba(30, 41, 59, 0.92);
          border: 1px solid rgba(148, 163, 184, 0.28);
          border-radius: 99px;
          font-size: 11px;
          font-weight: 700;
          color: #E2E8F0;
          letter-spacing: 0.1px;
          cursor: pointer;
          transition: background 0.15s, transform 0.15s;
        }
        .kn-browser-pill:hover {
          background: rgba(51, 65, 85, 0.95);
          transform: translateY(-1px);
        }
        .kn-cycle-tag {
          background: rgba(59, 130, 246, 0.25);
          color: #93C5FD;
          padding: 1px 5px;
          border-radius: 99px;
          font-size: 10px;
          font-weight: 800;
          font-family: ui-monospace, monospace;
        }
        .kn-active-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px rgba(16, 185, 129, 0.85);
          flex-shrink: 0;
        }
        .kn-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-family: inherit;
          font-size: 11.5px;
          font-weight: 700;
          border-radius: 99px;
          cursor: pointer;
          border: 1px solid transparent;
          padding: 7px 12px;
          outline: none;
          transition: transform 0.16s, box-shadow 0.16s, background 0.16s, filter 0.16s;
          white-space: nowrap;
          text-decoration: none;
        }
        .kn-btn:active {
          transform: scale(0.97);
        }
        #knowunity-site-workflow-btn {
          padding: 8px 15px;
          background: linear-gradient(135deg, #3B82F6, #1D4ED8);
          color: #ffffff;
          border: 1px solid rgba(191, 219, 254, 0.45);
          font-size: 12px;
          font-weight: 750;
          letter-spacing: 0.2px;
          box-shadow: 0 6px 18px rgba(37, 99, 235, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.35);
        }
        #knowunity-site-workflow-btn:hover {
          transform: translateY(-1px) scale(1.02);
          box-shadow: 0 10px 24px rgba(37, 99, 235, 0.52);
          filter: brightness(1.06);
        }
        #knowunity-stop-rotation-btn {
          display: none;
          padding: 8px 13px;
          background: linear-gradient(135deg, #EF4444, #DC2626);
          color: #ffffff;
          border: 1px solid rgba(254, 202, 202, 0.55);
          font-size: 11.5px;
          font-weight: 800;
          box-shadow: 0 6px 16px rgba(220, 38, 38, 0.4);
        }
        #knowunity-stop-rotation-btn:hover {
          transform: translateY(-1px) scale(1.02);
          filter: brightness(1.06);
        }
        #knowunity-clear-cookies-btn {
          background: rgba(245, 158, 11, 0.16);
          color: #FCD34D;
          border: 1px solid rgba(245, 158, 11, 0.38);
        }
        #knowunity-clear-cookies-btn:hover {
          background: rgba(245, 158, 11, 0.26);
          transform: translateY(-1px);
          color: #FDE68A;
        }
        #knowunity-site-menu-btn {
          background: rgba(51, 65, 85, 0.85);
          color: #F8FAFC;
          border: 1px solid rgba(148, 163, 184, 0.32);
        }
        #knowunity-site-menu-btn:hover, #knowunity-site-menu-btn.active {
          background: rgba(71, 85, 105, 0.95);
          border-color: rgba(147, 197, 253, 0.5);
          transform: translateY(-1px);
        }
        #knowunity-site-minimize-btn {
          padding: 7px;
          background: transparent;
          color: #94A3B8;
          border: 1px solid transparent;
          border-radius: 50%;
        }
        #knowunity-site-minimize-btn:hover {
          background: rgba(51, 65, 85, 0.7);
          color: #F8FAFC;
        }
        #knowunity-site-menu-panel {
          display: none;
          width: 336px;
          max-width: calc(100vw - 28px);
          background: rgba(255, 255, 255, 0.97);
          backdrop-filter: blur(26px);
          -webkit-backdrop-filter: blur(26px);
          border: 1px solid rgba(190, 210, 235, 0.9);
          border-radius: 20px;
          box-shadow: 0 20px 48px rgba(15, 23, 42, 0.26), 0 4px 14px rgba(15, 23, 42, 0.08);
          padding: 15px;
          margin-bottom: 4px;
          color: #0F172A;
          animation: knSlideUp 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes knSlideUp {
          from { opacity: 0; transform: translateY(10px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .kn-menu-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 10px;
          border-bottom: 1px solid rgba(203, 213, 225, 0.7);
          margin-bottom: 11px;
        }
        .kn-menu-title {
          font-size: 13px;
          font-weight: 800;
          color: #0F172A;
          letter-spacing: -0.2px;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .kn-pos-group {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          background: #F1F5F9;
          padding: 2px;
          border-radius: 8px;
          border: 1px solid #CBD5E1;
          margin-left: auto;
          margin-right: 6px;
        }
        .kn-pos-btn {
          border: none;
          background: transparent;
          color: #64748B;
          font-size: 9.5px;
          font-weight: 800;
          padding: 3px 5px;
          border-radius: 6px;
          cursor: pointer;
        }
        .kn-pos-btn.active {
          background: #2563EB;
          color: #FFFFFF;
        }
        .kn-menu-close-btn {
          background: #F1F5F9;
          border: none;
          color: #475569;
          cursor: pointer;
          padding: 5px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.15s, color 0.15s;
        }
        .kn-menu-close-btn:hover {
          background: #E2E8F0;
          color: #0F172A;
        }
        .kn-menu-section {
          margin-bottom: 11px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 13px;
          padding: 9px 10px;
        }
        .kn-menu-section:last-child {
          margin-bottom: 0;
        }
        .kn-section-label {
          font-size: 10px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          color: #475569;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 4px;
        }
        .kn-label-left {
          display: inline-flex;
          align-items: center;
          gap: 5px;
        }
        .kn-ref-row {
          display: flex;
          gap: 6px;
          margin-bottom: 6px;
        }
        .kn-input {
          flex: 1;
          min-width: 0;
          padding: 7px 10px;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          color: #0F172A;
          background: #FFFFFF;
          border: 1px solid #CBD5E1;
          border-radius: 9px;
          outline: none;
        }
        .kn-input:focus {
          border-color: #2563EB;
          box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.18);
        }
        .kn-btn-secondary {
          background: #FEF3C7;
          color: #92400E;
          border: 1px solid rgba(217, 119, 6, 0.35);
        }
        .kn-btn-secondary:hover {
          background: #FDE68A;
          color: #78350F;
        }
        .kn-btn-primary {
          background: linear-gradient(135deg, #2563EB, #1D4ED8);
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.4);
          box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
        }
        .kn-btn-primary:hover {
          filter: brightness(1.06);
          transform: translateY(-1px);
        }
        .kn-default-badge {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #EFF6FF;
          border: 1px solid #BFDBFE;
          border-radius: 8px;
          padding: 5px 8px;
          font-size: 11px;
          color: #1E3A8A;
          margin-top: 5px;
        }
        .kn-default-badge strong {
          color: #1D4ED8;
          font-family: ui-monospace, monospace;
        }
        .kn-toggle-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 4px 2px;
          font-size: 11.5px;
          font-weight: 650;
          color: #1E293B;
        }
        .kn-toggle-row input[type="checkbox"] {
          width: 15px;
          height: 15px;
          accent-color: #2563EB;
          cursor: pointer;
        }
        .kn-action-list {
          display: flex;
          flex-direction: column;
          gap: 5px;
        }
        .kn-menu-action {
          display: flex;
          align-items: center;
          gap: 8px;
          width: 100%;
          padding: 8px 10px;
          background: #FFFFFF;
          border: 1px solid #CBD5E1;
          border-radius: 9px;
          font-size: 11.5px;
          font-weight: 700;
          color: #0F172A;
          cursor: pointer;
          transition: background 0.15s, transform 0.15s, border-color 0.15s;
          text-align: left;
        }
        .kn-menu-action:hover {
          background: #EFF6FF;
          border-color: #93C5FD;
          transform: translateY(-1px);
        }
        .kn-menu-action.kn-danger {
          color: #B91C1C;
          background: #FEF2F2;
          border-color: #FECACA;
        }
        .kn-menu-action.kn-danger:hover {
          background: #FEE2E2;
          border-color: #FCA5A5;
        }
        .kn-cred-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 5px;
        }
        .kn-btn-ghost {
          background: #FFFFFF;
          color: #0F172A;
          border: 1px solid #CBD5E1;
          width: 100%;
        }
        .kn-btn-ghost:hover {
          background: #F1F5F9;
        }
        @keyframes knSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .kn-spin {
          animation: knSpin 0.9s linear infinite;
        }
      `;
      document.head.appendChild(styleEl);
    }

    const container = document.createElement('div');
    container.id = 'knowunity-site-toolbar';
    container.className = 'kn-ext-element';

    const miniBtn = document.createElement('button');
    miniBtn.id = 'knowunity-site-mini-btn';
    miniBtn.className = 'kn-btn';
    miniBtn.innerHTML = `${KN_ICONS.sparkle} <span>Knowunity Assistant</span>`;
    miniBtn.title = 'Expand Knowunity Assistant Toolbar';

    const menuPanel = document.createElement('div');
    menuPanel.id = 'knowunity-site-menu-panel';

    menuPanel.innerHTML = `
      <div class="kn-menu-header">
        <div class="kn-menu-title">${KN_ICONS.sparkle} <span>Knowunity Assistant v5.0</span></div>
        <div class="kn-pos-group" title="Reposition Floating Dock">
          <button type="button" class="kn-pos-btn" data-pos="bottom-left" title="Bottom Left">BL</button>
          <button type="button" class="kn-pos-btn" data-pos="bottom-center" title="Bottom Center">BC</button>
          <button type="button" class="kn-pos-btn active" data-pos="bottom-right" title="Bottom Right">BR</button>
          <button type="button" class="kn-pos-btn" data-pos="top-right" title="Top Right">TR</button>
        </div>
        <button type="button" class="kn-menu-close-btn" id="knowunity-menu-close-btn" title="Close Menu">${KN_ICONS.close}</button>
      </div>

      <!-- Browser & Rotation Environment Section -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${KN_ICONS.globe} <span>Environment & Rotation</span></span>
          <span>Cycle <strong id="knowunityMenuCycleDisplay">#0</strong></span>
        </div>
        <div class="kn-default-badge" style="margin-top:0;">
          <span style="display:flex; align-items:center; gap:5px;">
            <span class="kn-active-dot"></span>
            <span>${browserInfo.name}</span>
          </span>
          <span style="font-size:10px; font-weight:700;">${browserInfo.platform}</span>
        </div>
        <div class="kn-toggle-row" style="margin-top:4px;">
          <label for="knowunity-toggle-autoclear" style="cursor:pointer;">Clear Cookies on Magsimula All-in-One</label>
          <input type="checkbox" id="knowunity-toggle-autoclear" checked />
        </div>
        <div class="kn-toggle-row">
          <label for="knowunity-toggle-autoloop" style="cursor:pointer;">Auto-Loop After Tapos Na (Until Stopped)</label>
          <input type="checkbox" id="knowunity-toggle-autoloop" checked />
        </div>
      </div>

      <!-- Referral Code & Rotation Pool Section -->
      <div class="kn-menu-section" id="knowunity-menu-referral-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${KN_ICONS.star} <span>Referral Code & Rotation Pool</span></span>
        </div>
        <div class="kn-ref-row">
          <input type="text" id="knowunity-menu-ref-input" class="kn-input" placeholder="e.g. NM3G4X" maxlength="12" value="NM3G4X" autocomplete="off" />
          <button type="button" id="knowunity-menu-set-default-btn" class="kn-btn kn-btn-secondary" title="Save this code as your default referral code">
            ${KN_ICONS.star} <span>Set Default</span>
          </button>
        </div>
        <div class="kn-ref-row">
          <input type="text" id="knowunity-menu-pool-input" class="kn-input" placeholder="Rotation pool: NM3G4X, CODE2..." autocomplete="off" style="font-size:11px;" />
          <button type="button" id="knowunity-menu-save-pool-btn" class="kn-btn kn-btn-ghost" style="width:auto; padding:6px 10px;" title="Save comma-separated referral codes for rotation">
            ${KN_ICONS.rotate} <span>Save Pool</span>
          </button>
        </div>
        <button type="button" id="knowunity-menu-apply-ref-btn" class="kn-btn kn-btn-primary" style="width: 100%;">
          ${KN_ICONS.check} <span>Apply Referral Code Now</span>
        </button>
        <div class="kn-default-badge" id="knowunity-menu-default-status">
          <span>Default: <strong id="knowunityMenuDefaultDisplay">NM3G4X</strong></span>
          <span>Next: <strong id="knowunityMenuNextCodeDisplay">NM3G4X</strong></span>
        </div>
      </div>

      <!-- Workflow Options -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${KN_ICONS.bolt} <span>Workflow Options</span></span>
        </div>
        <div class="kn-action-list">
          <button type="button" id="knowunity-menu-run-all-btn" class="kn-menu-action">
            ${KN_ICONS.bolt} <span>Start Continuous Rotation All-in-One</span>
          </button>
          <button type="button" id="knowunity-menu-stop-btn" class="kn-menu-action kn-danger">
            ${KN_ICONS.stop} <span>Stop Rotation Loop Now</span>
          </button>
          <button type="button" id="knowunity-menu-autofill-btn" class="kn-menu-action">
            ${KN_ICONS.play} <span>Autofill Form Only (No Clear)</span>
          </button>
          <button type="button" id="knowunity-menu-tapos-btn" class="kn-menu-action">
            ${KN_ICONS.check} <span>Trigger "Tapos Na" Confirmation</span>
          </button>
        </div>
      </div>

      <!-- Tools & Storage -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${KN_ICONS.broom} <span>Tools & Storage</span></span>
        </div>
        <div class="kn-cred-grid" style="margin-bottom: 5px;">
          <button type="button" id="knowunity-menu-copy-email-btn" class="kn-btn kn-btn-ghost">
            ${KN_ICONS.copy} <span>Copy Email</span>
          </button>
          <button type="button" id="knowunity-menu-copy-pass-btn" class="kn-btn kn-btn-ghost">
            ${KN_ICONS.copy} <span>Copy Pass</span>
          </button>
        </div>
        <div class="kn-action-list">
          <button type="button" id="knowunity-menu-clear-cookies-btn" class="kn-menu-action kn-danger">
            ${KN_ICONS.broom} <span>Clear Cookies & Storage</span>
          </button>
          <button type="button" id="knowunity-menu-reset-state-btn" class="kn-menu-action">
            ${KN_ICONS.reset} <span>Reset Workflow & Rotation Counter</span>
          </button>
        </div>
      </div>
    `;

    // Main Floating Glass Dock
    const dock = document.createElement('div');
    dock.id = 'knowunity-site-dock';

    const browserBadge = document.createElement('div');
    browserBadge.className = 'kn-browser-pill';
    browserBadge.title = `Browser: ${browserInfo.summary} • Click to open Rotation & Settings Menu`;
    browserBadge.innerHTML = `
      ${KN_ICONS.globe}
      <span class="kn-browser-name">${browserInfo.shortName}</span>
      <span class="kn-cycle-tag" id="knowunity-dock-cycle-count">#0</span>
      <span class="kn-active-dot"></span>
    `;

    const cookiesBtn = document.createElement('button');
    cookiesBtn.id = 'knowunity-clear-cookies-btn';
    cookiesBtn.className = 'kn-btn';
    cookiesBtn.innerHTML = `${KN_ICONS.broom} <span>Clear Cookies</span>`;
    cookiesBtn.title = 'Clear website cookies, localStorage, and sessionStorage';
    cookiesBtn.addEventListener('click', clearWebsiteCookiesAndStorage);

    const mainBtn = document.createElement('button');
    mainBtn.id = 'knowunity-site-workflow-btn';
    mainBtn.className = 'kn-btn';
    mainBtn.innerHTML = `${KN_ICONS.bolt} <span>Magsimula All-in-One</span>`;
    mainBtn.title = 'Start Continuous Rotation: Sign Up -> Referral -> Tapos Na -> Auto-Clear Cookies -> Repeat until stopped';
    mainBtn.addEventListener('click', () => {
      executeOnPageWorkflow(null);
    });

    // Dedicated Instant Stop Rotation Button on Dock
    const stopDockBtn = document.createElement('button');
    stopDockBtn.id = 'knowunity-stop-rotation-btn';
    stopDockBtn.className = 'kn-btn';
    stopDockBtn.innerHTML = `${KN_ICONS.stop} <span>Stop</span>`;
    stopDockBtn.title = 'Stop the automatic rotation loop immediately';
    stopDockBtn.addEventListener('click', () => {
      stopRotationWorkflow();
    });

    const menuBtn = document.createElement('button');
    menuBtn.id = 'knowunity-site-menu-btn';
    menuBtn.className = 'kn-btn';
    menuBtn.innerHTML = `${KN_ICONS.menu} <span>Menu</span>`;
    menuBtn.title = 'Open options, dock position, and referral rotation menu';

    const minimizeBtn = document.createElement('button');
    minimizeBtn.id = 'knowunity-site-minimize-btn';
    minimizeBtn.className = 'kn-btn';
    minimizeBtn.innerHTML = KN_ICONS.minimize;
    minimizeBtn.title = 'Minimize toolbar';

    dock.appendChild(browserBadge);
    dock.appendChild(cookiesBtn);
    dock.appendChild(mainBtn);
    dock.appendChild(stopDockBtn);
    dock.appendChild(menuBtn);
    dock.appendChild(minimizeBtn);

    container.appendChild(miniBtn);
    container.appendChild(menuPanel);
    container.appendChild(dock);

    document.body.appendChild(container);

    // --- Wire Up Interactivity ---
    menuPanel.querySelectorAll('.kn-pos-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const pos = btn.dataset.pos || 'bottom-right';
        applyDockPosition(container, pos);
        try {
          chrome.storage.local.set({ dockPosition: pos });
        } catch (err) {}
      });
    });

    const refreshMenuStateFromStorage = () => {
      try {
        chrome.storage.local.get(
          [
            'defaultReferralCode',
            'lastReferralCode',
            'referralRotationPool',
            'rotationIndex',
            'rotationCycleCount',
            'autoClearOnStart',
            'autoRotateLoop',
            'rotationLoopActive',
            'dockPosition'
          ],
          (data) => {
            const defaultCode = (data && data.defaultReferralCode) || 'NM3G4X';
            const activeCode = (data && data.lastReferralCode) || defaultCode;
            const pool = parseReferralPool(data && data.referralRotationPool, defaultCode);
            const idx = parseInt((data && data.rotationIndex) || 0, 10) || 0;
            const nextCode = pool[idx % pool.length] || defaultCode;
            const cycleCount = parseInt((data && data.rotationCycleCount) || 0, 10) || 0;

            const refInput = document.getElementById('knowunity-menu-ref-input');
            const poolInput = document.getElementById('knowunity-menu-pool-input');
            const autoClearInput = document.getElementById('knowunity-toggle-autoclear');
            const autoLoopInput = document.getElementById('knowunity-toggle-autoloop');

            if (refInput && !refInput.dataset.userEdited) refInput.value = activeCode;
            if (poolInput && !poolInput.dataset.userEdited) poolInput.value = pool.join(', ');
            if (autoClearInput) {
              autoClearInput.checked =
                data && typeof data.autoClearOnStart === 'boolean' ? data.autoClearOnStart : true;
            }
            if (autoLoopInput) {
              autoLoopInput.checked =
                data && typeof data.autoRotateLoop === 'boolean' ? data.autoRotateLoop : true;
            }
            if (data && data.dockPosition) {
              applyDockPosition(container, data.dockPosition);
            }
            if (data && data.rotationLoopActive) {
              setStopButtonVisibility(true);
            }

            updateOnPageRotationBadges(cycleCount, defaultCode, nextCode);
          }
        );
      } catch (e) {}
    };

    const toggleMenu = (forceState = null) => {
      const isVisible = menuPanel.style.display === 'block';
      const nextState = forceState !== null ? forceState : !isVisible;
      menuPanel.style.display = nextState ? 'block' : 'none';
      if (nextState) {
        menuBtn.classList.add('active');
        refreshMenuStateFromStorage();
      } else {
        menuBtn.classList.remove('active');
      }
    };

    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    browserBadge.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu(true);
    });

    const closeBtn = document.getElementById('knowunity-menu-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => toggleMenu(false));
    }

    document.addEventListener('click', (e) => {
      if (
        !menuPanel.contains(e.target) &&
        !menuBtn.contains(e.target) &&
        !browserBadge.contains(e.target)
      ) {
        if (menuPanel.style.display === 'block') {
          toggleMenu(false);
        }
      }
    });

    minimizeBtn.addEventListener('click', () => {
      dock.style.display = 'none';
      menuPanel.style.display = 'none';
      miniBtn.style.display = 'flex';
    });

    miniBtn.addEventListener('click', () => {
      miniBtn.style.display = 'none';
      dock.style.display = 'flex';
    });

    const autoClearCheckbox = document.getElementById('knowunity-toggle-autoclear');
    if (autoClearCheckbox) {
      autoClearCheckbox.addEventListener('change', () => {
        chrome.storage.local.set({ autoClearOnStart: autoClearCheckbox.checked });
        showFloatingToast(
          autoClearCheckbox.checked
            ? 'Auto-Clear Cookies enabled on Magsimula All-in-One'
            : 'Auto-Clear Cookies disabled on Magsimula All-in-One'
        );
      });
    }

    const autoLoopCheckbox = document.getElementById('knowunity-toggle-autoloop');
    if (autoLoopCheckbox) {
      autoLoopCheckbox.addEventListener('change', () => {
        chrome.storage.local.set({
          autoRotateLoop: autoLoopCheckbox.checked,
          rotationLoopActive: autoLoopCheckbox.checked
        });
        if (!autoLoopCheckbox.checked) {
          stopRotationWorkflow();
        } else {
          showFloatingToast('Continuous Auto-Rotate Loop enabled!');
        }
      });
    }

    const menuRefInput = document.getElementById('knowunity-menu-ref-input');
    if (menuRefInput) {
      menuRefInput.addEventListener('input', () => {
        menuRefInput.dataset.userEdited = 'true';
        menuRefInput.value = menuRefInput.value.toUpperCase();
      });
    }

    const menuPoolInput = document.getElementById('knowunity-menu-pool-input');
    if (menuPoolInput) {
      menuPoolInput.addEventListener('input', () => {
        menuPoolInput.dataset.userEdited = 'true';
        menuPoolInput.value = menuPoolInput.value.toUpperCase();
      });
    }

    const setDefaultBtn = document.getElementById('knowunity-menu-set-default-btn');
    if (setDefaultBtn) {
      setDefaultBtn.addEventListener('click', async () => {
        const raw = (menuRefInput && menuRefInput.value.trim().toUpperCase()) || 'NM3G4X';
        const clean = raw.replace(/[^A-Z0-9]/g, '').slice(0, 12) || 'NM3G4X';
        await chrome.storage.local.set({ defaultReferralCode: clean, lastReferralCode: clean });
        const defaultDisplay = document.getElementById('knowunityMenuDefaultDisplay');
        if (defaultDisplay) defaultDisplay.textContent = clean;
        if (menuRefInput) menuRefInput.value = clean;
        showFloatingToast(`Referral code "${clean}" saved as default!`);
      });
    }

    const savePoolBtn = document.getElementById('knowunity-menu-save-pool-btn');
    if (savePoolBtn) {
      savePoolBtn.addEventListener('click', async () => {
        const rawPool = (menuPoolInput && menuPoolInput.value) || 'NM3G4X';
        const parsed = parseReferralPool(rawPool, 'NM3G4X');
        await chrome.storage.local.set({
          referralRotationPool: parsed,
          rotationIndex: 0,
          defaultReferralCode: parsed[0],
          lastReferralCode: parsed[0]
        });
        if (menuPoolInput) menuPoolInput.value = parsed.join(', ');
        if (menuRefInput) menuRefInput.value = parsed[0];
        updateOnPageRotationBadges(null, parsed[0], parsed[0]);
        showFloatingToast(`Saved ${parsed.length} code(s) to Rotation Pool!`);
      });
    }

    const applyRefBtn = document.getElementById('knowunity-menu-apply-ref-btn');
    if (applyRefBtn) {
      applyRefBtn.addEventListener('click', () => {
        const raw = (menuRefInput && menuRefInput.value.trim().toUpperCase()) || 'NM3G4X';
        const clean = raw.replace(/[^A-Z0-9]/g, '').slice(0, 12) || 'NM3G4X';
        toggleMenu(false);
        applyReferralCodeOnPage(clean, true);
      });
    }

    const menuRunAllBtn = document.getElementById('knowunity-menu-run-all-btn');
    if (menuRunAllBtn) {
      menuRunAllBtn.addEventListener('click', () => {
        toggleMenu(false);
        executeOnPageWorkflow(null);
      });
    }

    const menuStopBtn = document.getElementById('knowunity-menu-stop-btn');
    if (menuStopBtn) {
      menuStopBtn.addEventListener('click', () => {
        toggleMenu(false);
        stopRotationWorkflow();
      });
    }

    const menuAutofillBtn = document.getElementById('knowunity-menu-autofill-btn');
    if (menuAutofillBtn) {
      menuAutofillBtn.addEventListener('click', async () => {
        toggleMenu(false);
        const email = getFreshEmail();
        const d = await new Promise(r =>
          chrome.storage.local.get(['lastGeneratedPassword', 'defaultReferralCode'], r)
        );
        const password = getPersistentPassword(d && d.lastGeneratedPassword);
        const refCode = (d && d.defaultReferralCode) || 'NM3G4X';
        showFloatingToast('Autofilling sign-up form with credentials...');
        await autofillRegistrationForm(email, password, refCode);
      });
    }

    const menuTaposBtn = document.getElementById('knowunity-menu-tapos-btn');
    if (menuTaposBtn) {
      menuTaposBtn.addEventListener('click', () => {
        toggleMenu(false);
        showFloatingToast('Searching and triggering Tapos Na button...');
        triggerTaposNaButton();
      });
    }

    const copyEmailBtn = document.getElementById('knowunity-menu-copy-email-btn');
    if (copyEmailBtn) {
      copyEmailBtn.addEventListener('click', async () => {
        const d = await new Promise(r =>
          chrome.storage.local.get(['lastGeneratedEmail', 'activeEmail'], r)
        );
        const email = (d && (d.lastGeneratedEmail || d.activeEmail)) || '';
        if (email) {
          try {
            await navigator.clipboard.writeText(email);
            showFloatingToast('Email copied to clipboard!');
          } catch (e) {
            showFloatingToast('Email: ' + email);
          }
        } else {
          showFloatingToast('No email generated yet.');
        }
      });
    }

    const copyPassBtn = document.getElementById('knowunity-menu-copy-pass-btn');
    if (copyPassBtn) {
      copyPassBtn.addEventListener('click', async () => {
        const d = await new Promise(r =>
          chrome.storage.local.get(['lastGeneratedPassword', 'activePassword'], r)
        );
        const pass = (d && (d.lastGeneratedPassword || d.activePassword)) || '';
        if (pass) {
          try {
            await navigator.clipboard.writeText(pass);
            showFloatingToast('Password copied to clipboard!');
          } catch (e) {
            showFloatingToast('Password: ' + pass);
          }
        } else {
          showFloatingToast('No password generated yet.');
        }
      });
    }

    const menuClearCookiesBtn = document.getElementById('knowunity-menu-clear-cookies-btn');
    if (menuClearCookiesBtn) {
      menuClearCookiesBtn.addEventListener('click', () => {
        toggleMenu(false);
        clearWebsiteCookiesAndStorage();
      });
    }

    const menuResetStateBtn = document.getElementById('knowunity-menu-reset-state-btn');
    if (menuResetStateBtn) {
      menuResetStateBtn.addEventListener('click', async () => {
        await stopRotationWorkflow();
        await chrome.storage.local.set({
          rotationIndex: 0,
          rotationCycleCount: 0
        });
        refreshMenuStateFromStorage();
        toggleMenu(false);
        showFloatingToast('Workflow & rotation counter reset.');
      });
    }

    refreshMenuStateFromStorage();
  }

  // --- Auto-Resume Continuous Rotation Workflow Across Page Navigation / Reloads ---
  try {
    chrome.storage.local.get(
      [
        'masterWorkflowActive',
        'rotationLoopActive',
        'workflowStartTime',
        'workflowStep',
        'activeEmail',
        'activePassword',
        'referralCode'
      ],
      async (data) => {
        if (!data) return;

        // If user explicitly stopped rotation, do not auto-resume
        if (data.rotationLoopActive === false && !data.masterWorkflowActive) {
          return;
        }

        if (
          data.masterWorkflowActive &&
          Date.now() - (data.workflowStartTime || 0) < 45000
        ) {
          setStopButtonVisibility(true);
          showFloatingToast('Resuming Magsimula rotation workflow...');

          const email = data.activeEmail || getFreshEmail();
          const password = getPersistentPassword(data.activePassword);
          const refCode = data.referralCode || 'NM3G4X';

          if (data.workflowStep === 'AUTO_LOOP_NEXT') {
            await chrome.storage.local.remove(['masterWorkflowActive', 'workflowStep', 'workflowStartTime']);
            await new Promise(r => setTimeout(r, 350));
            if (!isStoppedByUser) {
              await executeOnPageWorkflow(null, { skipCookieClear: true, isAutoLoopResume: true });
            }
          } else if (data.workflowStep === 'POST_COOKIE_CLEAR') {
            await chrome.storage.local.remove(['masterWorkflowActive', 'workflowStep', 'workflowStartTime']);
            await waitForLandingOrSignupReady(7000);
            if (!isStoppedByUser) {
              const mode = detectPageMode();
              if (mode === 'UNKNOWN') {
                performMagsimulaAction();
                await waitForInputs(6000);
              }
              await autofillRegistrationForm(email, password, refCode, { handledByCallerLoop: true });
              await triggerNextRotationCycleIfActive();
            }
          } else if (data.workflowStep === 'REFERRAL_STEP') {
            await new Promise(r => setTimeout(r, 600));
            if (!isStoppedByUser) {
              await applyReferralCodeOnPage(refCode, true);
              await chrome.storage.local.remove(['masterWorkflowActive', 'workflowStep', 'workflowStartTime']);
              await triggerNextRotationCycleIfActive();
            }
          } else {
            await waitForInputs(8000);
            if (!isStoppedByUser) {
              await autofillRegistrationForm(email, password, refCode, { handledByCallerLoop: true });
              await triggerNextRotationCycleIfActive();
            }
          }
        }
      }
    );
  } catch (e) {}

  // --- 13. Runtime Message Listener ---
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (!req || !req.action) return false;

    if (req.action === 'ping') {
      sendResponse({ pong: true, mode: detectPageMode() });
      return false;
    }
    if (req.action === 'detect_page_mode') {
      const mode = detectPageMode();
      sendResponse({ mode });
      return false;
    }
    if (req.action === 'switch_to_signup') {
      switchToSignUp().then(sendResponse);
      return true;
    }
    if (req.action === 'autofill_registration_form') {
      isStoppedByUser = false;
      setStopButtonVisibility(true);
      chrome.storage.local.set({ rotationLoopActive: true });
      autofillRegistrationForm(req.email, req.password, req.referralCode || 'NM3G4X').then(sendResponse);
      return true;
    }
    if (req.action === 'apply_referral_code') {
      applyReferralCodeOnPage(req.code || 'NM3G4X', true).then(sendResponse);
      return true;
    }
    if (req.action === 'click_magsimula') {
      const res = performMagsimulaAction();
      sendResponse(res);
      return false;
    }
    if (req.action === 'execute_onpage_workflow') {
      executeOnPageWorkflow(req.referralCode || null, {
        clearCookies: typeof req.clearCookies === 'boolean' ? req.clearCookies : undefined
      }).then(sendResponse);
      return true;
    }
    if (req.action === 'stop_rotation_workflow') {
      stopRotationWorkflow().then(sendResponse);
      return true;
    }
    if (req.action === 'clear_site_storage') {
      clearCookiesAndStorageSilent().then(() => sendResponse({ success: true }));
      return true;
    }
    return false;
  });

  // Test Hooks
  try {
    window.__knowunityTestHooks = {
      findMagsimulaButton,
      performMagsimulaAction,
      getFreshEmail,
      getPersistentPassword,
      parseReferralPool,
      resolveNextRotationState,
      clearCookiesAndStorageSilent,
      autofillRegistrationForm,
      applyReferralCodeOnPage,
      triggerTaposNaButton,
      triggerNextRotationCycleIfActive,
      stopRotationWorkflow,
      executeOnPageWorkflow,
      detectBrowserInfo,
      createOnPageWorkflowWidget
    };
  } catch (e) {}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createOnPageWorkflowWidget);
  } else {
    createOnPageWorkflowWidget();
  }
})();
