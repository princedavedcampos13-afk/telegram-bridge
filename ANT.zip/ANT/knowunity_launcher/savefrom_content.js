// savefrom_content.js - SaveFrom Assistant v5.3 (en1.savefrom.net)
// Features:
// 1. Ultra-Clean "Download Section Only" Mode: Strips header, nav, promos, Televzr ads, how-to steps,
//    supported resources, SEO articles, FAQ, and footer so ONLY the download input box and video result card show.
// 2. Full On-Page "SaveFrom Assistant" Floating Glass Dock + Menu Drawer + Minimizable Pill matching the exact
//    Knowunity Assistant UI (BL / BC / BR / TR position switcher, 100% pure vector SVG icons, environment pill).
// 3. Multi-Layer Ad-Shield: Blocks window.open pop-unders, invisible overlay click-jacks, ad iframes, and
//    fake "Install SaveFrom.net Helper / Download HD via Televzr App" traps.
// 4. Smart Direct MP4 Extractor: Auto-expands "Download video in browser" and highlights direct MP4 links.

(() => {
  'use strict';

  const host = (window.location.hostname || '').toLowerCase();
  if (!host.includes('savefrom.net') && !host.includes('sfrom.net')) return;

  if (window.__savefromAssistantLoaded) {
    if (typeof window.__savefromAssistantForceRefresh === 'function') {
      window.__savefromAssistantForceRefresh();
    }
    return;
  }
  window.__savefromAssistantLoaded = true;

  const DEFAULT_SETTINGS = {
    sfOnlyDownloadSection: true,
    sfAdBlockEnabled: true,
    sfBlockPopups: true,
    sfHideHelperPromos: true,
    sfHideArticlesAndFooter: true,
    sfCompactMode: true,
    sfAutoBypassLowQualityWarning: true,
    sfAutoDownloadBest: false,
    sfTheme: 'midnight-glass', // 'midnight-glass' | 'emerald-dark' | 'cyber-neon' | 'minimal-light' | 'default'
    sfDockPosition: 'bottom-right',
    sfBlockedAdsCount: 0
  };

  let settings = { ...DEFAULT_SETTINGS };
  let sessionBlockedCount = 0;
  let lastAutoDownloadedHref = '';

  // --- High-DPI Pure Vector SVG Icons (Matching Knowunity Assistant 100%) ---
  const SF_ICONS = {
    sparkle: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M12 2l2.4 7.2L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.8z"/></svg>',
    bolt: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
    download: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    paste: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>',
    shield: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    layout: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>',
    palette: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="8.5" cy="10.5" r="1.5"/><circle cx="12" cy="7.5" r="1.5"/><circle cx="15.5" cy="10.5" r="1.5"/></svg>',
    broom: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/><path d="M3 21h18"/></svg>',
    menu: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    globe: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    check: '<svg class="kn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    close: '<svg class="kn-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    minimize: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>',
    reset: '<svg class="kn-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>'
  };

  function detectBrowserInfo() {
    const ua = navigator.userAgent || '';
    let name = 'Chromium';
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);

    if (/Lemur/i.test(ua)) name = 'Lemur Browser';
    else if (/Kiwi/i.test(ua)) name = 'Kiwi Browser';
    else if (/Brave/i.test(ua) || (navigator.brave && typeof navigator.brave.isBrave === 'function')) name = 'Brave Browser';
    else if (/EdgA?|Edge/i.test(ua)) name = 'Microsoft Edge';
    else if (/OPR|Opera/i.test(ua)) name = 'Opera';
    else if (/Vivaldi/i.test(ua)) name = 'Vivaldi';
    else if (/SamsungBrowser/i.test(ua)) name = 'Samsung Internet';
    else if (/Firefox|FxiOS/i.test(ua)) name = 'Firefox';
    else if (/Chrome|CriOS/i.test(ua)) name = 'Google Chrome';

    const shortName = name.replace(' Browser', '');
    return {
      name,
      shortName,
      isMobile,
      platform: isMobile ? 'Mobile' : 'Desktop',
      summary: `${name} (${isMobile ? 'Mobile' : 'Desktop'})`
    };
  }

  function isAssistantElement(el) {
    if (!el || typeof el.closest !== 'function') return false;
    return !!el.closest(
      '#savefrom-site-toolbar, #savefrom-site-menu-panel, #savefrom-helper-toast, #sf-clean-hero-badge, .sf-assistant-el'
    );
  }

  // --- 1. Multi-Layer Popup, Ad Redirect & Fake Helper Interceptor ---
  function installPopupAndRedirectGuard() {
    try {
      const origOpen = window.open;
      window.open = function (url) {
        if (!settings.sfAdBlockEnabled || !settings.sfBlockPopups) {
          return origOpen.apply(this, arguments);
        }
        const urlStr = String(url || '').toLowerCase();
        const isSafeDownload =
          urlStr.includes('googlevideo.com') ||
          urlStr.includes('fbcdn.net') ||
          urlStr.includes('cdninstagram.com') ||
          urlStr.includes('tiktokcdn') ||
          urlStr.includes('akamaihd.net') ||
          urlStr.includes('twimg.com') ||
          urlStr.includes('soundclouddownload') ||
          urlStr.includes('vimeo') ||
          urlStr.includes('savefrom.net/download');

        if (isSafeDownload) {
          return origOpen.apply(this, arguments);
        }

        incrementBlockedCounter(1);
        showFloatingToast('Ad-Shield blocked popup / ad redirect');
        return null;
      };
    } catch (e) {}

    window.addEventListener(
      'click',
      (e) => {
        if (!settings.sfAdBlockEnabled) return;
        const target = e.target;
        if (!target || typeof target.closest !== 'function') return;
        if (isAssistantElement(target)) return;

        const link = target.closest('a, button');
        if (link) {
          const href = (link.getAttribute('href') || '').toLowerCase();
          const cls = (link.className || '').toString().toLowerCase();
          const txt = (link.innerText || link.textContent || '').trim().toLowerCase();

          const isFakePromoLink =
            href.includes('televzr') ||
            href.includes('sf-helper') ||
            href.includes('helper') ||
            href.includes('utm_campaign=ss_extension') ||
            href.includes('chameleon') ||
            href.includes('casino') ||
            href.includes('betting') ||
            cls.includes('sf-helper') ||
            cls.includes('televzr') ||
            cls.includes('promo') ||
            txt.includes('install') ||
            txt.includes('download app') ||
            txt.includes('download hd via') ||
            txt.includes('televzr');

          if (isFakePromoLink && settings.sfHideHelperPromos) {
            e.preventDefault();
            e.stopPropagation();
            incrementBlockedCounter(1);
            showFloatingToast('Blocked fake installer / promo redirect');
            return false;
          }
        }
      },
      true
    );
  }

  function incrementBlockedCounter(amount = 1) {
    sessionBlockedCount += amount;
    settings.sfBlockedAdsCount = (parseInt(settings.sfBlockedAdsCount, 10) || 0) + amount;
    updateAssistantBadges();
    try {
      chrome.storage.local.set({ sfBlockedAdsCount: settings.sfBlockedAdsCount });
    } catch (e) {}
  }

  // --- 2. Ultra-Clean "Download Section Only" DOM Isolator + Ad Sanitizer ---
  const AD_SELECTORS = [
    '[class*="ad-banner" i]',
    '[class*="ads-" i]',
    '[id*="ad-container" i]',
    '[id*="google_ads" i]',
    'ins.adsbygoogle',
    'iframe[src*="ads" i]',
    'iframe[src*="doubleclick" i]',
    'iframe[src*="googlesyndication" i]',
    'iframe[src*="adservice" i]',
    'iframe[src*="exoclick" i]',
    'iframe[src*="propeller" i]',
    'iframe[src*="popads" i]',
    'iframe[src*="outbrain" i]',
    'iframe[src*="taboola" i]',
    'iframe[src*="mgid" i]',
    'iframe[src*="yandex" i]',
    'div[id^="yandex_rtb"]',
    'div[class*="yandex_rtb"]',
    '.b-banner',
    '.banner-box',
    '.ad-box',
    '.ads-box',
    '.partner-box',
    '.partners-block',
    '.promo-block',
    '.sf-promo',
    '.televzr-promo',
    '.extension-promo',
    '[class*="notification-bell" i]',
    '[class*="push-subscribe" i]'
  ];

  const HELPER_PROMO_SELECTORS = [
    'a[href*="televzr" i]',
    'a[href*="helper" i]',
    'a[href*="utm_campaign=ss_extension" i]',
    '.def-btn-box a[class*="helper" i]',
    '.install-btn',
    '.sf-quick-dl-btn',
    '.uvp-btn',
    '.btn-install',
    '.download-app-box',
    '.apk-download',
    '[class*="televzr" i]',
    '[class*="sf-helper" i]'
  ];

  const CLUTTER_SELECTORS = [
    'header',
    '.header',
    '#header',
    '.b-header',
    '.top-line',
    '.top-menu',
    '.lang-box',
    'nav',
    'footer',
    '.footer',
    '#footer',
    '.b-footer',
    '.how-to',
    '.howto-box',
    '.how-to-use',
    '.faq-box',
    '.faq-section',
    '.seo-text',
    '.seo-article',
    '.articles-box',
    '.supported-resources',
    '.supported-services',
    '.resources-list',
    '.promo-extension',
    '.extension-block',
    '.extension-box',
    '.app-promo',
    '.info-box',
    '.features-box',
    '.step-box',
    '.steps-block'
  ];

  function findDownloadCoreElements() {
    const urlInput =
      document.querySelector('input#sf_url') ||
      document.querySelector('input[name="sf_url"]') ||
      document.querySelector('form#sf_form input[type="text"], form#sf_form input[type="url"]') ||
      document.querySelector('.sf-form input[type="text"], .r-form input[type="text"]');

    const formEl =
      document.querySelector('form#sf_form') ||
      (urlInput && urlInput.closest('form')) ||
      document.querySelector('.sf-form, .r-form');

    const formBox =
      document.querySelector('#sf_form_box') ||
      document.querySelector('.downloader-box, .main-form-box') ||
      (formEl && formEl.parentElement);

    const resultBox =
      document.querySelector('#sf_result') ||
      document.querySelector('.result-box, .media-result');

    return { urlInput, formEl, formBox, resultBox };
  }

  // Isolates the download section by marking the ancestor chain of #sf_form and #sf_result
  // and hiding all non-download sibling branches when "Only Show Download Section" is enabled.
  function enforceDownloadOnlyCleanLayout() {
    if (!document.body) return;

    const { urlInput, formEl, formBox, resultBox } = findDownloadCoreElements();
    const coreTargets = [urlInput, formEl, formBox, resultBox].filter(Boolean);

    // Clear old markers if toggle was switched off
    if (!settings.sfOnlyDownloadSection) {
      document.querySelectorAll('[data-sf-hide-clutter="true"]').forEach((el) => {
        el.removeAttribute('data-sf-hide-clutter');
        el.style.removeProperty('display');
      });
      const badge = document.getElementById('sf-clean-hero-badge');
      if (badge) badge.style.display = 'none';
      return;
    }

    if (coreTargets.length === 0) return;

    // 1. Mark every ancestor of the download form and download result up to document.body
    document.querySelectorAll('[data-sf-keep-ancestor="true"]').forEach((el) => {
      el.removeAttribute('data-sf-keep-ancestor');
    });

    coreTargets.forEach((target) => {
      let curr = target;
      while (curr && curr !== document.body && curr !== document.documentElement) {
        curr.setAttribute('data-sf-keep-ancestor', 'true');
        curr = curr.parentElement;
      }
    });

    // 2. Walk down from body through kept ancestors and hide any sibling element that is NOT
    //    part of the download form, download result, or SaveFrom Assistant UI.
    const keptAncestors = [document.body, ...Array.from(document.querySelectorAll('[data-sf-keep-ancestor="true"]'))];
    keptAncestors.forEach((ancestor) => {
      // Do not hide children inside #sf_form or #sf_result themselves
      if (
        (formEl && (ancestor === formEl || formEl.contains(ancestor))) ||
        (resultBox && (ancestor === resultBox || resultBox.contains(ancestor)))
      ) {
        return;
      }

      Array.from(ancestor.children).forEach((child) => {
        if (!child || child.nodeType !== 1) return;
        const tag = child.tagName.toUpperCase();
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'LINK' || tag === 'META' || tag === 'NOSCRIPT') return;
        if (isAssistantElement(child)) return;
        if (child.id === 'sf-clean-hero-badge') return;
        if (child.getAttribute('data-sf-keep-ancestor') === 'true') return;
        if (formEl && (child === formEl || child.contains(formEl))) return;
        if (resultBox && (child === resultBox || child.contains(resultBox))) return;

        child.setAttribute('data-sf-hide-clutter', 'true');
      });
    });

    // 3. Inject a sleek minimal header badge right above the download box so the user sees
    //    that SaveFrom Assistant Clean Download Mode is active.
    const anchorTarget = formBox || formEl;
    if (anchorTarget && anchorTarget.parentElement) {
      let heroBadge = document.getElementById('sf-clean-hero-badge');
      if (!heroBadge) {
        heroBadge = document.createElement('div');
        heroBadge.id = 'sf-clean-hero-badge';
        heroBadge.className = 'sf-assistant-el';
        heroBadge.innerHTML = `
          <div class="sf-clean-hero-pill">
            ${SF_ICONS.shield}
            <span>SaveFrom Assistant • Clean Download Mode</span>
            <span class="sf-clean-dot"></span>
          </div>
          <h1 class="sf-clean-hero-title">Direct Video Downloader</h1>
          <p class="sf-clean-hero-sub">Paste any video link below or click <strong>Paste &amp; Download</strong> in the Assistant dock.</p>
        `;
        anchorTarget.parentElement.insertBefore(heroBadge, anchorTarget);
      } else {
        heroBadge.style.display = 'flex';
      }
    }
  }

  function scrubAdsAndPromos() {
    if (!document.body) return;
    let removedNow = 0;

    if (settings.sfAdBlockEnabled) {
      const adNodes = document.querySelectorAll(AD_SELECTORS.join(', '));
      adNodes.forEach((node) => {
        if (isAssistantElement(node)) return;
        if (!node.dataset.sfBlocked) {
          node.dataset.sfBlocked = 'true';
          node.style.setProperty('display', 'none', 'important');
          removedNow++;
        }
      });

      // Strip high z-index transparent click-jacking overlays
      document.querySelectorAll('body > div, body > iframe, body > a').forEach((el) => {
        if (isAssistantElement(el)) return;
        if (el.querySelector && (el.querySelector('#sf_form') || el.querySelector('#sf_url') || el.querySelector('#sf_result'))) {
          return;
        }
        try {
          const st = window.getComputedStyle(el);
          const z = parseInt(st.zIndex, 10);
          if (st.position === 'fixed' && z > 99999) {
            el.dataset.sfBlocked = 'true';
            el.style.setProperty('display', 'none', 'important');
            removedNow++;
          }
        } catch (e) {}
      });
    }

    if (settings.sfHideHelperPromos) {
      const promoNodes = document.querySelectorAll(HELPER_PROMO_SELECTORS.join(', '));
      promoNodes.forEach((node) => {
        if (isAssistantElement(node)) return;
        if (!node.dataset.sfBlocked) {
          node.dataset.sfBlocked = 'true';
          node.style.setProperty('display', 'none', 'important');
          removedNow++;
        }
      });

      // Automatically click "Download video in browser" / "without installation" when SaveFrom hides direct links
      if (settings.sfAutoBypassLowQualityWarning) {
        const directToggles = document.querySelectorAll(
          '#sf_result a, .result-box a, a.link-download-sub, .def-btn-name a'
        );
        directToggles.forEach((a) => {
          const txt = (a.innerText || a.textContent || '').trim().toLowerCase();
          if (
            txt.includes('in browser') ||
            txt.includes('without installation') ||
            txt.includes('continue in browser')
          ) {
            if (!a.dataset.sfAutoExpanded) {
              a.dataset.sfAutoExpanded = 'true';
              try {
                a.click();
              } catch (e) {}
            }
          }
        });
      }
    }

    // Highlight real direct download links inside #sf_result
    const realDownloadBtns = findVerifiedDownloadLinks();
    realDownloadBtns.forEach((btn) => {
      if (!btn.dataset.sfEnhanced) {
        btn.dataset.sfEnhanced = 'true';
        btn.classList.add('sf-verified-download-btn');
      }
    });

    // Optional Auto-Click Best MP4 when result arrives
    if (settings.sfAutoDownloadBest && realDownloadBtns.length > 0) {
      const bestBtn = realDownloadBtns[0];
      const href = bestBtn.getAttribute('href') || '';
      if (href && href.startsWith('http') && href !== lastAutoDownloadedHref) {
        lastAutoDownloadedHref = href;
        showFloatingToast('Auto-downloading best quality video...');
        try {
          bestBtn.click();
        } catch (e) {}
      }
    }

    enforceDownloadOnlyCleanLayout();

    if (removedNow > 0) {
      incrementBlockedCounter(removedNow);
    }
  }

  function findVerifiedDownloadLinks() {
    const candidates = Array.from(
      document.querySelectorAll(
        '#sf_result a.link-download, #sf_result .def-btn-box a, #sf_result .link-box a, .result-box a.link-download'
      )
    );
    return candidates.filter((a) => {
      if (!a || isAssistantElement(a)) return false;
      const href = (a.getAttribute('href') || '').toLowerCase();
      const txt = (a.innerText || a.textContent || '').trim().toLowerCase();
      if (!href || href === '#' || href.startsWith('javascript:')) return false;
      if (
        href.includes('televzr') ||
        href.includes('helper') ||
        href.includes('extension') ||
        txt.includes('install') ||
        txt.includes('televzr') ||
        txt.includes('app')
      ) {
        return false;
      }
      return true;
    });
  }

  // --- 3. Dynamic CSS Theme & Clean Download-Only Styling Engine ---
  function generateThemeCSS() {
    const theme = settings.sfTheme || 'midnight-glass';

    const palettes = {
      'midnight-glass': {
        bg: 'radial-gradient(circle at 20% 10%, #1e293b 0%, #0f172a 55%, #020617 100%)',
        cardBg: 'rgba(30, 41, 59, 0.85)',
        cardBorder: 'rgba(148, 163, 184, 0.28)',
        inputBg: 'rgba(15, 23, 42, 0.95)',
        inputBorder: '#3b82f6',
        textMain: '#f8fafc',
        textMuted: '#94a3b8',
        accent: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
        dlBtn: 'linear-gradient(135deg, #10b981, #059669)'
      },
      'emerald-dark': {
        bg: 'radial-gradient(circle at 15% 15%, #064e3b 0%, #022c22 55%, #020617 100%)',
        cardBg: 'rgba(6, 78, 59, 0.78)',
        cardBorder: 'rgba(52, 211, 153, 0.3)',
        inputBg: 'rgba(2, 44, 34, 0.95)',
        inputBorder: '#10b981',
        textMain: '#ecfdf5',
        textMuted: '#a7f3d0',
        accent: 'linear-gradient(135deg, #10b981, #059669)',
        dlBtn: 'linear-gradient(135deg, #10b981, #047857)'
      },
      'cyber-neon': {
        bg: 'radial-gradient(circle at 80% 10%, #3b0764 0%, #1e1b4b 50%, #090d16 100%)',
        cardBg: 'rgba(30, 27, 75, 0.85)',
        cardBorder: 'rgba(217, 70, 239, 0.38)',
        inputBg: 'rgba(15, 12, 41, 0.95)',
        inputBorder: '#d946ef',
        textMain: '#fae8ff',
        textMuted: '#f0abfc',
        accent: 'linear-gradient(135deg, #d946ef, #8b5cf6)',
        dlBtn: 'linear-gradient(135deg, #06b6d4, #2563eb)'
      },
      'minimal-light': {
        bg: 'linear-gradient(180deg, #f8fafc 0%, #e2e8f0 100%)',
        cardBg: 'rgba(255, 255, 255, 0.96)',
        cardBorder: 'rgba(15, 23, 42, 0.14)',
        inputBg: '#ffffff',
        inputBorder: '#2563eb',
        textMain: '#0f172a',
        textMuted: '#475569',
        accent: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
        dlBtn: 'linear-gradient(135deg, #10b981, #059669)'
      }
    };

    const p = palettes[theme] || palettes['midnight-glass'];
    let css = '';

    if (settings.sfAdBlockEnabled) {
      css += `
        ${AD_SELECTORS.join(',\n        ')} {
          display: none !important;
          visibility: hidden !important;
          height: 0 !important;
          pointer-events: none !important;
        }
      `;
    }

    if (settings.sfHideHelperPromos) {
      css += `
        ${HELPER_PROMO_SELECTORS.join(',\n        ')} {
          display: none !important;
        }
      `;
    }

    if (settings.sfOnlyDownloadSection || settings.sfHideArticlesAndFooter) {
      css += `
        ${CLUTTER_SELECTORS.join(',\n        ')},
        [data-sf-hide-clutter="true"] {
          display: none !important;
        }
      `;
    }

    if (settings.sfOnlyDownloadSection) {
      css += `
        html, body {
          margin: 0 !important;
          padding: 0 !important;
          min-height: 100vh !important;
          overflow-x: hidden !important;
        }
        #wrapper, .wrapper, .b-main, .b-content, .main-block, main {
          background: transparent !important;
          border: none !important;
          box-shadow: none !important;
          margin: 0 auto !important;
          padding: 0 !important;
          max-width: 820px !important;
          width: 100% !important;
        }
        .downloader-box, .main-form-box, #sf_form_box {
          margin: 0 auto !important;
          padding: 12px 18px !important;
          max-width: 780px !important;
          width: 100% !important;
          background: transparent !important;
          border: none !important;
          box-shadow: none !important;
        }
        #sf-clean-hero-badge {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 54px 20px 18px;
          margin: 0 auto;
          max-width: 720px;
          font-family: Inter, system-ui, -apple-system, sans-serif;
        }
        .sf-clean-hero-pill {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 6px 14px;
          border-radius: 999px;
          background: rgba(59, 130, 246, 0.16);
          border: 1px solid rgba(96, 165, 250, 0.4);
          color: ${theme === 'minimal-light' ? '#1d4ed8' : '#93c5fd'};
          font-size: 11.5px;
          font-weight: 700;
          margin-bottom: 12px;
        }
        .sf-clean-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #10b981;
          box-shadow: 0 0 8px #10b981;
        }
        .sf-clean-hero-title {
          margin: 0 0 6px !important;
          font-size: 28px !important;
          font-weight: 800 !important;
          letter-spacing: -0.03em !important;
          color: ${p.textMain} !important;
        }
        .sf-clean-hero-sub {
          margin: 0 !important;
          font-size: 13.5px !important;
          color: ${p.textMuted} !important;
          font-weight: 500 !important;
        }
      `;
    }

    if (theme !== 'default') {
      css += `
        html, body {
          background: ${p.bg} !important;
          color: ${p.textMain} !important;
          font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        }
        /* Download Form Card */
        form#sf_form, .sf-form, .r-form, #sf_form_box form {
          background: ${p.cardBg} !important;
          border: 1.5px solid ${p.cardBorder} !important;
          border-radius: 20px !important;
          padding: 14px !important;
          box-shadow: 0 22px 54px rgba(0, 0, 0, 0.36) !important;
          backdrop-filter: blur(18px) !important;
          -webkit-backdrop-filter: blur(18px) !important;
          display: flex !important;
          align-items: center !important;
          gap: 10px !important;
        }
        .tarea-wrap, .sf-form .l-box, #sf_form .l-box {
          flex: 1 !important;
          background: transparent !important;
          border: none !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        input#sf_url, input[name="sf_url"], form#sf_form input[type="text"], form#sf_form input[type="url"] {
          width: 100% !important;
          height: 50px !important;
          background: ${p.inputBg} !important;
          color: ${p.textMain} !important;
          border: 1.5px solid ${p.inputBorder} !important;
          border-radius: 13px !important;
          padding: 0 16px !important;
          font-size: 15px !important;
          font-weight: 600 !important;
          outline: none !important;
          box-sizing: border-box !important;
        }
        input#sf_url::placeholder {
          color: ${p.textMuted} !important;
          opacity: 0.75 !important;
        }
        button#sf_submit, #sf_submit, form#sf_form button[type="submit"], .sf-form .r-box button {
          height: 50px !important;
          background: ${p.accent} !important;
          color: #ffffff !important;
          border: none !important;
          border-radius: 13px !important;
          font-size: 14px !important;
          font-weight: 800 !important;
          padding: 0 24px !important;
          cursor: pointer !important;
          box-shadow: 0 8px 22px rgba(37, 99, 235, 0.35) !important;
          transition: transform 0.16s ease, filter 0.16s ease !important;
          white-space: nowrap !important;
        }
        button#sf_submit:hover, #sf_submit:hover {
          transform: translateY(-1px) !important;
          filter: brightness(1.08) !important;
        }
        /* Download Result Card */
        #sf_result, .result-box, .media-result {
          max-width: 780px !important;
          margin: 18px auto 90px !important;
          background: ${p.cardBg} !important;
          border: 1.5px solid ${p.cardBorder} !important;
          border-radius: 20px !important;
          padding: 20px !important;
          box-shadow: 0 24px 54px rgba(0, 0, 0, 0.42) !important;
          backdrop-filter: blur(18px) !important;
          -webkit-backdrop-filter: blur(18px) !important;
          color: ${p.textMain} !important;
        }
        #sf_result:empty {
          display: none !important;
        }
        #sf_result *, .result-box * {
          color: ${p.textMain} !important;
        }
        #sf_result select, #sf_result .drop-down-box {
          background: ${p.inputBg} !important;
          border: 1px solid ${p.cardBorder} !important;
          border-radius: 10px !important;
          color: ${p.textMain} !important;
        }
        .sf-verified-download-btn, #sf_result a.link-download, #sf_result .def-btn-box a {
          background: ${p.dlBtn} !important;
          color: #ffffff !important;
          border-radius: 12px !important;
          padding: 11px 22px !important;
          font-weight: 800 !important;
          text-decoration: none !important;
          display: inline-flex !important;
          align-items: center !important;
          justify-content: center !important;
          box-shadow: 0 8px 22px rgba(16, 185, 129, 0.38) !important;
          border: 1px solid rgba(255, 255, 255, 0.25) !important;
          transition: transform 0.15s ease, filter 0.15s ease !important;
        }
        .sf-verified-download-btn:hover, #sf_result a.link-download:hover {
          transform: translateY(-1px) scale(1.02) !important;
          filter: brightness(1.08) !important;
        }
      `;
    }

    return css;
  }

  function applyCustomStyles() {
    const root = document.head || document.documentElement;
    if (!root) return;
    let styleEl = document.getElementById('sf-customizer-styles');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'sf-customizer-styles';
      root.appendChild(styleEl);
    }
    styleEl.textContent = generateThemeCSS();
  }

  // --- 4. Assistant Actions (Paste & Download, Click Best MP4, Clear Input, Clear Cookies) ---
  async function pasteAndSubmitUrl(explicitUrl = null) {
    const { urlInput } = findDownloadCoreElements();
    if (!urlInput) {
      showFloatingToast('Could not locate SaveFrom URL input box on this page.');
      return { success: false, message: 'URL input not found' };
    }

    let targetUrl = explicitUrl;
    if (!targetUrl) {
      try {
        const clipText = await navigator.clipboard.readText();
        if (clipText && clipText.trim()) {
          targetUrl = clipText.trim();
        }
      } catch (e) {}
    }

    if (!targetUrl && urlInput.value && urlInput.value.trim()) {
      targetUrl = urlInput.value.trim();
    }

    if (!targetUrl) {
      urlInput.focus();
      showFloatingToast('Focused URL box — copy a video link or press Ctrl+V!');
      return { success: false, message: 'No URL in clipboard' };
    }

    urlInput.focus();
    urlInput.value = targetUrl;
    urlInput.dispatchEvent(new Event('input', { bubbles: true }));
    urlInput.dispatchEvent(new Event('change', { bubbles: true }));

    const submitBtn =
      document.querySelector('button#sf_submit') ||
      document.querySelector('#sf_submit') ||
      document.querySelector('form#sf_form button[type="submit"]') ||
      document.querySelector('.sf-form button[type="submit"]');

    if (submitBtn) {
      submitBtn.click();
    } else {
      const form = urlInput.closest('form');
      if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    }

    showFloatingToast('URL submitted! Fetching direct download links...');
    return { success: true, url: targetUrl };
  }

  function triggerBestQualityDownload() {
    scrubAdsAndPromos();
    const links = findVerifiedDownloadLinks();
    if (links.length === 0) {
      showFloatingToast('No download links ready yet — paste a video URL first!');
      return { success: false };
    }
    const best = links[0];
    try {
      best.click();
      showFloatingToast('Triggered direct video download!');
      return { success: true, href: best.getAttribute('href') };
    } catch (e) {
      return { success: false };
    }
  }

  function clearInputAndResults() {
    const { urlInput, resultBox } = findDownloadCoreElements();
    if (urlInput) {
      urlInput.value = '';
      urlInput.dispatchEvent(new Event('input', { bubbles: true }));
      urlInput.focus();
    }
    if (resultBox) {
      resultBox.innerHTML = '';
    }
    showFloatingToast('Cleared URL input & download results.');
  }

  async function clearSaveFromCookiesAndStorage() {
    showFloatingToast('Clearing SaveFrom cookies & local storage...');
    try {
      window.localStorage.clear();
    } catch (e) {}
    try {
      window.sessionStorage.clear();
    } catch (e) {}
    try {
      document.cookie.split(';').forEach((c) => {
        const eqIdx = c.indexOf('=');
        const name = (eqIdx > -1 ? c.slice(0, eqIdx) : c).trim();
        if (!name) return;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=${location.hostname}`;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.savefrom.net`;
      });
    } catch (e) {}

    try {
      chrome.runtime.sendMessage({ action: 'clear_website_cookies_from_page', url: window.location.href }, () => {});
    } catch (e) {}

    showFloatingToast('SaveFrom cookies & storage cleared!');
  }

  // --- 5. On-Page "SaveFrom Assistant" Floating Glass Dock & Menu Drawer (Knowunity Style) ---
  function showFloatingToast(msg) {
    if (!document.body) return;
    let toast = document.getElementById('savefrom-helper-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'savefrom-helper-toast';
      toast.className = 'sf-assistant-el';
      toast.style.cssText = [
        'position:fixed',
        'bottom:78px',
        'right:20px',
        'background:rgba(15, 23, 42, 0.96)',
        'color:#ffffff',
        'padding:10px 16px',
        'border-radius:99px',
        'border:1px solid rgba(147, 197, 253, 0.45)',
        'font-family:Inter,system-ui,-apple-system,sans-serif',
        'font-size:12px',
        'font-weight:700',
        'z-index:2147483647',
        'box-shadow:0 12px 32px rgba(15, 23, 42, 0.45)',
        'backdrop-filter:blur(16px)',
        'transition:opacity 0.2s, transform 0.2s',
        'pointer-events:none'
      ].join(';');
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
    clearTimeout(toast.__timer);
    toast.__timer = setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
    }, 2600);
  }

  function applyDockPosition(container, pos = 'bottom-right') {
    if (!container) return;
    container.dataset.position = pos;
    container.style.top = 'auto';
    container.style.bottom = 'auto';
    container.style.left = 'auto';
    container.style.right = 'auto';
    container.style.transform = 'none';
    container.style.alignItems = 'flex-end';

    if (pos === 'bottom-center') {
      container.style.bottom = '20px';
      container.style.left = '50%';
      container.style.transform = 'translateX(-50%)';
      container.style.alignItems = 'center';
    } else if (pos === 'bottom-left') {
      container.style.bottom = '20px';
      container.style.left = '18px';
      container.style.alignItems = 'flex-start';
    } else if (pos === 'top-right') {
      container.style.top = '72px';
      container.style.right = '18px';
      container.style.alignItems = 'flex-end';
    } else {
      container.style.bottom = '20px';
      container.style.right = '18px';
      container.style.alignItems = 'flex-end';
    }

    container.querySelectorAll('.kn-pos-btn').forEach((b) => {
      if (b.dataset.pos === pos) b.classList.add('active');
      else b.classList.remove('active');
    });
  }

  function updateAssistantBadges() {
    const total = settings.sfBlockedAdsCount || sessionBlockedCount;
    const dockCount = document.getElementById('savefrom-dock-shield-count');
    if (dockCount) dockCount.textContent = `#${total}`;
    const menuCount = document.getElementById('savefromMenuBlockedDisplay');
    if (menuCount) menuCount.textContent = `#${total}`;
    const cleanBtn = document.getElementById('savefrom-clean-mode-btn');
    if (cleanBtn) {
      cleanBtn.style.background = settings.sfOnlyDownloadSection
        ? 'rgba(16, 185, 129, 0.22)'
        : 'rgba(51, 65, 85, 0.85)';
      cleanBtn.style.color = settings.sfOnlyDownloadSection ? '#6EE7B7' : '#CBD5E1';
      cleanBtn.style.borderColor = settings.sfOnlyDownloadSection
        ? 'rgba(16, 185, 129, 0.45)'
        : 'rgba(148, 163, 184, 0.32)';
    }
  }

  function createSaveFromAssistantWidget() {
    if (!document.body || document.getElementById('savefrom-site-toolbar')) return;

    const browserInfo = detectBrowserInfo();

    if (!document.getElementById('savefrom-assistant-widget-styles')) {
      const widgetStyle = document.createElement('style');
      widgetStyle.id = 'savefrom-assistant-widget-styles';
      widgetStyle.textContent = `
        #savefrom-site-toolbar {
          position: fixed;
          bottom: 20px;
          right: 18px;
          z-index: 2147483646;
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 10px;
          font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          user-select: none;
          -webkit-user-select: none;
        }
        #savefrom-site-mini-btn {
          display: none;
          align-items: center;
          gap: 7px;
          padding: 9px 15px;
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.94), rgba(30, 58, 138, 0.94));
          color: #ffffff !important;
          border: 1px solid rgba(147, 197, 253, 0.45);
          border-radius: 99px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 10px 28px rgba(15, 23, 42, 0.38);
          backdrop-filter: blur(18px);
          -webkit-backdrop-filter: blur(18px);
          transition: transform 0.18s, box-shadow 0.18s;
        }
        #savefrom-site-mini-btn:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: 0 14px 32px rgba(15, 23, 42, 0.48);
        }
        #savefrom-site-dock {
          display: flex;
          align-items: center;
          gap: 6px;
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(22px);
          -webkit-backdrop-filter: blur(22px);
          padding: 6px 8px;
          border-radius: 99px;
          border: 1px solid rgba(148, 163, 184, 0.34);
          box-shadow: 0 14px 36px rgba(15, 23, 42, 0.4), 0 3px 10px rgba(15, 23, 42, 0.22);
          transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        #savefrom-site-toolbar .kn-browser-pill {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 6px 10px;
          background: rgba(30, 41, 59, 0.92);
          border: 1px solid rgba(148, 163, 184, 0.28);
          border-radius: 99px;
          font-size: 11px;
          font-weight: 700;
          color: #E2E8F0 !important;
          letter-spacing: 0.1px;
          cursor: pointer;
          transition: background 0.15s, transform 0.15s;
        }
        #savefrom-site-toolbar .kn-browser-pill:hover {
          background: rgba(51, 65, 85, 0.95);
          transform: translateY(-1px);
        }
        #savefrom-site-toolbar .kn-cycle-tag {
          background: rgba(16, 185, 129, 0.22);
          color: #6EE7B7 !important;
          padding: 1px 6px;
          border-radius: 99px;
          font-size: 10px;
          font-weight: 800;
          font-family: ui-monospace, monospace;
        }
        #savefrom-site-toolbar .kn-active-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px rgba(16, 185, 129, 0.85);
          flex-shrink: 0;
        }
        #savefrom-site-toolbar .kn-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-family: inherit;
          font-size: 11.5px;
          font-weight: 700;
          border-radius: 99px;
          cursor: pointer;
          border: 1px solid transparent;
          padding: 7px 12px;
          outline: none;
          transition: transform 0.16s, box-shadow 0.16s, background 0.16s, filter 0.16s;
          white-space: nowrap;
          text-decoration: none;
        }
        #savefrom-site-toolbar .kn-btn:active {
          transform: scale(0.97);
        }
        #savefrom-paste-dl-btn {
          padding: 8px 15px;
          background: linear-gradient(135deg, #3B82F6, #1D4ED8);
          color: #ffffff !important;
          border: 1px solid rgba(191, 219, 254, 0.45);
          font-size: 12px;
          font-weight: 750;
          letter-spacing: 0.2px;
          box-shadow: 0 6px 18px rgba(37, 99, 235, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.35);
        }
        #savefrom-paste-dl-btn:hover {
          transform: translateY(-1px) scale(1.02);
          box-shadow: 0 10px 24px rgba(37, 99, 235, 0.52);
          filter: brightness(1.06);
        }
        #savefrom-best-mp4-btn {
          background: rgba(16, 185, 129, 0.18);
          color: #6EE7B7 !important;
          border: 1px solid rgba(16, 185, 129, 0.4);
        }
        #savefrom-best-mp4-btn:hover {
          background: rgba(16, 185, 129, 0.28);
          transform: translateY(-1px);
        }
        #savefrom-clean-mode-btn {
          background: rgba(16, 185, 129, 0.22);
          color: #6EE7B7 !important;
          border: 1px solid rgba(16, 185, 129, 0.45);
        }
        #savefrom-site-menu-btn {
          background: rgba(51, 65, 85, 0.85);
          color: #F8FAFC !important;
          border: 1px solid rgba(148, 163, 184, 0.32);
        }
        #savefrom-site-menu-btn:hover, #savefrom-site-menu-btn.active {
          background: rgba(71, 85, 105, 0.95);
          border-color: rgba(147, 197, 253, 0.5);
          transform: translateY(-1px);
        }
        #savefrom-site-minimize-btn {
          padding: 7px;
          background: transparent;
          color: #94A3B8 !important;
          border: 1px solid transparent;
          border-radius: 50%;
        }
        #savefrom-site-minimize-btn:hover {
          background: rgba(51, 65, 85, 0.7);
          color: #F8FAFC !important;
        }
        #savefrom-site-menu-panel {
          display: none;
          width: 340px;
          max-width: calc(100vw - 28px);
          background: rgba(255, 255, 255, 0.97);
          backdrop-filter: blur(26px);
          -webkit-backdrop-filter: blur(26px);
          border: 1px solid rgba(190, 210, 235, 0.9);
          border-radius: 20px;
          box-shadow: 0 20px 48px rgba(15, 23, 42, 0.32), 0 4px 14px rgba(15, 23, 42, 0.12);
          padding: 15px;
          margin-bottom: 4px;
          color: #0F172A !important;
          animation: sfSlideUp 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }
        #savefrom-site-menu-panel * {
          color: inherit;
        }
        @keyframes sfSlideUp {
          from { opacity: 0; transform: translateY(10px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        #savefrom-site-menu-panel .kn-menu-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 10px;
          border-bottom: 1px solid rgba(203, 213, 225, 0.7);
          margin-bottom: 11px;
        }
        #savefrom-site-menu-panel .kn-menu-title {
          font-size: 13px;
          font-weight: 800;
          color: #0F172A !important;
          letter-spacing: -0.2px;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        #savefrom-site-menu-panel .kn-pos-group {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          background: #F1F5F9;
          padding: 2px;
          border-radius: 8px;
          border: 1px solid #CBD5E1;
          margin-left: auto;
          margin-right: 6px;
        }
        #savefrom-site-menu-panel .kn-pos-btn {
          border: none;
          background: transparent;
          color: #64748B !important;
          font-size: 9.5px;
          font-weight: 800;
          padding: 3px 5px;
          border-radius: 6px;
          cursor: pointer;
        }
        #savefrom-site-menu-panel .kn-pos-btn.active {
          background: #2563EB;
          color: #FFFFFF !important;
        }
        #savefrom-site-menu-panel .kn-menu-close-btn {
          background: #F1F5F9;
          border: none;
          color: #475569 !important;
          cursor: pointer;
          padding: 5px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #savefrom-site-menu-panel .kn-menu-section {
          margin-bottom: 11px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 13px;
          padding: 9px 10px;
        }
        #savefrom-site-menu-panel .kn-menu-section:last-child {
          margin-bottom: 0;
        }
        #savefrom-site-menu-panel .kn-section-label {
          font-size: 10px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          color: #475569 !important;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 4px;
        }
        #savefrom-site-menu-panel .kn-label-left {
          display: inline-flex;
          align-items: center;
          gap: 5px;
        }
        #savefrom-site-menu-panel .kn-default-badge {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #EFF6FF;
          border: 1px solid #BFDBFE;
          border-radius: 8px;
          padding: 5px 8px;
          font-size: 11px;
          color: #1E3A8A !important;
          margin-bottom: 6px;
        }
        #savefrom-site-menu-panel .kn-toggle-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 4px 2px;
          font-size: 11.5px;
          font-weight: 650;
          color: #1E293B !important;
        }
        #savefrom-site-menu-panel .kn-toggle-row input[type="checkbox"] {
          width: 15px;
          height: 15px;
          accent-color: #2563EB;
          cursor: pointer;
        }
        #savefrom-site-menu-panel .kn-select {
          width: 100%;
          padding: 7px 10px;
          border-radius: 9px;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          color: #0F172A !important;
          font-size: 12px;
          font-weight: 700;
          outline: none;
        }
        #savefrom-site-menu-panel .kn-action-list {
          display: flex;
          flex-direction: column;
          gap: 5px;
        }
        #savefrom-site-menu-panel .kn-menu-action {
          display: flex;
          align-items: center;
          gap: 8px;
          width: 100%;
          padding: 8px 10px;
          background: #FFFFFF;
          border: 1px solid #CBD5E1;
          border-radius: 9px;
          font-size: 11.5px;
          font-weight: 700;
          color: #0F172A !important;
          cursor: pointer;
          transition: background 0.15s, transform 0.15s, border-color 0.15s;
          text-align: left;
        }
        #savefrom-site-menu-panel .kn-menu-action:hover {
          background: #EFF6FF;
          border-color: #93C5FD;
          transform: translateY(-1px);
        }
        #savefrom-site-menu-panel .kn-menu-action.kn-danger {
          color: #B91C1C !important;
          background: #FEF2F2;
          border-color: #FECACA;
        }
      `;
      (document.head || document.documentElement).appendChild(widgetStyle);
    }

    const container = document.createElement('div');
    container.id = 'savefrom-site-toolbar';
    container.className = 'sf-assistant-el';

    const miniBtn = document.createElement('button');
    miniBtn.id = 'savefrom-site-mini-btn';
    miniBtn.className = 'kn-btn';
    miniBtn.innerHTML = `${SF_ICONS.sparkle} <span>SaveFrom Assistant</span>`;
    miniBtn.title = 'Expand SaveFrom Assistant Toolbar';

    const menuPanel = document.createElement('div');
    menuPanel.id = 'savefrom-site-menu-panel';
    menuPanel.innerHTML = `
      <div class="kn-menu-header">
        <div class="kn-menu-title">${SF_ICONS.sparkle} <span>SaveFrom Assistant v5.3</span></div>
        <div class="kn-pos-group" title="Reposition Floating Dock">
          <button type="button" class="kn-pos-btn" data-pos="bottom-left" title="Bottom Left">BL</button>
          <button type="button" class="kn-pos-btn" data-pos="bottom-center" title="Bottom Center">BC</button>
          <button type="button" class="kn-pos-btn active" data-pos="bottom-right" title="Bottom Right">BR</button>
          <button type="button" class="kn-pos-btn" data-pos="top-right" title="Top Right">TR</button>
        </div>
        <button type="button" class="kn-menu-close-btn" id="savefrom-menu-close-btn" title="Close Menu">${SF_ICONS.close}</button>
      </div>

      <!-- Environment & Ad-Shield Section -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${SF_ICONS.shield} <span>Environment &amp; Ad-Shield</span></span>
          <span>Blocked <strong id="savefromMenuBlockedDisplay">#0</strong></span>
        </div>
        <div class="kn-default-badge">
          <span style="display:flex; align-items:center; gap:5px;">
            <span class="kn-active-dot"></span>
            <span>${browserInfo.name}</span>
          </span>
          <span style="font-size:10px; font-weight:700;">${browserInfo.platform}</span>
        </div>
        <div class="kn-toggle-row">
          <label for="sf-menu-toggle-only-dl" style="cursor:pointer;"><strong>Only Show Download Section (Clean UI)</strong></label>
          <input type="checkbox" id="sf-menu-toggle-only-dl" checked />
        </div>
        <div class="kn-toggle-row">
          <label for="sf-menu-toggle-adblock" style="cursor:pointer;">Block All Ads, Pop-unders &amp; Redirects</label>
          <input type="checkbox" id="sf-menu-toggle-adblock" checked />
        </div>
        <div class="kn-toggle-row">
          <label for="sf-menu-toggle-helper" style="cursor:pointer;">Hide Fake "Install Helper / App" Promos</label>
          <input type="checkbox" id="sf-menu-toggle-helper" checked />
        </div>
        <div class="kn-toggle-row">
          <label for="sf-menu-toggle-autodl" style="cursor:pointer;">Auto-Click Best MP4 When Ready</label>
          <input type="checkbox" id="sf-menu-toggle-autodl" />
        </div>
      </div>

      <!-- Theme Preset Section -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${SF_ICONS.palette} <span>UI Theme Customizer</span></span>
        </div>
        <select id="sf-menu-theme-select" class="kn-select">
          <option value="midnight-glass">Midnight Glass (Dark Slate)</option>
          <option value="emerald-dark">Emerald Matrix (Deep Green)</option>
          <option value="cyber-neon">Cyberpunk Neon (Violet / Cyan)</option>
          <option value="minimal-light">Minimal Clean (Light)</option>
          <option value="default">Original SaveFrom Theme</option>
        </select>
      </div>

      <!-- Quick Downloader Actions -->
      <div class="kn-menu-section">
        <div class="kn-section-label">
          <span class="kn-label-left">${SF_ICONS.bolt} <span>Downloader Actions</span></span>
        </div>
        <div class="kn-action-list">
          <button type="button" id="sf-menu-paste-btn" class="kn-menu-action">
            ${SF_ICONS.paste} <span>Paste Clipboard URL &amp; Fetch Video</span>
          </button>
          <button type="button" id="sf-menu-best-mp4-btn" class="kn-menu-action">
            ${SF_ICONS.download} <span>Download Best Quality MP4 Now</span>
          </button>
          <button type="button" id="sf-menu-clear-input-btn" class="kn-menu-action">
            ${SF_ICONS.reset} <span>Clear URL Input &amp; Results</span>
          </button>
          <button type="button" id="sf-menu-clear-cookies-btn" class="kn-menu-action kn-danger">
            ${SF_ICONS.broom} <span>Clear SaveFrom Cookies &amp; Storage</span>
          </button>
        </div>
      </div>
    `;

    const dock = document.createElement('div');
    dock.id = 'savefrom-site-dock';

    const browserBadge = document.createElement('div');
    browserBadge.className = 'kn-browser-pill';
    browserBadge.title = `Browser: ${browserInfo.summary} • Click to open SaveFrom Assistant Menu`;
    browserBadge.innerHTML = `
      ${SF_ICONS.shield}
      <span>${browserInfo.shortName}</span>
      <span class="kn-cycle-tag" id="savefrom-dock-shield-count">#0</span>
      <span class="kn-active-dot"></span>
    `;

    const cleanModeBtn = document.createElement('button');
    cleanModeBtn.id = 'savefrom-clean-mode-btn';
    cleanModeBtn.className = 'kn-btn';
    cleanModeBtn.innerHTML = `${SF_ICONS.layout} <span>Download Only</span>`;
    cleanModeBtn.title = 'Toggle Ultra-Clean Mode (Only Show Download Section)';
    cleanModeBtn.addEventListener('click', () => {
      const nextVal = !settings.sfOnlyDownloadSection;
      saveAndApplySettings(
        { sfOnlyDownloadSection: nextVal, sfHideArticlesAndFooter: nextVal },
        nextVal ? 'Ultra-Clean Mode: Showing ONLY Download Section' : 'Showing full SaveFrom page'
      );
    });

    const pasteDlBtn = document.createElement('button');
    pasteDlBtn.id = 'savefrom-paste-dl-btn';
    pasteDlBtn.className = 'kn-btn';
    pasteDlBtn.innerHTML = `${SF_ICONS.bolt} <span>Paste &amp; Download</span>`;
    pasteDlBtn.title = 'Paste video URL from clipboard and start download';
    pasteDlBtn.addEventListener('click', () => pasteAndSubmitUrl());

    const bestMp4Btn = document.createElement('button');
    bestMp4Btn.id = 'savefrom-best-mp4-btn';
    bestMp4Btn.className = 'kn-btn';
    bestMp4Btn.innerHTML = `${SF_ICONS.download} <span>Best MP4</span>`;
    bestMp4Btn.title = 'Click the highest quality direct MP4 download link';
    bestMp4Btn.addEventListener('click', () => triggerBestQualityDownload());

    const menuBtn = document.createElement('button');
    menuBtn.id = 'savefrom-site-menu-btn';
    menuBtn.className = 'kn-btn';
    menuBtn.innerHTML = `${SF_ICONS.menu} <span>Menu</span>`;
    menuBtn.title = 'Open SaveFrom Assistant Menu & UI Customizer';

    const minimizeBtn = document.createElement('button');
    minimizeBtn.id = 'savefrom-site-minimize-btn';
    minimizeBtn.className = 'kn-btn';
    minimizeBtn.innerHTML = SF_ICONS.minimize;
    minimizeBtn.title = 'Minimize SaveFrom Assistant';

    dock.appendChild(browserBadge);
    dock.appendChild(cleanModeBtn);
    dock.appendChild(pasteDlBtn);
    dock.appendChild(bestMp4Btn);
    dock.appendChild(menuBtn);
    dock.appendChild(minimizeBtn);

    container.appendChild(miniBtn);
    container.appendChild(menuPanel);
    container.appendChild(dock);
    document.body.appendChild(container);

    // --- Wire Up Menu & Dock Controls ---
    const syncMenuControls = () => {
      const onlyDl = document.getElementById('sf-menu-toggle-only-dl');
      const adBlk = document.getElementById('sf-menu-toggle-adblock');
      const helpBlk = document.getElementById('sf-menu-toggle-helper');
      const autoDl = document.getElementById('sf-menu-toggle-autodl');
      const themeSel = document.getElementById('sf-menu-theme-select');

      if (onlyDl) onlyDl.checked = Boolean(settings.sfOnlyDownloadSection);
      if (adBlk) adBlk.checked = Boolean(settings.sfAdBlockEnabled);
      if (helpBlk) helpBlk.checked = Boolean(settings.sfHideHelperPromos);
      if (autoDl) autoDl.checked = Boolean(settings.sfAutoDownloadBest);
      if (themeSel) themeSel.value = settings.sfTheme || 'midnight-glass';

      applyDockPosition(container, settings.sfDockPosition || 'bottom-right');
      updateAssistantBadges();
    };

    const toggleMenu = (forceState = null) => {
      const isVisible = menuPanel.style.display === 'block';
      const nextState = forceState !== null ? forceState : !isVisible;
      menuPanel.style.display = nextState ? 'block' : 'none';
      if (nextState) {
        menuBtn.classList.add('active');
        syncMenuControls();
      } else {
        menuBtn.classList.remove('active');
      }
    };

    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu();
    });
    browserBadge.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu(true);
    });
    document.getElementById('savefrom-menu-close-btn')?.addEventListener('click', () => toggleMenu(false));

    document.addEventListener('click', (e) => {
      if (!menuPanel.contains(e.target) && !menuBtn.contains(e.target) && !browserBadge.contains(e.target)) {
        if (menuPanel.style.display === 'block') toggleMenu(false);
      }
    });

    minimizeBtn.addEventListener('click', () => {
      dock.style.display = 'none';
      menuPanel.style.display = 'none';
      miniBtn.style.display = 'inline-flex';
    });

    miniBtn.addEventListener('click', () => {
      miniBtn.style.display = 'none';
      dock.style.display = 'flex';
    });

    menuPanel.querySelectorAll('.kn-pos-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const pos = btn.dataset.pos || 'bottom-right';
        saveAndApplySettings({ sfDockPosition: pos }, `Dock position: ${pos}`);
        applyDockPosition(container, pos);
      });
    });

    document.getElementById('sf-menu-toggle-only-dl')?.addEventListener('change', (e) => {
      saveAndApplySettings(
        { sfOnlyDownloadSection: e.target.checked, sfHideArticlesAndFooter: e.target.checked },
        e.target.checked ? 'Showing ONLY Download Section' : 'Restored full page sections'
      );
    });
    document.getElementById('sf-menu-toggle-adblock')?.addEventListener('change', (e) => {
      saveAndApplySettings(
        { sfAdBlockEnabled: e.target.checked, sfBlockPopups: e.target.checked },
        e.target.checked ? 'Ad & Popup Shield enabled' : 'Ad & Popup Shield paused'
      );
    });
    document.getElementById('sf-menu-toggle-helper')?.addEventListener('change', (e) => {
      saveAndApplySettings(
        { sfHideHelperPromos: e.target.checked },
        e.target.checked ? 'Hidden fake installer buttons' : 'Showing installer buttons'
      );
    });
    document.getElementById('sf-menu-toggle-autodl')?.addEventListener('change', (e) => {
      saveAndApplySettings(
        { sfAutoDownloadBest: e.target.checked },
        e.target.checked ? 'Auto-Download Best MP4 enabled' : 'Auto-Download Best MP4 disabled'
      );
    });
    document.getElementById('sf-menu-theme-select')?.addEventListener('change', (e) => {
      saveAndApplySettings({ sfTheme: e.target.value }, `Applied theme: ${e.target.value}`);
    });

    document.getElementById('sf-menu-paste-btn')?.addEventListener('click', () => {
      toggleMenu(false);
      pasteAndSubmitUrl();
    });
    document.getElementById('sf-menu-best-mp4-btn')?.addEventListener('click', () => {
      toggleMenu(false);
      triggerBestQualityDownload();
    });
    document.getElementById('sf-menu-clear-input-btn')?.addEventListener('click', () => {
      toggleMenu(false);
      clearInputAndResults();
    });
    document.getElementById('sf-menu-clear-cookies-btn')?.addEventListener('click', () => {
      toggleMenu(false);
      clearSaveFromCookiesAndStorage();
    });

    syncMenuControls();
  }

  function saveAndApplySettings(patch, toastMsg = null) {
    settings = { ...settings, ...patch };
    applyCustomStyles();
    enforceDownloadOnlyCleanLayout();
    scrubAdsAndPromos();
    updateAssistantBadges();
    try {
      chrome.storage.local.set(patch);
    } catch (e) {}
    if (toastMsg) showFloatingToast(toastMsg);
  }

  function forceFullRefresh() {
    applyCustomStyles();
    createSaveFromAssistantWidget();
    enforceDownloadOnlyCleanLayout();
    scrubAdsAndPromos();
    updateAssistantBadges();
  }

  window.__savefromAssistantForceRefresh = forceFullRefresh;

  // --- 6. Initialization, Continuous Observer & Runtime Messaging ---
  installPopupAndRedirectGuard();
  applyCustomStyles();

  try {
    chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS), (stored) => {
      if (stored) {
        settings = { ...DEFAULT_SETTINGS, ...stored };
      }
      forceFullRefresh();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      let changed = false;
      for (const k of Object.keys(DEFAULT_SETTINGS)) {
        if (changes[k] !== undefined) {
          settings[k] = changes[k].newValue;
          changed = true;
        }
      }
      if (changed) {
        forceFullRefresh();
      }
    });
  } catch (e) {
    forceFullRefresh();
  }

  const observer = new MutationObserver(() => {
    if (!document.getElementById('sf-customizer-styles')) {
      applyCustomStyles();
    }
    if (!document.getElementById('savefrom-site-toolbar') && document.body) {
      createSaveFromAssistantWidget();
    }
    scrubAdsAndPromos();
  });

  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', forceFullRefresh);
  } else {
    forceFullRefresh();
  }
  window.addEventListener('load', forceFullRefresh);
  setInterval(forceFullRefresh, 1200);

  try {
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
      if (!req || !req.action) return false;
      if (req.action === 'ping' || req.action === 'sf_get_status') {
        forceFullRefresh();
        sendResponse({
          pong: true,
          onSaveFrom: true,
          mode: 'SAVEFROM_CLEAN',
          sessionBlockedCount,
          settings
        });
        return false;
      }
      if (req.action === 'sf_update_settings') {
        saveAndApplySettings(req.settings || {});
        sendResponse({ success: true, settings });
        return false;
      }
      if (req.action === 'sf_paste_and_download') {
        pasteAndSubmitUrl(req.url || null).then((res) => sendResponse(res));
        return true;
      }
      if (req.action === 'sf_download_best_mp4') {
        sendResponse(triggerBestQualityDownload());
        return false;
      }
      if (req.action === 'clear_site_storage') {
        clearSaveFromCookiesAndStorage().then(() => sendResponse({ success: true }));
        return true;
      }
      return false;
    });
  } catch (e) {}
})();
