// popup.js - Knowunity Assistant v5.0 Popup Controller
// Features: Continuous Infinite Rotation Loop (Sign Up -> Apply Code -> Tapos Na -> Clear Cookie -> Back to Sign Up Landing Page -> Repeat Until Stopped),
// Instant Stop Rotation Control, Multi-Code Referral Pool, and 100% Vector Zero-Emoji UI.

const STATES = {
  IDLE: 'IDLE',
  STARTING: 'STARTING',
  STEP_1_SUCCESS: 'STEP_1_SUCCESS',
  REFERRAL_STEP: 'REFERRAL_STEP',
  ERROR: 'ERROR'
};

function debugLog(stage, message = '') {
  const ts = new Date().toISOString().substring(11, 23);
  console.log(`[Knowunity-Popup ${ts}] [${stage}]`, message);
}

function detectBrowserInfo() {
  const ua = navigator.userAgent || '';
  let name = 'Chromium';
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);

  if (/Lemur/i.test(ua)) {
    name = 'Lemur Browser';
  } else if (/Kiwi/i.test(ua)) {
    name = 'Kiwi Browser';
  } else if (/Brave/i.test(ua) || (navigator.brave && typeof navigator.brave.isBrave === 'function')) {
    name = 'Brave Browser';
  } else if (/EdgA?|Edge/i.test(ua)) {
    name = 'Microsoft Edge';
  } else if (/OPR|Opera/i.test(ua)) {
    name = 'Opera';
  } else if (/Vivaldi/i.test(ua)) {
    name = 'Vivaldi';
  } else if (/SamsungBrowser/i.test(ua)) {
    name = 'Samsung Internet';
  } else if (/Firefox|FxiOS/i.test(ua)) {
    name = 'Firefox';
  } else if (/Chrome|CriOS/i.test(ua)) {
    name = 'Google Chrome';
  }

  const shortName = name.replace(' Browser', '');
  return {
    name,
    shortName,
    isMobile,
    platform: isMobile ? 'Mobile' : 'Desktop',
    summary: `${name} (${isMobile ? 'Mobile' : 'Desktop'})`,
    badge: `${shortName} / ${isMobile ? 'Mobile' : 'Desktop'}`
  };
}

const POPUP_ICONS = {
  check:
    '<svg class="btn-icon-xs" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
  copy:
    '<svg class="btn-icon-xs" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  eye:
    '<svg class="btn-icon-xs" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeOff:
    '<svg class="btn-icon-xs" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>',
  trash:
    '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
  date:
    '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:middle;margin-right:4px;"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>'
};

function parseReferralPool(rawPool, fallbackDefault = 'NM3G4X') {
  if (Array.isArray(rawPool)) {
    const cleaned = rawPool
      .map(c => String(c || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))
      .filter(c => c.length >= 4);
    return cleaned.length > 0 ? cleaned : [fallbackDefault];
  }
  if (typeof rawPool === 'string' && rawPool.trim()) {
    const cleaned = rawPool
      .split(/[\s,;]+/)
      .map(c => c.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))
      .filter(c => c.length >= 4);
    return cleaned.length > 0 ? cleaned : [fallbackDefault];
  }
  return [fallbackDefault];
}

function initPopup() {
  debugLog('INIT', 'Glass UI Popup v5.0 initializing.');

  const $ = id => document.getElementById(id);

  const detectedBrowserVersion = $('detectedBrowserVersion');
  const browserNameText = $('browserNameText');

  const startBtn = $('startBtn') || $('workflowBtn');
  const stopRotationBtn = $('stopRotationBtn');
  const resetBtn = $('resetBtn') || $('resetWorkflowBtn');
  const autoClearCookiesToggle = $('autoClearCookiesToggle');
  const autoRotateLoopToggle = $('autoRotateLoopToggle');
  const rotationCycleBadge = $('rotationCycleBadge');
  const nextCodeDisplay = $('nextCodeDisplay');

  const referralCodeInput = $('referralCodeInput');
  const applyReferralBtn = $('applyReferralBtn');
  const setDefaultReferralBtn = $('setDefaultReferralBtn');
  const defaultCodeDisplay = $('defaultCodeDisplay');
  const rotationPoolInput = $('rotationPoolInput');
  const saveRotationPoolBtn = $('saveRotationPoolBtn');
  const referralStatus = $('referralStatus');

  const domainSelect = $('domain') || $('domainSelect');
  const customDomainGroup = $('customDomainGroup');
  const customDomainInput = $('customDomainInput');
  const emailInput = $('email') || $('emailInput');
  const passwordInput = $('password') || $('passwordInput');
  const togglePasswordBtn = $('togglePassword') || $('togglePasswordBtn');
  const savedCountBadge = $('savedCount') || $('historyCountBadge');

  const workflowTitle = $('workflowTitle') || $('statusTitle');
  const workflowMessage = $('workflowMessage') || $('statusDesc');
  const step1 = $('step1') || $('step1Indicator');
  const step2 = $('step2') || $('step2Indicator');
  const pageStatePill = $('pageState') || $('pageModeBadge');
  const checkBtn = $('checkBtn') || $('detectPageModeBtn');
  const toastEl = $('toast');

  const historyCountBadge = $('historyCountBadge');
  const historyListContainer = $('historyListContainer');
  const clearAllHistoryBtn = $('clearAllHistoryBtn');
  const historyConfirmModal = $('historyConfirmModal');
  const confirmClearHistoryBtn = $('confirmClearHistoryBtn');
  const cancelClearHistoryBtn = $('cancelClearHistoryBtn');

  const reloadBtn = $('reloadBtn') || $('reloadPageBtn');
  const cookiesBtn = $('cookiesBtn') || $('clearCookiesBtn');
  const dataBtn = $('dataBtn') || $('clearExtensionDataBtn');

  const cookieConfirmModal = $('cookieConfirmModal');
  const cookieTargetHost = $('cookieTargetHost');
  const confirmClearCookiesBtn = $('confirmClearCookiesBtn');
  const cancelClearCookiesBtn = $('cancelClearCookiesBtn');

  if (!startBtn) return;

  const browserInfo = detectBrowserInfo();
  if (browserNameText) {
    browserNameText.textContent = `v5.0 / ${browserInfo.name}`;
  } else if (detectedBrowserVersion) {
    detectedBrowserVersion.textContent = `v5.0 / ${browserInfo.name}`;
  }
  if (detectedBrowserVersion) {
    detectedBrowserVersion.title = browserInfo.summary;
  }

  let currentState = STATES.IDLE;
  let isLocked = false;
  let isCookieOperationRunning = false;
  let activeEmail = '';
  let activePassword = '';
  let currentWorkflowToken = 0;
  let pendingCookieTab = null;
  let toastTimer = null;

  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2800);
  }

  function setStepper(step) {
    if (step === 1) {
      if (step1) step1.className = 'step active';
      if (step2) step2.className = 'step';
    } else if (step === 2) {
      if (step1) step1.className = 'step';
      if (step2) step2.className = 'step active';
    }
  }

  function updateHistoryBadge() {
    if (typeof EmailGenerator !== 'undefined' && EmailGenerator.getHistory && savedCountBadge) {
      const history = EmailGenerator.getHistory();
      savedCountBadge.textContent = `${history.length} saved`;
    }
  }

  function getSelectedDomain() {
    if (domainSelect && domainSelect.value === 'custom') {
      return (customDomainInput && customDomainInput.value.trim()) || 'gmail.com';
    }
    return (domainSelect && domainSelect.value) || 'gmail.com';
  }

  function showStatusMessage(title, message, isError = false) {
    if (workflowTitle) workflowTitle.textContent = title;
    if (workflowMessage) workflowMessage.textContent = message;
    if (isError) showToast(message);
  }

  function transitionTo(state, payload = {}) {
    currentState = state;

    switch (state) {
      case STATES.IDLE:
        startBtn.disabled = false;
        startBtn.classList.remove('state-busy');
        showStatusMessage(
          payload.title || 'Workflow Ready',
          payload.message || 'Click Magsimula All-in-One to start continuous rotation until stopped.'
        );
        setStepper(1);
        isLocked = false;
        break;

      case STATES.STARTING:
        startBtn.disabled = true;
        showStatusMessage(
          payload.title || 'Stage 1: Processing',
          payload.message || 'Clearing cookies, rotating code, and running workflow...'
        );
        setStepper(1);
        break;

      case STATES.STEP_1_SUCCESS:
      case STATES.REFERRAL_STEP:
        startBtn.disabled = false;
        showStatusMessage(
          payload.title || 'Cycle Complete — Auto-Loop Active',
          payload.message ||
            'Referral applied & Tapos Na clicked! Clearing cookies and restarting Sign Up automatically...'
        );
        setStepper(2);
        isLocked = false;
        break;

      case STATES.ERROR:
        startBtn.disabled = false;
        showStatusMessage('Workflow Stopped', payload.error || 'An unexpected error occurred.', true);
        isLocked = false;
        break;
    }

    try {
      chrome.storage.local.set({
        popupState: currentState,
        popupStatusTitle: (workflowTitle && workflowTitle.textContent) || '',
        popupStatusDesc: (workflowMessage && workflowMessage.textContent) || ''
      });
    } catch (e) {}
  }

  function isRealWebTab(tab) {
    if (!tab) return false;
    const u = (tab.url || tab.pendingUrl || '').toLowerCase();
    if (!u) return false;
    if (
      u.startsWith('chrome-extension://') ||
      u.startsWith('moz-extension://') ||
      u.startsWith('edge-extension://') ||
      u.startsWith('chrome://') ||
      u.startsWith('about:') ||
      u.startsWith('devtools://')
    ) {
      return false;
    }
    return u.startsWith('http://') || u.startsWith('https://');
  }

  function isKnowunityTab(tab) {
    const u = (tab && (tab.url || tab.pendingUrl || '')).toLowerCase();
    return u.includes('knowunity.ph') || u.includes('knowunity.com') || u.includes('knowunity.de');
  }

  async function getTargetTab() {
    try {
      const lastFocused = await new Promise(resolve => {
        try {
          chrome.tabs.query({ active: true, lastFocusedWindow: true }, tabs => {
            if (chrome.runtime.lastError || !tabs) resolve([]);
            else resolve(tabs.filter(isRealWebTab));
          });
        } catch (e) {
          resolve([]);
        }
      });
      if (lastFocused.length > 0) return lastFocused[0];

      const allActive = await new Promise(resolve => {
        try {
          chrome.tabs.query({ active: true }, tabs => {
            if (chrome.runtime.lastError || !tabs) resolve([]);
            else resolve(tabs.filter(isRealWebTab));
          });
        } catch (e) {
          resolve([]);
        }
      });

      if (allActive.length > 0) {
        return allActive.find(isKnowunityTab) || allActive[0];
      }

      const allTabs = await new Promise(resolve => {
        try {
          chrome.tabs.query({}, tabs => {
            if (chrome.runtime.lastError || !tabs) resolve([]);
            else resolve(tabs.filter(isRealWebTab));
          });
        } catch (e) {
          resolve([]);
        }
      });

      if (allTabs.length > 0) {
        return allTabs.find(isKnowunityTab) || allTabs[0];
      }

      return null;
    } catch (err) {
      return null;
    }
  }

  async function sendTabMessageWithRetry(tabId, message, maxRetries = 3) {
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const response = await new Promise((resolve, reject) => {
          chrome.tabs.sendMessage(tabId, message, res => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(res);
          });
        });
        return response;
      } catch (err) {
        lastError = err;
        try {
          await chrome.scripting.executeScript({
            target: { tabId },
            files: ['email_generator.js', 'password_generator.js', 'content.js']
          });
        } catch (e) {}
        await new Promise(r => setTimeout(r, 350));
      }
    }
    throw new Error(
      `Communication with page failed: ${lastError ? lastError.message : 'No response from tab'}`
    );
  }

  async function getCookiesForSite(tabUrl) {
    const urlObj = new URL(tabUrl);
    const hostname = urlObj.hostname.toLowerCase();
    const rootDomain = hostname.replace(/^www\./, '');
    const cookieMap = new Map();

    const addCookies = cookies => {
      if (Array.isArray(cookies)) {
        for (const c of cookies) {
          const cDomain = (c.domain || '').toLowerCase().replace(/^\./, '');
          if (hostname.endsWith(cDomain) || cDomain.endsWith(rootDomain) || cDomain === hostname) {
            const key = `${c.name}|${c.domain}|${c.path}|${c.storeId}`;
            cookieMap.set(key, c);
          }
        }
      }
    };

    await new Promise(resolve => {
      try {
        chrome.cookies.getAll({ url: tabUrl }, cookies => {
          if (!chrome.runtime.lastError) addCookies(cookies);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });

    await new Promise(resolve => {
      try {
        chrome.cookies.getAll({ domain: rootDomain }, cookies => {
          if (!chrome.runtime.lastError) addCookies(cookies);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });

    await new Promise(resolve => {
      try {
        chrome.cookies.getAll({ domain: '.' + rootDomain }, cookies => {
          if (!chrome.runtime.lastError) addCookies(cookies);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });

    return Array.from(cookieMap.values());
  }

  function removeSingleCookie(cookie) {
    return new Promise(resolve => {
      const domain = (cookie.domain || '').replace(/^\./, '');
      const path = cookie.path && cookie.path.startsWith('/') ? cookie.path : '/' + (cookie.path || '');
      const secureUrl = `https://${domain}${path}`;
      const httpUrl = `http://${domain}${path}`;

      const reqPrimary = {
        url: secureUrl,
        name: cookie.name,
        storeId: cookie.storeId
      };

      if (cookie.partitionKey && typeof cookie.partitionKey === 'object' && cookie.partitionKey.topLevelSite) {
        reqPrimary.partitionKey = cookie.partitionKey;
      }

      try {
        chrome.cookies.remove(reqPrimary, resPrimary => {
          if (!chrome.runtime.lastError && resPrimary) {
            return resolve({ success: true });
          }

          const reqNoPartition = {
            url: secureUrl,
            name: cookie.name,
            storeId: cookie.storeId
          };

          try {
            chrome.cookies.remove(reqNoPartition, resSecond => {
              if (!chrome.runtime.lastError && resSecond) {
                return resolve({ success: true });
              }

              if (!cookie.secure) {
                const reqHttp = {
                  url: httpUrl,
                  name: cookie.name,
                  storeId: cookie.storeId
                };
                chrome.cookies.remove(reqHttp, resThird => {
                  if (!chrome.runtime.lastError && resThird) {
                    return resolve({ success: true });
                  }
                  const errMsg =
                    (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Removal returned null';
                  resolve({ success: false, error: errMsg });
                });
              } else {
                const errMsg =
                  (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Removal returned null';
                resolve({ success: false, error: errMsg });
              }
            });
          } catch (e2) {
            resolve({ success: false, error: e2.message });
          }
        });
      } catch (e1) {
        resolve({ success: false, error: e1.message });
      }
    });
  }

  async function silentClearTabCookiesAndStorage(tab) {
    if (!tab || !tab.url) return 0;
    let removedCount = 0;
    try {
      const cookiesToRemove = await getCookiesForSite(tab.url);
      for (const c of cookiesToRemove) {
        const res = await removeSingleCookie(c);
        if (res.success) removedCount++;
      }
    } catch (e) {}

    try {
      await sendTabMessageWithRetry(tab.id, { action: 'clear_site_storage' }, 2);
    } catch (e) {}

    return removedCount;
  }

  // --- Stop Continuous Rotation Loop Handler ---
  async function stopContinuousRotation() {
    currentWorkflowToken++;
    isLocked = false;

    await chrome.storage.local.remove(['masterWorkflowActive', 'workflowStep', 'workflowStartTime']);
    await chrome.storage.local.set({
      rotationLoopActive: false
    });

    try {
      const target = await getTargetTab();
      if (target && target.id) {
        chrome.tabs.sendMessage(target.id, { action: 'stop_rotation_workflow' }, () => {});
      }
    } catch (e) {}

    transitionTo(STATES.IDLE, {
      title: 'Rotation Loop Stopped',
      message: 'Continuous auto-rotation was stopped by user. Click Magsimula All-in-One to start again.'
    });
    showToast('Rotation workflow stopped!');
  }

  // --- 1. Authoritative Step 1 Handler (Magsimula All-in-One with Continuous Rotation) ---
  async function runStep1Workflow() {
    if (isLocked) return;
    isLocked = true;
    const workflowToken = ++currentWorkflowToken;

    try {
      transitionTo(STATES.STARTING, { message: 'Checking configuration...' });
      const domain = getSelectedDomain();
      if (typeof EmailGenerator === 'undefined') {
        throw new Error('EmailGenerator module is not loaded.');
      }
      const domainCheck = EmailGenerator.validateDomain(domain);
      if (!domainCheck.valid) {
        transitionTo(STATES.ERROR, { error: domainCheck.error });
        return;
      }

      transitionTo(STATES.STARTING, { message: 'Locating active Knowunity tab...' });
      const target = await getTargetTab();
      const targetUrl = (target && (target.url || target.pendingUrl || '')).toLowerCase();

      if (!target || (!targetUrl.includes('knowunity.ph') && !targetUrl.includes('knowunity.com'))) {
        throw new Error('Please open https://knowunity.ph/ in your browser before starting Magsimula.');
      }

      const storageState = await new Promise(r =>
        chrome.storage.local.get(
          [
            'defaultReferralCode',
            'referralRotationPool',
            'rotationIndex',
            'rotationCycleCount',
            'autoClearOnStart',
            'autoRotateLoop',
            'lastGeneratedPassword'
          ],
          r
        )
      );

      const defaultCode = (storageState && storageState.defaultReferralCode) || 'NM3G4X';
      const pool = parseReferralPool(
        (rotationPoolInput && rotationPoolInput.value) || (storageState && storageState.referralRotationPool),
        defaultCode
      );
      const rotIdx = parseInt((storageState && storageState.rotationIndex) || 0, 10) || 0;
      const cycleCount = (parseInt((storageState && storageState.rotationCycleCount) || 0, 10) || 0) + 1;

      const typedCode = referralCodeInput && referralCodeInput.value.trim().toUpperCase();
      let selectedReferralCode;
      if (pool.length > 1) {
        selectedReferralCode = pool[rotIdx % pool.length] || defaultCode;
      } else {
        selectedReferralCode = typedCode || pool[0] || defaultCode;
      }
      const nextIdx = (rotIdx + 1) % pool.length;
      const nextCode = pool[nextIdx] || selectedReferralCode;

      const shouldAutoClear = autoClearCookiesToggle
        ? autoClearCookiesToggle.checked
        : storageState && typeof storageState.autoClearOnStart === 'boolean'
        ? storageState.autoClearOnStart
        : true;

      const shouldAutoLoop = autoRotateLoopToggle
        ? autoRotateLoopToggle.checked
        : storageState && typeof storageState.autoRotateLoop === 'boolean'
        ? storageState.autoRotateLoop
        : true;

      if (rotationCycleBadge) rotationCycleBadge.textContent = `Cycle #${cycleCount}`;
      if (nextCodeDisplay) nextCodeDisplay.textContent = nextCode;
      if (referralCodeInput) referralCodeInput.value = selectedReferralCode;

      await chrome.storage.local.set({
        rotationIndex: nextIdx,
        rotationCycleCount: cycleCount,
        referralRotationPool: pool,
        lastReferralCode: selectedReferralCode,
        autoClearOnStart: shouldAutoClear,
        autoRotateLoop: shouldAutoLoop,
        rotationLoopActive: shouldAutoLoop,
        selectedDomain: domain
      });

      if (shouldAutoClear) {
        transitionTo(STATES.STARTING, {
          title: `Cycle #${cycleCount}: Clearing Cookies`,
          message: 'Wiping Knowunity cookies and local session storage...'
        });
        await silentClearTabCookiesAndStorage(target);
      }

      transitionTo(STATES.STARTING, { message: 'Connecting to Knowunity page...' });
      await sendTabMessageWithRetry(target.id, { action: 'ping' });

      transitionTo(STATES.STARTING, { message: 'Detecting page mode (Login vs Sign Up)...' });
      const modeRes = await sendTabMessageWithRetry(target.id, { action: 'detect_page_mode' });
      const mode = (modeRes && modeRes.mode) || 'UNKNOWN';

      if (mode === 'LOGIN') {
        transitionTo(STATES.STARTING, { message: 'Login page detected. Switching to Sign Up...' });
        const switchRes = await sendTabMessageWithRetry(target.id, { action: 'switch_to_signup' });
        if (!switchRes || !switchRes.success) {
          throw new Error((switchRes && switchRes.message) || 'Failed to switch from Login to Sign-Up mode.');
        }
        await new Promise(r => setTimeout(r, 600));
      } else if (mode === 'UNKNOWN') {
        transitionTo(STATES.STARTING, { message: 'Opening registration form...' });
        chrome.tabs.sendMessage(target.id, { action: 'click_magsimula' }, () => {});
        await new Promise(r => setTimeout(r, 1200));
        try {
          const tab = await chrome.tabs.get(target.id);
          if (tab && tab.status === 'loading') {
            await new Promise(r => setTimeout(r, 800));
          }
        } catch (e) {}
      }

      transitionTo(STATES.STARTING, { message: 'Generating unique test credentials...' });
      const emailResult = EmailGenerator.generateEmail(domain);
      if (!emailResult.success) {
        throw new Error(emailResult.error);
      }
      activeEmail = emailResult.email;
      if (
        storageState &&
        storageState.lastGeneratedPassword &&
        storageState.lastGeneratedPassword.length >= 8
      ) {
        activePassword = storageState.lastGeneratedPassword;
      } else {
        activePassword = PasswordGenerator.generatePassword(14);
      }

      if (emailInput) emailInput.value = activeEmail;
      if (passwordInput) passwordInput.value = activePassword;
      updateHistoryBadge();

      await saveCredentialToHistory(activeEmail, activePassword, selectedReferralCode, cycleCount);
      await chrome.storage.local.set({
        lastGeneratedEmail: activeEmail,
        lastGeneratedPassword: activePassword,
        lastReferralCode: selectedReferralCode,
        emailHistory: EmailGenerator.getHistory()
      });

      transitionTo(STATES.STARTING, {
        title: `Cycle #${cycleCount}: Registering & Looping`,
        message: `Populating form and applying rotated code "${selectedReferralCode}"...`
      });
      const autofillResponse = await sendTabMessageWithRetry(target.id, {
        action: 'autofill_registration_form',
        email: activeEmail,
        password: activePassword,
        referralCode: selectedReferralCode
      });

      if (!autofillResponse || !autofillResponse.success) {
        throw new Error((autofillResponse && autofillResponse.message) || 'Failed to populate registration fields.');
      }

      if (workflowToken !== currentWorkflowToken) return;

      showToast(`Cycle #${cycleCount} Complete! Auto-clearing cookies for next cycle...`);
      transitionTo(STATES.STEP_1_SUCCESS, {
        title: `Cycle #${cycleCount} Done — Auto-Looping`,
        message:
          'Referral applied & Tapos Na clicked! Automatically clearing cookies and returning to Sign Up until stopped.'
      });

      detectAndDisplayPageMode();
    } catch (err) {
      transitionTo(STATES.ERROR, { error: err.message });
    } finally {
      isLocked = false;
    }
  }

  // --- 2. Step 2: Dedicated Referral Code Handler ---
  async function applyReferralCode() {
    const refData = await new Promise(r => chrome.storage.local.get(['defaultReferralCode'], r));
    const defaultCode = (refData && refData.defaultReferralCode) || 'NM3G4X';
    const code = (referralCodeInput && referralCodeInput.value.trim()) || defaultCode;
    if (referralStatus) referralStatus.textContent = '';

    if (!code) {
      if (referralStatus) {
        referralStatus.textContent = 'Validation Error: Please enter or paste a 6-character referral code.';
        referralStatus.style.color = '#dc2626';
      }
      showToast('Please enter a referral code.');
      return;
    }

    if (applyReferralBtn) applyReferralBtn.disabled = true;
    if (referralStatus) {
      referralStatus.textContent = 'Locating referral section, filling 6 boxes, and triggering apply...';
      referralStatus.style.color = '#1d4ed8';
    }

    try {
      const target = await getTargetTab();
      const targetUrl = (target && (target.url || target.pendingUrl || '')).toLowerCase();
      if (!target || (!targetUrl.includes('knowunity.ph') && !targetUrl.includes('knowunity.com'))) {
        throw new Error('Please open Knowunity in your browser tab.');
      }

      chrome.storage.local.set({ lastReferralCode: code });

      const res = await sendTabMessageWithRetry(target.id, {
        action: 'apply_referral_code',
        code
      });

      if (res && res.success) {
        if (referralStatus) {
          referralStatus.textContent = res.message;
          referralStatus.style.color = '#15803d';
        }
        showToast('6-Box Referral code applied & clicked!');
      } else {
        if (referralStatus) {
          referralStatus.textContent = (res && res.message) || 'Referral section not found on page.';
          referralStatus.style.color = '#dc2626';
        }
        showToast('Referral code section not found.');
      }
    } catch (err) {
      if (referralStatus) {
        referralStatus.textContent = 'Error: ' + err.message;
        referralStatus.style.color = '#dc2626';
      }
      showToast('Referral application failed.');
    } finally {
      if (applyReferralBtn) applyReferralBtn.disabled = false;
    }
  }

  // --- 3. Reset Workflow & Rotation Counter Handler ---
  async function resetWorkflow() {
    await stopContinuousRotation();

    activeEmail = '';
    activePassword = '';
    if (emailInput) emailInput.value = '';
    if (passwordInput) passwordInput.value = '';

    const refData = await new Promise(r =>
      chrome.storage.local.get(['defaultReferralCode', 'referralRotationPool'], r)
    );
    const defCode = (refData && refData.defaultReferralCode) || 'NM3G4X';
    const pool = parseReferralPool(refData && refData.referralRotationPool, defCode);

    await chrome.storage.local.set({
      rotationIndex: 0,
      rotationCycleCount: 0,
      autoRotateLoop: true,
      rotationLoopActive: false
    });

    if (referralCodeInput) referralCodeInput.value = defCode;
    if (defaultCodeDisplay) defaultCodeDisplay.textContent = defCode;
    if (rotationCycleBadge) rotationCycleBadge.textContent = 'Cycle #0';
    if (nextCodeDisplay) nextCodeDisplay.textContent = pool[0] || defCode;
    if (autoRotateLoopToggle) autoRotateLoopToggle.checked = true;
    if (referralStatus) referralStatus.textContent = '';

    transitionTo(STATES.IDLE);
    showToast('Workflow & rotation counter reset.');
  }

  async function loadAndRenderHistory() {
    try {
      const data = await new Promise(r => chrome.storage.local.get(['credentialsHistory'], r));
      const list = Array.isArray(data && data.credentialsHistory) ? data.credentialsHistory : [];
      renderHistoryList(list);
    } catch (e) {}
  }

  async function saveCredentialToHistory(email, password, referralCode = 'NM3G4X', cycle = null) {
    if (!email || typeof email !== 'string' || !email.includes('@')) return;
    if (!password || typeof password !== 'string') return;

    try {
      const data = await new Promise(r => chrome.storage.local.get(['credentialsHistory'], r));
      const list = Array.isArray(data && data.credentialsHistory) ? data.credentialsHistory : [];

      const exists = list.some(
        item => item.email && item.email.toLowerCase() === email.trim().toLowerCase()
      );
      if (exists) return;

      const newEntry = {
        id: 'cred_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        email: email.trim(),
        password,
        referralCode: referralCode || 'NM3G4X',
        cycle,
        timestamp: Date.now(),
        createdAt: new Date().toISOString()
      };

      const updated = [newEntry, ...list];
      await chrome.storage.local.set({ credentialsHistory: updated });
      renderHistoryList(updated);
    } catch (e) {}
  }

  async function deleteHistoryItem(id) {
    if (!id) return;
    try {
      const data = await new Promise(r => chrome.storage.local.get(['credentialsHistory'], r));
      const list = Array.isArray(data && data.credentialsHistory) ? data.credentialsHistory : [];
      const updated = list.filter(item => item.id !== id);
      await chrome.storage.local.set({ credentialsHistory: updated });
      renderHistoryList(updated);
      showToast('Entry deleted from history.');
    } catch (e) {}
  }

  function promptClearAllHistory() {
    if (historyConfirmModal) historyConfirmModal.style.display = 'flex';
  }

  function cancelClearAllHistory() {
    if (historyConfirmModal) historyConfirmModal.style.display = 'none';
  }

  async function executeClearAllHistory() {
    try {
      await chrome.storage.local.set({ credentialsHistory: [] });
      if (historyConfirmModal) historyConfirmModal.style.display = 'none';
      renderHistoryList([]);
      showToast('Cleared all credentials history.');
    } catch (e) {
      if (historyConfirmModal) historyConfirmModal.style.display = 'none';
    }
  }

  function renderHistoryList(items) {
    if (!historyListContainer) return;
    const list = Array.isArray(items) ? [...items] : [];
    list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

    if (historyCountBadge) historyCountBadge.textContent = `${list.length} saved`;
    if (savedCountBadge) savedCountBadge.textContent = `${list.length} saved`;

    if (list.length === 0) {
      historyListContainer.innerHTML = `
        <div class="history-empty">
          <div class="history-empty-icon"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
          <strong>No generated accounts yet</strong>
          <p>Accounts generated via Magsimula All-in-One will automatically be archived here with their passwords and referral codes.</p>
        </div>
      `;
      return;
    }

    let html = '';
    for (const item of list) {
      const dateStr = item.timestamp
        ? new Date(item.timestamp).toLocaleString([], {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
          })
        : 'Recently generated';

      const emailEsc = escapeHtml(item.email || '');
      const passEsc = escapeHtml(item.password || '');
      const codeEsc = escapeHtml(item.referralCode || 'NM3G4X');
      const cycleTag = item.cycle ? ` / #${escapeHtml(String(item.cycle))}` : '';
      const maskedPass = '************';

      html += `
        <div class="history-card" data-id="${item.id}">
          <div class="history-card-top">
            <span class="history-date">${POPUP_ICONS.date}${dateStr} (Code: ${codeEsc}${cycleTag})</span>
            <button type="button" class="history-delete-btn" data-action="delete" data-id="${item.id}" title="Delete this entry">${POPUP_ICONS.trash}</button>
          </div>
          <div class="history-item-row">
            <span class="history-item-label">Email:</span>
            <span class="history-item-val" title="${emailEsc}">${emailEsc}</span>
            <div class="history-item-actions">
              <button type="button" class="history-action-btn" data-action="copy-email" data-val="${emailEsc}" title="Copy Email">${POPUP_ICONS.copy}<span>Copy</span></button>
            </div>
          </div>
          <div class="history-item-row">
            <span class="history-item-label">Password:</span>
            <span class="history-item-val pass-field masked" data-plain="${passEsc}">${maskedPass}</span>
            <div class="history-item-actions">
              <button type="button" class="history-action-btn" data-action="toggle-pass" title="Show/Hide Password">${POPUP_ICONS.eye}</button>
              <button type="button" class="history-action-btn" data-action="copy-pass" data-val="${passEsc}" title="Copy Password">${POPUP_ICONS.copy}<span>Copy</span></button>
            </div>
          </div>
        </div>
      `;
    }

    historyListContainer.innerHTML = html;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  async function copyToClipboard(text) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const tempInp = document.createElement('textarea');
      tempInp.value = text;
      tempInp.style.position = 'fixed';
      tempInp.style.opacity = '0';
      document.body.appendChild(tempInp);
      tempInp.select();
      document.execCommand('copy');
      document.body.removeChild(tempInp);
    }
  }

  async function reloadActivePage() {
    if (reloadBtn) reloadBtn.disabled = true;
    showStatusMessage('Reloading...', 'Refreshing active browser tab...');

    try {
      const target = await getTargetTab();
      if (!target || !target.id) {
        throw new Error('Could not identify an active browser tab.');
      }

      await new Promise((resolve, reject) => {
        try {
          chrome.tabs.reload(target.id, { bypassCache: true }, () => {
            if (chrome.runtime.lastError) {
              chrome.tabs.reload(target.id, () => {
                if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                else resolve();
              });
            } else {
              resolve();
            }
          });
        } catch (e) {
          try {
            chrome.tabs.reload(target.id);
            resolve();
          } catch (e2) {
            reject(e);
          }
        }
      });

      showStatusMessage('Page Reloaded', `Reloaded active tab: ${target.url || 'Current Website'}`);
      showToast('Page reloaded successfully.');
      setTimeout(detectAndDisplayPageMode, 1500);
    } catch (err) {
      showStatusMessage('Reload Failed', 'Failed to reload page: ' + err.message, true);
    } finally {
      if (reloadBtn) reloadBtn.disabled = false;
    }
  }

  async function clearExtensionData() {
    try {
      await stopContinuousRotation();
      await chrome.storage.local.clear();

      activeEmail = '';
      activePassword = '';
      if (emailInput) emailInput.value = '';
      if (passwordInput) passwordInput.value = '';
      if (referralCodeInput) referralCodeInput.value = 'NM3G4X';
      if (defaultCodeDisplay) defaultCodeDisplay.textContent = 'NM3G4X';
      if (rotationPoolInput) rotationPoolInput.value = 'NM3G4X';
      if (rotationCycleBadge) rotationCycleBadge.textContent = 'Cycle #0';
      if (nextCodeDisplay) nextCodeDisplay.textContent = 'NM3G4X';
      if (autoClearCookiesToggle) autoClearCookiesToggle.checked = true;
      if (autoRotateLoopToggle) autoRotateLoopToggle.checked = true;
      if (referralStatus) referralStatus.textContent = '';
      if (savedCountBadge) savedCountBadge.textContent = '0 saved';

      if (typeof EmailGenerator !== 'undefined' && EmailGenerator.clearHistory) {
        EmailGenerator.clearHistory();
      }
      renderHistoryList([]);

      transitionTo(STATES.IDLE);
      showStatusMessage(
        'Extension Data Cleared',
        'Saved test credentials, history, and rotation state cleared. Website cookies were preserved.'
      );
      showToast('Extension storage cleared.');
    } catch (err) {
      showStatusMessage('Storage Error', 'Failed to clear extension storage: ' + err.message, true);
    }
  }

  async function sendSaveFromMessageWithInject(tabId, message) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const res = await new Promise((resolve, reject) => {
          chrome.tabs.sendMessage(tabId, message, (r) => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          });
        });
        return res;
      } catch (err) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId },
            files: ['savefrom_content.js']
          });
        } catch (e) {}
        await new Promise((r) => setTimeout(r, 250));
      }
    }
    return null;
  }

  async function detectAndDisplayPageMode() {
    if (!pageStatePill) return;
    pageStatePill.textContent = 'Detecting...';
    pageStatePill.className = 'pill mode-detecting';

    try {
      const target = await getTargetTab();
      const rawUrl = (target && (target.url || target.pendingUrl || '')).toLowerCase();

      if (target && (rawUrl.includes('savefrom.net') || rawUrl.includes('sfrom.net'))) {
        pageStatePill.textContent = 'SaveFrom Active';
        pageStatePill.className = 'pill mode-signup';
        await sendSaveFromMessageWithInject(target.id, { action: 'sf_get_status' });
        showStatusMessage(
          'SaveFrom Assistant Active',
          'Ultra-Clean Download-Only UI & Ad-Shield are active on en1.savefrom.net.'
        );
        return;
      }

      if (!target || (!rawUrl.includes('knowunity.ph') && !rawUrl.includes('knowunity.com'))) {
        pageStatePill.textContent = 'Other Site';
        pageStatePill.className = 'pill mode-other';
        return;
      }

      const res = await sendTabMessageWithRetry(target.id, { action: 'detect_page_mode' });
      const mode = (res && res.mode) || 'UNKNOWN';

      if (mode === 'SIGN_UP') {
        pageStatePill.textContent = 'Sign-Up';
        pageStatePill.className = 'pill mode-signup';
      } else if (mode === 'LOGIN') {
        pageStatePill.textContent = 'Log-In';
        pageStatePill.className = 'pill mode-login';
      } else {
        pageStatePill.textContent = 'Landing/Main';
        pageStatePill.className = 'pill mode-landing';
      }
    } catch (err) {
      pageStatePill.textContent = 'Ready';
      pageStatePill.className = 'pill mode-other';
    }
  }

  async function promptClearWebsiteCookies() {
    if (isCookieOperationRunning) return;

    try {
      const target = await getTargetTab();
      if (!target || !target.url) {
        showStatusMessage(
          'Cookie Cleaner Error',
          'Cannot identify an active website. Please make sure a web page is open.',
          true
        );
        return;
      }

      let urlObj;
      try {
        urlObj = new URL(target.url);
      } catch (e) {
        showStatusMessage('Invalid URL', `Tab URL "${target.url}" is not a valid web address.`, true);
        return;
      }

      if (urlObj.protocol !== 'http:' && urlObj.protocol !== 'https:') {
        showStatusMessage(
          'Unsupported Protocol',
          `Cannot clear cookies for non-web page: ${target.url}`,
          true
        );
        return;
      }

      pendingCookieTab = target;
      if (cookieTargetHost) cookieTargetHost.textContent = urlObj.hostname;
      if (cookieConfirmModal) cookieConfirmModal.style.display = 'flex';
    } catch (err) {
      showStatusMessage('Cookie Error', 'Failed to inspect active tab: ' + err.message, true);
    }
  }

  function cancelClearWebsiteCookies() {
    pendingCookieTab = null;
    if (cookieConfirmModal) cookieConfirmModal.style.display = 'none';
    showStatusMessage('Cookie Operation Canceled', 'Cookie removal was canceled.');
  }

  async function executeClearWebsiteCookies() {
    if (cookieConfirmModal) cookieConfirmModal.style.display = 'none';

    const tab = pendingCookieTab;
    pendingCookieTab = null;

    if (!tab || !tab.url) {
      showStatusMessage('Error', 'Active tab reference was lost. Please tap Clear Cookies again.', true);
      return;
    }

    isCookieOperationRunning = true;
    if (cookiesBtn) cookiesBtn.disabled = true;

    let urlObj;
    try {
      urlObj = new URL(tab.url);
    } catch (e) {
      restoreCookieButton();
      showStatusMessage('Error', 'Invalid tab URL format.', true);
      return;
    }

    const targetHost = urlObj.hostname;
    showStatusMessage('Cleaning Session', `Removing cookies and clearing site storage for ${targetHost}...`);

    try {
      const cookiesToRemove = await getCookiesForSite(tab.url);
      let removedCount = 0;

      for (const cookie of cookiesToRemove) {
        const res = await removeSingleCookie(cookie);
        if (res.success) removedCount++;
      }

      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            try {
              window.localStorage.clear();
            } catch (e) {}
            try {
              window.sessionStorage.clear();
            } catch (e) {}
            try {
              document.cookie.split(';').forEach(c => {
                document.cookie = c
                  .replace(/^ +/, '')
                  .replace(/=.*/, '=;expires=' + new Date(0).toUTCString() + ';path=/');
                document.cookie = c
                  .replace(/^ +/, '')
                  .replace(
                    /=.*/,
                    '=;expires=' + new Date(0).toUTCString() + ';path=/;domain=' + location.hostname
                  );
              });
            } catch (e) {}
          }
        });
      } catch (scriptErr) {
        chrome.tabs.sendMessage(tab.id, { action: 'clear_site_storage' }, () => {});
      }

      try {
        await new Promise(r => {
          chrome.tabs.reload(tab.id, { bypassCache: true }, () => r());
        });
      } catch (reloadErr) {}

      showStatusMessage(
        'Session Cleared',
        `Successfully removed ${removedCount} cookie(s) and cleared local session storage for ${targetHost}. Tab reloaded!`
      );
      showToast('Cookies & session cleared! Tab reloaded.');
      setTimeout(detectAndDisplayPageMode, 1500);
    } catch (err) {
      showStatusMessage('Cookie Error', `Cookie clearing failed: ${err.message}`, true);
    } finally {
      restoreCookieButton();
    }
  }

  function restoreCookieButton() {
    isCookieOperationRunning = false;
    if (cookiesBtn) cookiesBtn.disabled = false;
  }

  // --- Attach Event Listeners ---
  startBtn.addEventListener('click', runStep1Workflow);
  if (stopRotationBtn) stopRotationBtn.addEventListener('click', stopContinuousRotation);
  if (resetBtn) resetBtn.addEventListener('click', resetWorkflow);
  if (applyReferralBtn) applyReferralBtn.addEventListener('click', applyReferralCode);

  if (autoClearCookiesToggle) {
    autoClearCookiesToggle.addEventListener('change', () => {
      chrome.storage.local.set({ autoClearOnStart: autoClearCookiesToggle.checked });
      showToast(
        autoClearCookiesToggle.checked
          ? 'Auto-Clear Cookies enabled on Magsimula'
          : 'Auto-Clear Cookies disabled on Magsimula'
      );
    });
  }

  if (autoRotateLoopToggle) {
    autoRotateLoopToggle.addEventListener('change', () => {
      chrome.storage.local.set({
        autoRotateLoop: autoRotateLoopToggle.checked,
        rotationLoopActive: autoRotateLoopToggle.checked
      });
      if (!autoRotateLoopToggle.checked) {
        stopContinuousRotation();
      } else {
        showToast('Continuous Auto-Rotate Loop enabled!');
      }
    });
  }

  if (setDefaultReferralBtn) {
    setDefaultReferralBtn.addEventListener('click', async () => {
      const rawCode = (referralCodeInput && referralCodeInput.value.trim().toUpperCase()) || 'NM3G4X';
      const cleanCode = rawCode.replace(/[^A-Z0-9]/g, '').slice(0, 12) || 'NM3G4X';
      await chrome.storage.local.set({ defaultReferralCode: cleanCode, lastReferralCode: cleanCode });
      if (defaultCodeDisplay) defaultCodeDisplay.textContent = cleanCode;
      if (referralCodeInput) referralCodeInput.value = cleanCode;
      showToast(`Default code set to ${cleanCode}`);
      if (referralStatus) {
        referralStatus.textContent = `Default referral code set to: ${cleanCode}`;
        referralStatus.style.color = 'var(--accent)';
      }
    });
  }

  if (saveRotationPoolBtn) {
    saveRotationPoolBtn.addEventListener('click', async () => {
      const rawPool = (rotationPoolInput && rotationPoolInput.value) || 'NM3G4X';
      const parsed = parseReferralPool(rawPool, 'NM3G4X');
      await chrome.storage.local.set({
        referralRotationPool: parsed,
        rotationIndex: 0,
        defaultReferralCode: parsed[0],
        lastReferralCode: parsed[0]
      });
      if (rotationPoolInput) rotationPoolInput.value = parsed.join(', ');
      if (referralCodeInput) referralCodeInput.value = parsed[0];
      if (defaultCodeDisplay) defaultCodeDisplay.textContent = parsed[0];
      if (nextCodeDisplay) nextCodeDisplay.textContent = parsed[0];
      showToast(`Saved ${parsed.length} code(s) to Rotation Pool!`);
      if (referralStatus) {
        referralStatus.textContent = `Rotation pool updated (${parsed.length} code${parsed.length > 1 ? 's' : ''}): ${parsed.join(', ')}`;
        referralStatus.style.color = 'var(--accent)';
      }
    });
  }

  if (clearAllHistoryBtn) clearAllHistoryBtn.addEventListener('click', promptClearAllHistory);
  if (confirmClearHistoryBtn) confirmClearHistoryBtn.addEventListener('click', executeClearAllHistory);
  if (cancelClearHistoryBtn) cancelClearHistoryBtn.addEventListener('click', cancelClearAllHistory);

  if (historyListContainer) {
    historyListContainer.addEventListener('click', async e => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const action = btn.dataset.action;

      if (action === 'delete') {
        const id = btn.dataset.id;
        if (id) await deleteHistoryItem(id);
      } else if (action === 'copy-email') {
        const val = btn.dataset.val;
        if (val) {
          await copyToClipboard(val);
          showToast('Email copied to clipboard!');
        }
      } else if (action === 'copy-pass') {
        const val = btn.dataset.val;
        if (val) {
          await copyToClipboard(val);
          showToast('Password copied to clipboard!');
        }
      } else if (action === 'toggle-pass') {
        const card = btn.closest('.history-card');
        const passValEl = card ? card.querySelector('.pass-field') : null;
        if (passValEl) {
          const isMasked = passValEl.classList.contains('masked');
          if (isMasked) {
            passValEl.textContent = passValEl.dataset.plain || '';
            passValEl.classList.remove('masked');
            btn.innerHTML = POPUP_ICONS.eyeOff;
            btn.title = 'Hide Password';
          } else {
            passValEl.textContent = '************';
            passValEl.classList.add('masked');
            btn.innerHTML = POPUP_ICONS.eye;
            btn.title = 'Show Password';
          }
        }
      }
    });
  }

  if (reloadBtn) reloadBtn.addEventListener('click', reloadActivePage);
  if (dataBtn) dataBtn.addEventListener('click', clearExtensionData);
  if (cookiesBtn) cookiesBtn.addEventListener('click', promptClearWebsiteCookies);
  if (checkBtn) {
    checkBtn.addEventListener('click', () => {
      detectAndDisplayPageMode();
      showToast('Checking active page state...');
    });
  }

  if (confirmClearCookiesBtn) confirmClearCookiesBtn.addEventListener('click', executeClearWebsiteCookies);
  if (cancelClearCookiesBtn) cancelClearCookiesBtn.addEventListener('click', cancelClearWebsiteCookies);

  if (domainSelect) {
    domainSelect.addEventListener('change', () => {
      if (customDomainGroup) {
        customDomainGroup.style.display = domainSelect.value === 'custom' ? 'grid' : 'none';
      }
      chrome.storage.local.set({ selectedDomain: getSelectedDomain() });
    });
  }

  if (togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener('click', () => {
      passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
      togglePasswordBtn.innerHTML =
        passwordInput.type === 'password' ? POPUP_ICONS.eye : POPUP_ICONS.eyeOff;
    });
  }

  document.querySelectorAll('[data-copy]').forEach(button => {
    button.addEventListener('click', async () => {
      const targetInput = $(button.dataset.copy);
      const value = targetInput ? targetInput.value : '';
      if (!value) return showToast('Nothing to copy yet.');
      await copyToClipboard(value);
      showToast(`Copied ${button.dataset.copy} to clipboard!`);
    });
  });

  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(
      [
        'emailHistory',
        'lastGeneratedEmail',
        'lastGeneratedPassword',
        'defaultReferralCode',
        'lastReferralCode',
        'referralRotationPool',
        'rotationIndex',
        'rotationCycleCount',
        'autoClearOnStart',
        'autoRotateLoop',
        'popupState',
        'popupStatusTitle',
        'popupStatusDesc'
      ],
      data => {
        if (data && data.emailHistory && typeof EmailGenerator !== 'undefined') {
          EmailGenerator.loadHistory(data.emailHistory);
          updateHistoryBadge();
        }
        if (data && data.lastGeneratedEmail && emailInput) {
          activeEmail = data.lastGeneratedEmail;
          emailInput.value = activeEmail;
        }
        if (data && data.lastGeneratedPassword && passwordInput) {
          activePassword = data.lastGeneratedPassword;
          passwordInput.value = activePassword;
        }

        const defaultCode = (data && data.defaultReferralCode) || 'NM3G4X';
        const pool = parseReferralPool(data && data.referralRotationPool, defaultCode);
        const rotIdx = parseInt((data && data.rotationIndex) || 0, 10) || 0;
        const cycleCount = parseInt((data && data.rotationCycleCount) || 0, 10) || 0;
        const nextCode = pool[rotIdx % pool.length] || defaultCode;

        if (defaultCodeDisplay) defaultCodeDisplay.textContent = defaultCode;
        if (referralCodeInput) {
          referralCodeInput.value = (data && data.lastReferralCode) || defaultCode;
        }
        if (rotationPoolInput) {
          rotationPoolInput.value = pool.join(', ');
        }
        if (rotationCycleBadge) {
          rotationCycleBadge.textContent = `Cycle #${cycleCount}`;
        }
        if (nextCodeDisplay) {
          nextCodeDisplay.textContent = nextCode;
        }
        if (autoClearCookiesToggle) {
          autoClearCookiesToggle.checked =
            data && typeof data.autoClearOnStart === 'boolean' ? data.autoClearOnStart : true;
        }
        if (autoRotateLoopToggle) {
          autoRotateLoopToggle.checked =
            data && typeof data.autoRotateLoop === 'boolean' ? data.autoRotateLoop : true;
        }

        if (
          data &&
          (data.popupState === STATES.STEP_1_SUCCESS || data.popupState === STATES.REFERRAL_STEP)
        ) {
          transitionTo(STATES.REFERRAL_STEP, {
            title: data.popupStatusTitle || 'Step 1 Complete',
            message: data.popupStatusDesc || 'Credentials populated. Step 2 Referral Code is ready.'
          });
        }
      }
    );
  }

  loadAndRenderHistory();

  if (chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        if (changes.credentialsHistory) {
          renderHistoryList(changes.credentialsHistory.newValue || []);
        }
        if (changes.rotationCycleCount && rotationCycleBadge) {
          rotationCycleBadge.textContent = `Cycle #${changes.rotationCycleCount.newValue || 0}`;
        }
        if (changes.lastReferralCode && referralCodeInput) {
          referralCodeInput.value = changes.lastReferralCode.newValue || 'NM3G4X';
        }
      }
    });
  }


  // --- SaveFrom.net (en1.savefrom.net) Assistant, Clean Download-Only UI & Ad-Blocker Controls ---
  const sfThemeSelect = $('sfThemeSelect');
  const sfOnlyDownloadToggle = $('sfOnlyDownloadToggle');
  const sfAdBlockToggle = $('sfAdBlockToggle');
  const sfHideHelperToggle = $('sfHideHelperToggle');
  const sfCleanClutterToggle = $('sfCleanClutterToggle');
  const sfBlockedCountBadge = $('sfBlockedCountBadge');
  const openSavefromBtn = $('openSavefromBtn');
  const sfPasteDownloadBtn = $('sfPasteDownloadBtn');
  const sfApplyNowBtn = $('sfApplyNowBtn');

  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(
      {
        sfTheme: 'midnight-glass',
        sfOnlyDownloadSection: true,
        sfAdBlockEnabled: true,
        sfBlockPopups: true,
        sfHideHelperPromos: true,
        sfHideArticlesAndFooter: true,
        sfAutoDownloadBest: false,
        sfBlockedAdsCount: 0
      },
      (sfData) => {
        if (sfThemeSelect && sfData.sfTheme) sfThemeSelect.value = sfData.sfTheme;
        if (sfOnlyDownloadToggle) sfOnlyDownloadToggle.checked = Boolean(sfData.sfOnlyDownloadSection);
        if (sfAdBlockToggle) sfAdBlockToggle.checked = Boolean(sfData.sfAdBlockEnabled);
        if (sfHideHelperToggle) sfHideHelperToggle.checked = Boolean(sfData.sfHideHelperPromos);
        if (sfCleanClutterToggle) sfCleanClutterToggle.checked = Boolean(sfData.sfAutoDownloadBest);
        if (sfBlockedCountBadge) {
          sfBlockedCountBadge.textContent = `${sfData.sfBlockedAdsCount || 0} blocked`;
        }
      }
    );
  }

  function pushSaveFromSettings(patch, toastMsg) {
    chrome.storage.local.set(patch, async () => {
      try {
        const tab = await getTargetTab();
        const u = (tab && (tab.url || tab.pendingUrl || '')).toLowerCase();
        if (tab && tab.id && (u.includes('savefrom.net') || u.includes('sfrom.net'))) {
          await sendSaveFromMessageWithInject(tab.id, { action: 'sf_update_settings', settings: patch });
        }
      } catch (e) {}
      if (toastMsg) showToast(toastMsg);
    });
  }

  if (sfThemeSelect) {
    sfThemeSelect.addEventListener('change', () => {
      pushSaveFromSettings({ sfTheme: sfThemeSelect.value }, `SaveFrom theme: ${sfThemeSelect.value}`);
    });
  }
  if (sfOnlyDownloadToggle) {
    sfOnlyDownloadToggle.addEventListener('change', () => {
      pushSaveFromSettings(
        {
          sfOnlyDownloadSection: sfOnlyDownloadToggle.checked,
          sfHideArticlesAndFooter: sfOnlyDownloadToggle.checked
        },
        sfOnlyDownloadToggle.checked
          ? 'Ultra-Clean Mode: Showing ONLY Download Section'
          : 'Restored full SaveFrom page sections'
      );
    });
  }
  if (sfAdBlockToggle) {
    sfAdBlockToggle.addEventListener('change', () => {
      pushSaveFromSettings(
        { sfAdBlockEnabled: sfAdBlockToggle.checked, sfBlockPopups: sfAdBlockToggle.checked },
        sfAdBlockToggle.checked ? 'SaveFrom Ad-Blocker enabled' : 'SaveFrom Ad-Blocker paused'
      );
    });
  }
  if (sfHideHelperToggle) {
    sfHideHelperToggle.addEventListener('change', () => {
      pushSaveFromSettings(
        { sfHideHelperPromos: sfHideHelperToggle.checked },
        sfHideHelperToggle.checked ? 'Hidden fake installer buttons' : 'Showing installer buttons'
      );
    });
  }
  if (sfCleanClutterToggle) {
    sfCleanClutterToggle.addEventListener('change', () => {
      pushSaveFromSettings(
        { sfAutoDownloadBest: sfCleanClutterToggle.checked },
        sfCleanClutterToggle.checked ? 'Auto-Download Best MP4 enabled' : 'Auto-Download Best MP4 disabled'
      );
    });
  }
  if (sfPasteDownloadBtn) {
    sfPasteDownloadBtn.addEventListener('click', async () => {
      const tab = await getTargetTab();
      const u = (tab && (tab.url || tab.pendingUrl || '')).toLowerCase();
      if (!tab || (!u.includes('savefrom.net') && !u.includes('sfrom.net'))) {
        chrome.tabs.create({ url: 'https://en1.savefrom.net/' });
        return;
      }
      await sendSaveFromMessageWithInject(tab.id, { action: 'sf_paste_and_download' });
      showToast('Pasted URL & started fetch on SaveFrom!');
    });
  }
  if (sfApplyNowBtn) {
    sfApplyNowBtn.addEventListener('click', async () => {
      const tab = await getTargetTab();
      const u = (tab && (tab.url || tab.pendingUrl || '')).toLowerCase();
      if (!tab || (!u.includes('savefrom.net') && !u.includes('sfrom.net'))) {
        showToast('Open en1.savefrom.net first!');
        return;
      }
      await sendSaveFromMessageWithInject(tab.id, {
        action: 'sf_update_settings',
        settings: {
          sfOnlyDownloadSection: sfOnlyDownloadToggle ? sfOnlyDownloadToggle.checked : true,
          sfTheme: sfThemeSelect ? sfThemeSelect.value : 'midnight-glass'
        }
      });
      showToast('SaveFrom Assistant & Clean UI applied!');
    });
  }
  if (openSavefromBtn) {
    openSavefromBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://en1.savefrom.net/' });
    });
  }

  detectAndDisplayPageMode();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup);
} else {
  initPopup();
}
