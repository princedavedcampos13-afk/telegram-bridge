// password_generator.js - Cryptographically Secure Random Password Generator

const PasswordGenerator = (() => {
  const UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const LOWERCASE = 'abcdefghijklmnopqrstuvwxyz';
  const NUMBERS = '0123456789';
  const SYMBOLS = '!@#$%&*'; // Standard web-safe symbols that pass strict registration regexes

  function generatePassword(length = 14, options = {}) {
    const opts = Object.assign({
      includeUppercase: true,
      includeLowercase: true,
      includeNumbers: true,
      includeSymbols: true
    }, options);

    const safeLength = Math.max(8, Math.min(32, parseInt(length, 10) || 14));
    let characterPool = '';
    const guaranteedChars = [];

    if (opts.includeUppercase) {
      characterPool += UPPERCASE;
      guaranteedChars.push(getRandomChar(UPPERCASE));
    }
    if (opts.includeLowercase) {
      characterPool += LOWERCASE;
      guaranteedChars.push(getRandomChar(LOWERCASE));
    }
    if (opts.includeNumbers) {
      characterPool += NUMBERS;
      guaranteedChars.push(getRandomChar(NUMBERS));
    }
    if (opts.includeSymbols) {
      characterPool += SYMBOLS;
      guaranteedChars.push(getRandomChar(SYMBOLS));
    }

    if (!characterPool) {
      characterPool = LOWERCASE + NUMBERS;
      guaranteedChars.push(getRandomChar(LOWERCASE));
      guaranteedChars.push(getRandomChar(NUMBERS));
    }

    const remainingCount = Math.max(0, safeLength - guaranteedChars.length);
    const randomChars = [];
    const webCrypto = (typeof crypto !== 'undefined') ? crypto : ((typeof window !== 'undefined') ? window.crypto : null);

    if (webCrypto && typeof webCrypto.getRandomValues === 'function' && remainingCount > 0) {
      const randomValues = new Uint32Array(remainingCount);
      webCrypto.getRandomValues(randomValues);
      for (let i = 0; i < remainingCount; i++) {
        randomChars.push(characterPool[randomValues[i] % characterPool.length]);
      }
    } else {
      for (let i = 0; i < remainingCount; i++) {
        randomChars.push(characterPool[Math.floor(Math.random() * characterPool.length)]);
      }
    }

    const allChars = guaranteedChars.concat(randomChars);
    shuffleArray(allChars);

    return allChars.join('');
  }

  function getRandomChar(charset) {
    const webCrypto = (typeof crypto !== 'undefined') ? crypto : ((typeof window !== 'undefined') ? window.crypto : null);
    if (webCrypto && typeof webCrypto.getRandomValues === 'function') {
      const arr = new Uint32Array(1);
      webCrypto.getRandomValues(arr);
      return charset[arr[0] % charset.length];
    }
    return charset[Math.floor(Math.random() * charset.length)];
  }

  function shuffleArray(array) {
    const webCrypto = (typeof crypto !== 'undefined') ? crypto : ((typeof window !== 'undefined') ? window.crypto : null);
    if (webCrypto && typeof webCrypto.getRandomValues === 'function' && array.length > 0) {
      const rand = new Uint32Array(array.length);
      webCrypto.getRandomValues(rand);
      for (let i = array.length - 1; i > 0; i--) {
        const j = rand[i] % (i + 1);
        [array[i], array[j]] = [array[j], array[i]];
      }
    } else {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
  }

  return {
    generatePassword
  };
})();

if (typeof window !== 'undefined') {
  window.PasswordGenerator = PasswordGenerator;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PasswordGenerator;
}
