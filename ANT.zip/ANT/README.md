# Knowunity Assistant (v5.0) — Rotation Workflow, Integrated Auto-Clear Cookies & Redesigned Glass Dock Edition

A Chromium Manifest V3 browser extension optimized for Lemur Browser on Android and desktop Chromium browsers.

## Key Updates & Enhancements in v5.0

### 1. Integrated Clear Cookies + Rotation Workflow in `Magsimula All-in-One`
- **Built-in Cookie & Storage Wipe**: Clicking **`Magsimula All-in-One`** (on the floating dock, menu drawer, or extension popup) now automatically wipes all `knowunity.ph` / `knowunity.com` cookies (including partitioned & subdomain cookies via `background.js`), `localStorage`, and `sessionStorage` before starting registration.
- **Multi-Code Referral Rotation Pool**: Configure a single default referral code or a comma-separated pool of referral codes (e.g., `NM3G4X, CODE02, CODE03`). Each run automatically advances to the next code in the pool and increments the **Rotation Cycle Counter (`#1`, `#2`, ...)**.
- **Continuous Auto-Rotate Loop Mode**: Enable **Auto-Rotate Continuous Loop** in the popup or on-page menu to automatically start the next rotation cycle after `"Tapos Na"` completes.
- **Smart Post-Clear Navigation**: If triggered while logged into a previous session, the extension automatically saves workflow state, redirects to the root landing page, and seamlessly resumes the registration + referral sequence.

### 2. Redesigned & Repositionable Floating Glass Dock & Menu Drawer
- **Sleek Dark-Slate Glass Dock (`#knowunity-site-dock`)**: High-contrast frost-glass bar featuring a live browser & rotation cycle badge (`Lemur #1`), quick **Clear Cookies** button, primary **Magsimula All-in-One** button, **Menu** toggle, and collapsible **Minimize** trigger.
- **4-Corner Dock Position Switcher**: Reposition the floating dock anytime (`BL` Bottom-Left, `BC` Bottom-Center, `BR` Bottom-Right, `TR` Top-Right) directly from the menu header.
- **Streamlined Card Menu Drawer (`#knowunity-site-menu-panel`)**:
  - **Environment & Rotation Toggles**: Live browser/platform status, cycle counter, `Clear Cookies on Magsimula All-in-One` toggle, and `Auto-Rotate Continuous Loop` toggle.
  - **Referral Code & Rotation Pool**: Set your primary default code or save a multi-code rotation pool with live `Default` and `Next` code indicators.
  - **Workflow Shortcuts**: Run Magsimula All-in-One, Autofill Form Only (without clearing cookies), or trigger `"Tapos Na"` confirmation.
  - **Tools & Storage**: Copy active email/password, clear cookies & storage, or reset workflow & rotation counters.

### 3. Comprehensive Bug Fixes & Hardening (100% Bug-Free)
- **Strict Extension Element Isolation**: Fixed a critical bug where `findInputsImmediate()`, `fillSixBoxReferralCode()`, and `detectPageMode()` could match inputs or text inside the extension's own on-page menu drawer (`#knowunity-menu-ref-input`).
- **Popup Initialization & Storage Sync Fixes**: Fixed undeclared DOM references (`browserNameText`, `detectedBrowserVersion`, `setDefaultReferralBtn`, `defaultCodeDisplay`) and added missing `defaultReferralCode` / rotation keys to the initial `chrome.storage.local.get` call in `popup.js`.
- **100% Pure Vector Icons**: Replaced leftover raw unicode symbols (`●`, `◉`, `◎`, `›`, `✓`, `\uFE0F`) with crisp inline SVG icons across `content.js`, `popup.html`, and `popup.js`.
- **Resilient Cookie Removal**: Upgraded `background.js` to scan all `knowunity` domains/subdomains with 3-stage fallback removal (with `partitionKey`, without `partitionKey`, and alternate protocol).

## Installation Instructions (Lemur Browser on Android / Desktop Chromium)

1. Extract `knowunity_launcher_v5.zip`.
2. Open `chrome://extensions` and enable **Developer Mode**.
3. Tap **Load unpacked** (or **Update**) and select the extracted folder.
4. Open `https://knowunity.ph/` and tap **`Magsimula All-in-One`** on the floating dock or popup.
