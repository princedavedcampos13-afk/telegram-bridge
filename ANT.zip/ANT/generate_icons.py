import os
import struct
import zlib
import math

def create_png(width, height, get_pixel):
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0) # Filter type 0 (None)
        for x in range(width):
            r, g, b, a = get_pixel(x, y, width, height)
            raw_data.extend([r, g, b, a])
    
    # PNG signature
    png = bytearray(b'\x89PNG\r\n\x1a\n')
    
    # IHDR chunk
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    ihdr_crc = struct.pack('>I', zlib.crc32(b'IHDR' + ihdr_data) & 0xffffffff)
    png.extend(struct.pack('>I', len(ihdr_data)) + b'IHDR' + ihdr_data + ihdr_crc)
    
    # IDAT chunk
    compressed = zlib.compress(raw_data, 9)
    idat_crc = struct.pack('>I', zlib.crc32(b'IDAT' + compressed) & 0xffffffff)
    png.extend(struct.pack('>I', len(compressed)) + b'IDAT' + compressed + idat_crc)
    
    # IEND chunk
    iend_crc = struct.pack('>I', zlib.crc32(b'IEND') & 0xffffffff)
    png.extend(struct.pack('>I', 0) + b'IEND' + iend_crc)
    
    return bytes(png)

def point_in_polygon(x, y, poly):
    inside = False
    n = len(poly)
    p1x, p1y = poly[0]
    for i in range(1, n + 1):
        p2x, p2y = poly[i % n]
        if y > min(p1y, p2y):
            if y <= max(p1y, p2y):
                if x <= max(p1x, p2x):
                    if p1y != p2y:
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside

def get_icon_pixel(x, y, w, h):
    # Normalized coords 0.0 to 1.0
    nx = x / float(w)
    ny = y / float(h)
    
    # Rounded rectangle background
    corner_radius = 0.22
    dx = max(corner_radius - nx, 0, nx - (1.0 - corner_radius))
    dy = max(corner_radius - ny, 0, ny - (1.0 - corner_radius))
    dist = math.hypot(dx, dy)
    
    if dist > corner_radius:
        return (0, 0, 0, 0) # transparent
    
    # Emerald gradient background (top-left #10b981 to bottom-right #047857)
    grad = (nx + ny) / 2.0
    bg_r = int(16 * (1 - grad) + 4 * grad)
    bg_g = int(185 * (1 - grad) + 120 * grad)
    bg_b = int(129 * (1 - grad) + 87 * grad)
    
    # Lightning bolt polygon coords (normalized 0 to 1)
    bolt = [
        (0.56, 0.16),
        (0.28, 0.54),
        (0.48, 0.54),
        (0.40, 0.84),
        (0.72, 0.44),
        (0.52, 0.44),
    ]
    
    if point_in_polygon(nx, ny, bolt):
        # White bolt with subtle soft yellow glow
        return (255, 255, 255, 255)
    
    return (bg_r, bg_g, bg_b, 255)

os.makedirs('icons', exist_ok=True)

for size in [16, 48, 128]:
    png_data = create_png(size, size, get_icon_pixel)
    path = os.path.join('icons', f'icon{size}.png')
    with open(path, 'wb') as f:
        f.write(png_data)
    print(f"Generated {path} ({size}x{size})")
